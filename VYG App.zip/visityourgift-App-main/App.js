import * as React from 'react';
import {NavigationContainer, useRoute} from '@react-navigation/native';
import { configureStore } from '@reduxjs/toolkit'
import Screens from './App/Screens/index'
import  {Provider}  from 'react-redux';
import rootReducer from './App/Slices'
import { LogBox, StatusBar } from 'react-native';
import FlipkartSuperCoinsGif from './App/Components/GifAnimation';

const store = configureStore({reducer:rootReducer})
const App =() => {





    LogBox.ignoreAllLogs(true);

    return( 
        <Provider store={store} >
             {/* <StatusBar
        backgroundColor="#264d9b"
        barStyle="light-content"
     /> */}

{/* <FlipkartSuperCoinsGif /> */}

         <Screens/>
        </Provider>
    )

}
export default App;


// import LinearGradient from 'react-native-linear-gradient';
// import { getStatusBarHeight } from 'react-native-iphone-x-helper';
// const color = "#ff0000"

// const color1 = "#4152aa"

// const StatusBarGradient = () => {
//     useEffect(() => {
//       StatusBar.setBarStyle('light-content');
//     }, []);
  
//     return (
//       <LinearGradient
//         style={{ height: getStatusBarHeight(), width: '100%', position: 'absolute', top: 0, left: 0 }}
//         colors={['#ec2c61', '#ff4e43']}
//         start={{ x: 0, y: 0 }}
//         end={{ x: 1, y: 0 }}
//       />
//     );
//   };

  
// import React, { useState, useEffect, Component } from 'react';
// import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Linking, ScrollView, SafeAreaView, StatusBar } from 'react-native';


// export default function Terms(props) {





//     return (
//         <View style={{ height: "100%", width: "100%", }}>

//             <StatusBar
//                 backgroundColor="#4152aa"
//                 barStyle="light-content"
//             />

//             <View style={{ justifyContent: "space-between", flexDirection: "row", width: "100%", alignItems: "center", height: 60, backgroundColor: "white" }}>
//                 <View style={{ width: "55%", justifyContent: "space-evenly", flexDirection: "row", alignItems: "center" }}>
//                     <Image style={{ width: 32, height: 32, resizeMode: "contain" }} source={require("./App/Assets/left-arrow.png")} />
//                     <Text style={{ fontWeight: "500", color: "black", fontSize: 20 }}>add campaign</Text>
//                 </View>
//                 <View style={{ width: "22%", justifyContent: "space-evenly", flexDirection: "row", alignItems: "center" }}>
//                     <Text style={{ fontWeight: "500", color: "black", fontSize: 20 }}>348</Text>
//                     {/* <Image style={{ width: 30, height: 30, resizeMode: "contain" }} source={require("./App/Assets/heart12.png")} /> */}
//                     <Image style={{ width: 30, height: 30, resizeMode: "contain" }} source={require("./App/Assets/hearty.png")} />

//                 </View>

//             </View>
//             <View style={{ height: "25%", }}>
//                 <Image style={{ width: "100%", height: "100%", resizeMode: "cover" }} source={require("./App/Assets/blackyy.jpg")} />
//             </View>

//             <View style={{ height: "68%", width: "100%" }}>




//                 <View style={{ flexDirection: "row", width: "100%", height: 80, alignItems: "center" }}>
//                     <Image style={{ marginLeft: 20, width: 40, height: 40, resizeMode: "contain" }} source={require("./App/Assets/danger.png")} />
//                     <Text style={{ marginLeft: 10, color: "black", fontSize: 16, width: "80%" }}>How to get link: open your video on YT {"->"} share button {"->"} copy link</Text>
//                 </View>

//                 <View style={{ alignSelf: "center", justifyContent: "space-evenly", flexDirection: "row", width: "98%", height: 70, alignItems: "center" }}>

//                     <View style={{ flexDirection: "row", justifyContent: "space-evenly", alignItems: "center", width: "65%", backgroundColor: "#f3f3f3", height: 50, borderRadius: 25 }}>
//                         <Text style={{ color: "black", fontSize: 14.5, width: "70%" }}>Video link address(URL)</Text>
//                         <Image style={{ width: 25, height: 25, resizeMode: "contain" }} source={require("./App/Assets/youtube.png")} />
//                     </View>
//                     <View style={{ width: "25%", backgroundColor: "#4152aa", height: 50, borderRadius: 25, justifyContent: "center", alignItems: "center" }}>
//                         <Text style={{ color: "white", fontSize: 16 }}>Add</Text>
//                     </View>
//                     {/* <LinearGradient
//                         style={{ width: '25%', height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center' }}
//                         colors={['#ec2c61', '#ff4e43']}
//                         start={{ x: 0, y: 0 }}
//                         end={{ x: 1, y: 0 }}
//                     >
//                         <Text style={{ color: 'white', fontSize: 16 }}>Add</Text>
//                     </LinearGradient> */}


//                 </View>

//                 <Text style={{ color: "black", fontSize: 14.5, width: "70%", marginTop: 10, marginLeft: 20 }}>Select from recent videos  </Text>




//                 <View style={{ marginTop: 20, borderRadius: 20, alignSelf: "center", flexDirection: "row", width: "90%", height: 50, alignItems: "center" }}>

//                     <View style={{ borderTopLeftRadius: 20, borderBottomLeftRadius: 20, justifyContent: "center", backgroundColor: "#4152aa", alignItems: "center", width: "33%", flexDirection: "row", height: 50, }}>
//                         <Image style={{ width: 25, height: 25, resizeMode: "contain" }} source={require("./App/Assets/youtube1.png")} />
//                         <Text style={{ color: "white", fontSize: 14, marginLeft: 5 }}>View</Text>
//                     </View>
//                     {/* <LinearGradient
//                         style={{ borderTopLeftRadius: 20, borderBottomLeftRadius: 20, justifyContent: 'center', alignItems: 'center', width: '33%', flexDirection: 'row', height: 50 }}
//                         colors={['#ec2c61', '#ff4e43']}
//                         start={{ x: 0, y: 0 }}
//                         end={{ x: 1, y: 0 }}
//                     >
//                         <Image style={{ width: 25, height: 25, resizeMode: 'contain' }} source={require('./App/Assets/youtube1.png')} />
//                         <Text style={{ color: 'white', fontSize: 14, marginLeft: 5 }}>View</Text>
//                     </LinearGradient> */}




//                     <View style={{ justifyContent: "center", backgroundColor: "#f3f3f3", borderRightWidth: 0.19, alignItems: "center", width: "34%", height: 50, flexDirection: "row" }}>
//                         <Image style={{ width: 20, height: 20, resizeMode: "contain" }} source={require("./App/Assets/playlist.png")} />
//                         <Text style={{ color: "grey", fontSize: 14, marginLeft: 5 }}>Subcribe</Text>
//                     </View>

//                     <View style={{ borderTopRightRadius: 20, borderBottomRightRadius: 20, justifyContent: "center", backgroundColor: "#f3f3f3", alignItems: "center", width: "33%", height: 50, flexDirection: "row" }}>
//                         <Image style={{ width: 20, height: 20, resizeMode: "contain" }} source={require("./App/Assets/thumb-up.png")} />
//                         <Text style={{ color: "grey", fontSize: 14, marginLeft: 5 }}>Like</Text>
//                     </View>
//                 </View>


//                 <Text style={{ color: "black", fontSize: 15, fontWeight: "600", width: "70%", marginTop: 20, marginLeft: 20 }}>Campaign Settings  </Text>


//                 <View style={{ alignSelf: "center", justifyContent: "space-evenly", flexDirection: "row", width: "98%", height: 60, alignItems: "center" }}>


//                     <Text style={{ color: "black", fontSize: 14.5, width: "59%" }}>Numbers of View</Text>

//                     <View style={{ flexDirection: "row", width: "30%", backgroundColor: "#f3f3f3", height: 42, borderRadius: 25, justifyContent: "space-around", alignItems: "center" }}>
//                         <Text style={{ color: "black", fontSize: 15, fontWeight: "500" }}>25</Text>
//                         <Image style={{ width: 25, height: 25, resizeMode: "contain" }} source={require("./App/Assets/down1.png")} />
//                     </View>
//                 </View>
//                 <View style={{ alignSelf: "center", justifyContent: "space-evenly", flexDirection: "row", width: "98%", height: 55, alignItems: "center" }}>


//                     <Text style={{ color: "black", fontSize: 14.5, width: "59%" }}>Time Required(sec.)</Text>

//                     <View style={{ flexDirection: "row", width: "30%", backgroundColor: "#f3f3f3", height: 42, borderRadius: 25, justifyContent: "space-around", alignItems: "center" }}>
//                         <Text style={{ color: "black", fontSize: 15, fontWeight: "500" }}>25</Text>
//                         <Image style={{ width: 25, height: 25, resizeMode: "contain" }} source={require("./App/Assets/down1.png")} />
//                     </View>
//                 </View>
//                 <Text style={{ color: "black", fontSize: 15, fontWeight: "600", width: "70%", marginTop: 5, marginLeft: 20 }}>Campaign Cost  </Text>

//                 <View style={{ alignSelf: "center", justifyContent: "space-evenly", flexDirection: "row", width: "93%", height: 60, alignItems: "center" }}>


//                     <Text style={{ color: "black", fontSize: 14.5, width: "70%" }}>Total Cost</Text>

//                     <View style={{ width: "25%", justifyContent: "space-evenly", flexDirection: "row", alignItems: "center" }}>
//                         <Text style={{ fontWeight: "800", color: "#4152aa", fontSize: 20 }}>1500</Text>
//                         {/* <Image style={{ width: 30, height: 30, resizeMode: "contain" }} source={require("./App/Assets/heart12.png")} /> */}
//                         <Image style={{ width: 30, height: 30, resizeMode: "contain" }} source={require("./App/Assets/hearty.png")} />

//                     </View>
//                 </View>



//                 <View style={{ width: "100%", justifyContent: "space-evenly", alignItems: "center", flexDirection: "row" }}>



//                     <View style={{ width: "45%", backgroundColor: "black", height: 50, borderRadius: 25, justifyContent: "center", alignItems: "center" }}>
//                         <Text style={{ color: "white", fontSize: 15 }}>Decrease Cost 10%</Text>
//                     </View>
//                     <View style={{ width: "45%", backgroundColor: "#4152aa", height: 50, borderRadius: 25, justifyContent: "center", alignItems: "center" }}>
//                         <Text style={{ color: "white", fontSize: 15 }}>Done</Text>
//                     </View>

//                     {/* <LinearGradient
//                         style={{ width: '45%', height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center' }}
//                         colors={['#ec2c61', '#ff4e43']}
//                         start={{ x: 0, y: 0 }}
//                         end={{ x: 1, y: 0 }}
//                     >
//                         <Text style={{ color: 'white', fontSize: 15 }}>Done</Text>
//                     </LinearGradient> */}


//                 </View>






//             </View>



//         </View>
//     )
// }