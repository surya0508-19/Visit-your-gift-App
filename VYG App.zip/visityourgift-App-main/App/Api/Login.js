import { URL_LOGIN, URL_SIGNUP } from '../Constants'
import axios from 'axios';
import Toast from 'react-native-simple-toast';

export const loginapi = async (postdata) => {

    try {
        const login = await axios({
            method: "post",
            url: `${URL_LOGIN}`,
            data: postdata

        })


        // console.log("req_token", login.data)

        if (login.data.token) {
            return login.data;

        }




    }
    catch (error) {
        console.log("error====>", error)
        console.log("400", error.response.data.errors.email)
        // Toast.show(error.response.data.errors);
    }
}



export const signupApi = async (postsignup) => {

    try {
        const signup = await axios({
            method: "post",
            url: `${URL_SIGNUP}`,
            data: postsignup
        })


        Toast.show("Sign up Successfull");
        return signup.data;

    }
    catch (error) {
        console.log("error====>", error)
        console.log("400", error.response.data.message)
        Toast.show(error.response.data.message);

    }


}




