
import React, { useState, useEffect, Component, useRef } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet, Animated } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { IMAGE_URL_CATEGORY } from '../Constants';
import { authSelector } from '../Slices/auth';
import { deletebrands, fetchcatbrand } from '../Slices/brand';
import { cartSelector } from '../Slices/cart';
import { categoriesproductSliceSelector, fetchcatproducts, updatemainloader, updatepagination } from '../Slices/categoriesproduct';
import { homedataSelector, switch_cat_head } from '../Slices/homedata';
const { width, height } = Dimensions.get("window")
export default function Subcategories(props, navigation) {
  const dispatch = useDispatch()
  const { categories } = useSelector(homedataSelector)
  const { cart_products } = useSelector(cartSelector)
  const { switchcatstatus } = useSelector(categoriesproductSliceSelector)
  const { token } = useSelector(authSelector)
  const width1 = new Animated.Value(40);
  const height1 = new Animated.Value(40);
  const [value, setValue] = useState(0)
  useEffect(() => {
    // if (switchcatstatus || value) {
    Animated.timing(
      width1, // The animated value to drive
      {
        toValue: 60, // Animate to opacity: 1 (opaque)
        duration: 1000, // Make it take a while
        useNativeDriver: false,
      },
    ).start(); // Starts the animation
    Animated.timing(
      height1, // The animated value to drive
      {
        toValue: 60, // Animate to opacity: 1 (opaque)
        duration: 1000, // Make it take a while
        useNativeDriver: false,
      },
    ).start(); // Starts the animation
    // }
  }, [switchcatstatus, value]);


  const update = (index) => {

    dispatch(switch_cat_head(categories[index]))
    var data = {
      cat_id: categories[index].id,
      page: 1,
      cartdata: cart_products,
      type: 'switch',
      token: token,
      brand: "",
      state: "",
      sort: ""

    }
    dispatch(fetchcatproducts(data))
    dispatch(fetchcatbrand(categories[index].id))
    setValue(index)
    dispatch(deletebrands())
  }
  const animatedValue = useRef(new Animated.Value(1)).current;
  const [zoomed, setZoomed] = useState(false);

  // Function to handle zoom-in animation
  const handleZoomIn = () => {
    Animated.timing(animatedValue, {
      toValue: 1.5,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      // Reset zoom after animation completes
      Animated.timing(animatedValue, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    });
  };
  return (

    <FlatList
      data={categories}
      horizontal
      showsHorizontalScrollIndicator={false}
      renderItem={({ item, index }) => (
        <View style={{ backgroundColor: "#00a4ff" }}>

          <>
            {index === value ? (
              <View style={styles.subcategoryconatiner}>
                <View style={{ width: "94%", height: "100%", alignItems: "center" }}>
                  <View style={{ width: "100%", height: "75.5%", justifyContent: "center", alignItems: "center" }}>
                    <View style={{ width: "80%", height: "90%", backgroundColor: "#cfe9f7", borderRadius: width * 0.2, alignSelf: "center" }} />
                    <Animated.Image
                      source={{ uri: `${IMAGE_URL_CATEGORY}${item.image}` }}
                      style={{
                        width: width * 0.15,
                        height: width * 0.15,
                        transform: [{ scale: animatedValue }],
                        position: "absolute",
                        resizeMode: "contain",
                      }}
                    />
                  </View>
                  <Text numberOfLines={2} style={styles.title1}>{item.name}</Text>
                </View>
                {/* <View style={{ width: "94%", height: "5%", marginTop: 10, backgroundColor: "#00a4ff", borderTopLeftRadius: width * 0.025, borderBottomLeftRadius: width * 0.02 }} /> */}
              </View>
            ) : (
              <View style={styles.subcategoryconatiner1}>
                <View style={{ width: "100%", height: "100%", alignItems: "center" }}>
                  <View style={{ width: "100%", height: "75%", alignItems: "center", justifyContent: "center" }}>
                    <Pressable onPress={() => {
                      handleZoomIn();
                      update(index);
                    }} style={{ width: "75%", height: "90%", backgroundColor: "#f6f6f3", borderRadius: width * 0.3, justifyContent: "center" }}>
                      <Image
                        source={{ uri: `${IMAGE_URL_CATEGORY}${item.image}` }}
                        style={{ width: 50, height: 50, alignSelf: "center", resizeMode: "contain" }}
                      />
                    </Pressable>
                  </View>
                  <View style={{ width: "100%", height: "30%", alignItems: "center", justifyContent: "center" }}>
                    <Text numberOfLines={2} style={styles.title2}>{item.name}</Text>
                  </View>
                </View>
              </View>
            )}
          </>


        </View>

      )}
    />

  )
}
const styles = StyleSheet.create({
  conatiner: {
    width: width,
    height: height * 0.01,
    backgroundColor: "#d3d3d33d"
  },
  subcategoryconatiner: {
    width: 90,
    height: 95,
    alignItems: "center",
    marginTop: 10,
    justifyContent: "center",


  },
  subcategoryconatiner1: {
    width: 90,
    height: 95,
    // backgroundColor: "white",
    alignItems: "center",
    marginTop: 10,

  },
  title1: {
    fontFamily: "Roboto-Medium",
    fontWeight: "700",
    fontSize: width * 0.03,
    color: "white",
    textAlign: "center",
    width: "85%"
  },
  title2: {
    fontFamily: "Roboto-Light",
    fontWeight: "600",
    fontSize: width * 0.0285,
    color: "white",
    textAlign: "center",
    width: "85%"
  },
})