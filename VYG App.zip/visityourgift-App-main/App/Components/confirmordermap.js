import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import {useDispatch, useSelector} from 'react-redux';
import { countSelector,getcount} from '../Slices/count';
const {width,height} = Dimensions.get("window")
export default function Confirmordermap (props,navigation) {
    return(
        <View style={{width:width,height:height*0.5,backgroundColor:"red",position:"absolute",top:0}} >

        </View>
    )
}