import React, { useState, useEffect, Component } from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,Modal, TextInput,StyleSheet,FlatList} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { Recommendedproduct } from '../Screens/TestData/data';
import { categoriesproductSliceSelector, update_similarpro,updatecatpro } from '../Slices/categoriesproduct';
import { IMAGE_URL_PRODUCTS } from '../Constants';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { addtocart, cartSelector, fetchcart, update_maincart } from '../Slices/cart';
import { authSelector } from '../Slices/auth';

const {width,height}=Dimensions.get("window")
export default function Similarproducts (props,navigation) {
  const dispatch = useDispatch()
  const {similarproducts,categoriesproduct} = useSelector(categoriesproductSliceSelector)
  
  const{cart_products} = useSelector(cartSelector)
  const {token} = useSelector(authSelector)
  const updatecart = (index,type) => {
    
    var data = [...similarproducts]
    if( data[index].qty >= data[index].actual_qty && type == "increment")
    {
       Toast.show("You reached maximun stock", Toast.SHORT);
    }
    else
    {
        //update cart 
        dispatch(update_similarpro({value:index,key:type}))

       if(type == "increment" && data[index].qty == 0)
       { 
           var price = {
               productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price ) * 1,
               cartlength:1,
               type:"addtocart"
           }
          dispatch(update_maincart(price))
       }
       else if (data[index].qty > 0) 
       {
         if(type == "increment")
         {
           var price = {
               productprice:Number(data[index].offer_price ? data[index].offer_price : data[index].price ) * Number(1),
               cartlength:0,
               type:type
           }
          dispatch(update_maincart(price))
         }
         else
         {
           var price = {
               productprice:Number(data[index].offer_price ? data[index].offer_price : data[index].price ) * Number(-1),
               cartlength:(data[index].qty == 1 ? Number(-1) :Number(0)),
               type:type
           }
          dispatch(update_maincart(price))
         }
       }
      
       
       //update cart with api call
       var data={
           "product_id":data[index].product_id,
           "product_variant_id":data[index].variant_id,
           "quantity":1,
            "type":type
       }
       var payload ={
           data:data,
           token:token
       }
       dispatch(addtocart(payload))
       dispatch(fetchcart(token))
    
    }
  }
 return(
    <FlatList 
    data={similarproducts}
    horizontal={true}
    showsHorizontalScrollIndicator={false}
    renderItem={({item,index}) => (
        <Card style={{width:width*0.45,height:height*0.35,margin:width*0.02}} >
          <View style={{width:"100%",height:"60%",justifyContent:"center"}} >
          <Image style={{width:"60%",height:"90%",alignSelf:"center",resizeMode:"contain"}} source={{uri:`${IMAGE_URL_PRODUCTS}`+item.image}} />
          </View>

          <View style={{width:"100%",height:"40%",}} >
            <View style={{width:"100%",height:"50%",justifyContent:"center"}} >
            <Text numberOfLines={2} style={style.title1} >{item.productname} </Text>
            <Text  style={style.text} >({item.variant_value}) </Text>
            </View> 
            <View style={{width:"100%",height:"50%",flexDirection:"row",alignItems:"center",}} >
                <View style={{width:"40%",height:"100%",justifyContent:"center",marginLeft:"5%"}} >
                {item.offer_price ?
                <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.0325, color: "black", marginLeft: "10%",textDecorationLine: 'line-through',color:"grey" }} >$ {parseFloat(item.offer_price).toFixed(2)}</Text>:null}
                <Text  style={style.price_text} >$  {parseFloat(item.price).toFixed(2)} </Text> 
                </View>
                <View style={{width:"60%",height:"100%",justifyContent:"center",alignItems:"center"}} >
                    {!item.check ?
                    <Pressable onPress={() => updatecart(index,"increment")} style={{width:'70%',height:'55%',borderRadius:width*0.015,backgroundColor:"#f8fff8",borderColor:"#00a4ff",borderWidth:width*0.001,justifyContent:"center"}} >
                    <Text style={style.add_text} >ADD</Text> 
                    </Pressable>:
                      <View style={{width:'70%',height:'55%',borderRadius:width*0.015,backgroundColor:"#00a4ff",borderColor:"#00a4ff",borderWidth:width*0.001,alignItems:'center',flexDirection:"row"}} >
                         <Pressable onPress={() => updatecart(index,"decrement")} style={{ width: "25%", height: "100%", justifyContent: "center"}} >
                                <Image style={{ width: "80%", height: "80%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/minus1.png')} />
                         </Pressable>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center" }} >
                                <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, textAlign: "center", color: "white" }} >{item.qty}</Text>
                            </View>

                            <Pressable onPress={() => updatecart(index,"increment")} style={{ width: "25%", height: "100%", justifyContent: "center" }} >
                                <Image style={{ width: "80%", height: "80%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/plus1.png')} />
                            </Pressable>
                      </View>}
                </View>
             </View>
            </View>
          
        </Card>
    )}
    />
 )
}
const style = StyleSheet.create({
    container:{
        width:width,
        height:height*0.875,
        backgroundColor:"white",
        borderRadius:width*0.035,
        top:"11.25%"
    },
    container1:{
        width:width,
        height:height*0.6,
        backgroundColor:"white",
        position:"absolute",
        bottom:0,
        borderRadius:width*0.035
    },
    title1:{
        fontFamily:"Roboto-Medium",
        fontWeight:"600",
        fontSize:width*0.035,
        color:"black",
        marginLeft:"5%"
      },
      price_text:{
        fontFamily:"Roboto-Medium",
        fontWeight:"600",
        fontSize:width*0.035,
        color:"black",
        marginLeft:"5%"
      },
      add_text:{
        fontFamily:"Roboto-Regular",
        fontWeight:"600",
        fontSize:width*0.035,
        color:"#00a4ff",
        textAlign:"center"
      },
      text:{
        fontFamily:"Roboto-Light",
        fontWeight:"600",
        fontSize:width*0.03,
        color:"black",
        marginTop:"1%",
        marginLeft:"5%",
        width:"95%"
      }
})