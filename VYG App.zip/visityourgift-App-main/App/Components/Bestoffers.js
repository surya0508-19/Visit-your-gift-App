
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';

const {width,height} = Dimensions.get("window")
export default function Bestoffers (props,navigation) {
    const DATA = [
        {
          shop_image:require("../Assets/kannan.png"),
          shop_name:"Kannan Departmental Store",
          offer:"Bye 1 Get 1",
          valid:"12 Mar 2023"
        },
        {
            shop_image:require("../Assets/hari.jpg"),
            shop_name:"Sri Hari maligai",
            offer:"Free 10 kg sugar for above 100rup",
            valid:"20 feb 2023"
        },
        {
            shop_image:require("../Assets/pettikadai.png"),
            shop_name:"Sattanathan petti shop",
            offer:"Dall 100rup for 1 kg",
            valid:"28 jan 2023"
        },
        {
            shop_image:require("../Assets/supermarket.jpg"),
            shop_name:"Sangamam super market",
            offer:"Bucket free for Gloub jammun powder",
            valid:"14 Apr 2023"
        },
      ];
    
return(
<FlatList 
       data={DATA}
       numColumns={2}
       renderItem={({item}) => (
        <View style={{width:"50%",height:'auto',backgroundColor:"white",margin:0.75}} >
            <Pressable onPress={() => props.shopdetail()} style={{width:"100%",height:height*0.2,justifyContent:"center"}} >
              <Image style={{width:"70%",height:"80%",margin:5,alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={item.shop_image} />
            </Pressable>
          <Text style={{fontFamily:"Roboto-Medium",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.041}} >{item.shop_name}</Text>
          <Text style={{fontFamily:"Roboto-Medium",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.035,marginTop:"2%",color:"#00a4ff"}} >{item.offer}</Text>
          <Text style={{fontFamily:"Roboto-Light",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.035,marginTop:"2%",marginBottom:"5%"}} >Offer up to : {item.valid}</Text>
         </View>
       )
    }
/>
)
}
const styles = StyleSheet.create({
    conatiner:{
        width:width,
        height:height*0.01,
        backgroundColor:"#d3d3d33d"
    }
})