
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { IMAGE_URL_BRANDS, IMAGE_URL_PRODUCTS } from '../Constants';
import { authSelector } from '../Slices/auth';
import { cartSelector } from '../Slices/cart';
import { fetchbrandproducts, } from '../Slices/searchproducts';



const { width, height } = Dimensions.get("window")
export default function SearchProducts(props, navigation) {

    const dispatch = useDispatch()

    const { cart_products } = useSelector(cartSelector);
    const {token} = useSelector(authSelector)
    const detail = (id, index) => {

        dispatch(fetchbrandproducts(id, cart_products,token))
        setIndex(index)
    }

    const [Index, setIndex] = useState("")

    return (
        <FlatList
            data={props.dataParentToChild}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item, index }) => (
                <Pressable onPress={() => detail(item.id, index)} >
                    <View>

                        <View style={{ width: 100, height: height * 0.15, backgroundColor: "white" }}>
                            <View style={ Index==index? { width: "90%", height: height * 0.1, backgroundColor: "#f3f7ff",marginLeft:"5%",marginTop:"5%",borderRadius: width * 0.02 ,borderColor:"#00a4ff",borderWidth:width*0.005}:{ width: "100%", height: height * 0.1, backgroundColor: "#f3f7ff",  borderRadius: width * 0.02 ,marginLeft:"5%",marginTop:"5%"}}>
                           {item.image ?
                            <Image style={{ width: "80%", height: "80%", resizeMode: "contain", alignSelf: "center", marginTop: "5%", marginBottom: "5%" }} source={{uri:`${IMAGE_URL_BRANDS}`+item.image}} />:
                            <Image style={{ width: "80%", height: "80%", resizeMode: "contain", alignSelf: "center", marginTop: "5%", marginBottom: "5%" }} source={require("../Assets/serachempty.png")} />}
                        </View>
                        <Text style={{ color: "black", fontFamily: "Roboto-Medium", fontSize: width * 0.030, textAlign: "center", width: "100%", marginTop: "5%" }} >{item.name}</Text>

                    </View>

                    {/* <View style={{ width: 100, height: height * 0.15, backgroundColor: "white" }}>
                            <View style={{ width: "100%", height: height * 0.1, backgroundColor: "#f3f7ff", margin: 5, borderRadius: width * 0.02 }}>
                                <Image style={{ width: "80%", height: "80%", resizeMode: "contain", alignSelf: "center", marginTop: "5%", marginBottom: "5%" }} source={item.image1} />
                            </View>
                            <Text style={{ color: "black", fontFamily: "Roboto-Medium", fontSize: width * 0.030, textAlign: "center", width: "100%", marginTop: "5%" }} >{item.title1}</Text>

                        </View> */}
                </View>
                </ Pressable>
            )
            }
        />
            )
}
            const styles = StyleSheet.create({
                conatiner: {
                width: width,
            height: height * 0.01,
            backgroundColor: "#d3d3d33d"
    }
})