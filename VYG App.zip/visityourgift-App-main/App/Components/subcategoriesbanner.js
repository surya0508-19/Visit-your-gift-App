
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
export default function Subcategoriesbanner (props,navigation) {
    const {width,height} = Dimensions.get("window")
    const DATA = [
        {
          id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
          title: 'First Item',
          image:require('../Assets/lays.jpg')
        },
        {
          id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
          title: 'Second Item',
          image:require('../Assets/rice1.png')
        },
        {
          id: '58694a0f-3da1-471f-bd96-145571e29d72',
          title: 'Third Item',
          image:require('../Assets/grocerybanner.jpg')
        },
      ];
return(
    <SwiperFlatList
      autoplay
      autoplayDelay={2}
      autoplayLoop
      index={2}
      paginationDefaultColor={"#b3b3b3"}
      paginationActiveColor={"black"}
      paginationStyleItem={{width:width*0.015,height:height*0.008,top:"10%"}}
      data={DATA}
      showPagination={true}
      renderItem={({item}) => (
         <Card style={{width:width*0.75,height:height*0.245,marginLeft:width*0.02,marginRight:width*0.02,marginTop:5}} >
          <Image style={{width:"100%",height:"100%"}} source={item.image}  />
         </Card>
      )}
    />
)
}