import React, { useState, useEffect, Component } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Modal, TextInput, StyleSheet, FlatList } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar';
import { countSelector } from '../Slices/count';
import Menuoptions from './Menuoptions'
import { getmodel, modelSelector } from '../Slices/model';
import Carthelp from './carthelp';
import { ScrollView } from 'react-native-gesture-handler';
import { RecentAddress, Savedaddress } from '../Screens/TestData/data';
import { Menu, MenuOptions, MenuOption, MenuTrigger } from 'react-native-popup-menu';
import { MenuProvider } from 'react-native-popup-menu';

const { width, height } = Dimensions.get("window")
export default function SearchLocation(props, navigation) {
    const { model } = useSelector(modelSelector)
    const { count } = useSelector(countSelector);
    const dispatch = useDispatch()
    useEffect(() => {
        setActive(props.dataParentToChild)
    }, [])

    const [active, setActive] = useState(false)

    const data = "rgba(52, 52, 52, 0.8)"
    const modelclose = () => {
        dispatch(getmodel(false))
    }

    const onMenuSelect = () => {

    }
    return (

        <Modal
            animationType="slide"
            transparent={true}
            visible={model}>
            <Statusbar dataParentToChild={data} />
            <View style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)" }} >
                <View onStartShouldSetResponder={() => modelclose()} style={{ width: "100%", height: "15%", justifyContent: "center" }} >
                    <TouchableOpacity onPress={() => modelclose()} style={{ width: width * 0.11, height: height * 0.055, backgroundColor: "black", borderRadius: width * 0.07, alignSelf: "center", justifyContent: "center" }} >
                        <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../Assets/reject.png')} />
                    </TouchableOpacity>
                </View>
                <View style={{ width: width, height: "85%", }} >


                    <Card style={style.container} >
                        <ScrollView>
                            <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "2.5%", }} >Select a location</Text>
                            <View style={{ width: width * 0.87, height: height * 0.0575, borderColor: "gray", borderWidth: width * 0.001, alignSelf: "center", marginTop: "5%", borderRadius: width * 0.015, flexDirection: "row" }} >
                                <View style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                                    <Image style={{ width: '45%', height: "45%", resizeMode: "contain", alignSelf: "center" }} source={require('../Assets/search.png')} />
                                </View>
                                <View style={{ width: "85%", height: "100%", }} >
                                    <TextInput
                                        style={{ fontSize: width * 0.04, fontFamily: "Roboto-Light" }}
                                        placeholder='Start typing to search...' />
                                </View>

                            </View>

                            <TouchableOpacity style={{ width: width * 0.95, height: height * 0.08, marginTop: "5%", alignItems: "center", flexDirection: "row", borderBottomWidth: width * 0.001, borderColor: 'gray', alignSelf: "center" }} >
                                <View style={{ width: "12.5%", height: "100%", justifyContent: "center" }} >
                                    <Image style={{ width: '45%', height: "45%", resizeMode: "contain", alignSelf: "center" }} source={require('../Assets/location.png')} />
                                </View>

                                <View style={{ width: "75%", height: "100%", justifyContent: "center" }} >
                                    <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0425, color: "#00a4ff" }} >Use current location</Text>
                                </View>
                                <View style={{ width: "12.5%", height: "100%", justifyContent: "center" }} >
                                    <Image style={{ width: '40%', height: "40%", resizeMode: "contain", alignSelf: "center" }} source={require('../Assets/rightward.png')} />
                                </View>
                            </TouchableOpacity>

                            <Text style={{ fontFamily: "Roboto-Bold", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "5%", }} >Saved addresses</Text>
                            <View style={{ marginTop: "2.5%" }} >
                                <FlatList
                                    data={Savedaddress}
                                    renderItem={({ item }) => (


                                        <View style={{ width: "95%", height: height * 0.1, alignSelf: "center", borderBottomWidth: width * 0.001, borderColor: "gray", flexDirection: "row", alignItems: "center" }} >
                                            <View style={{ width: "17.5%", height: "90%", alignItems: "center", justifyContent: "space-evenly", }} >
                                                <Image style={{ width: '30%', height: "30%", resizeMode: "contain", alignSelf: "center" }} source={item.Type == "Home" ? require('../Assets/home2.png') : item.Type == "Office" ? require('../Assets/office.png') : require('../Assets/adlocation.png')} />
                                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black" }} >{item.distance}km</Text>
                                            </View>
                                            <View style={{ width: "65%", height: "auto", }} >
                                                <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.0425, }} >{item.Type}</Text>
                                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", marginLeft: "2.5%", }} >{item.address}</Text>
                                            </View>
                                            <View style={{ width: "17.5%", height: "100%", justifyContent: "center" }} >
                                                {/* <MenuProvider>
                                                    <Menuoptions /> */}
                                                    <View style={{ width: "42.5%", height: "35%", backgroundColor: "white", borderRadius: width * 0.1, alignSelf: "center", borderWidth: width * 0.001, borderColor: "gray", alignItems: "center", flexDirection: "row", justifyContent: "center" }} >
                                                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
                                                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
                                                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>

                                                        </View>


                                                {/* </MenuProvider> */}
                                            </View>
                                        </View>
                                    )
                                    }
                                />
                            </View>

                            <Text style={{ fontFamily: "Roboto-Bold", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "5%", }} >Recent Locations</Text>
                            <View style={{ marginTop: "2.5%" }} >
                                <FlatList
                                    data={RecentAddress}
                                    renderItem={({ item }) => (


                                        <View style={{ width: "95%", height: height * 0.1, alignSelf: "center", borderBottomWidth: width * 0.001, borderColor: "gray", flexDirection: "row", alignItems: "center" }} >
                                            <View style={{ width: "17.5%", height: "90%", alignItems: "center", justifyContent: "space-evenly", }} >
                                                <Image style={{ width: '35%', height: "35%", alignSelf: "center" }} source={require('../Assets/time.png')} />
                                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black" }} >{item.distance}km</Text>
                                            </View>
                                            <View style={{ width: "82.5%", height: "auto", }} >

                                                <Text numberOfLines={2} style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", marginLeft: "2.5%", }} >{item.address}</Text>
                                            </View>

                                        </View>
                                    )
                                    }
                                />
                            </View>
                        </ScrollView>
                    </Card>
                </View>
            </View>
        </Modal>

    )

}
const style = StyleSheet.create({
    container: {
        width: width,
        height: "100%",
        backgroundColor: "white",
        // borderRadius:width*0.035,
        position: "absolute",
        bottom: 0,
        borderTopLeftRadius: width * 0.035,
        borderTopRightRadius: width * 0.035,
        // top:"11.25%"
    },
    container1: {
        width: width,
        height: height * 0.6,
        backgroundColor: "white",
        position: "absolute",
        bottom: 0,
        borderRadius: width * 0.035
    }
})