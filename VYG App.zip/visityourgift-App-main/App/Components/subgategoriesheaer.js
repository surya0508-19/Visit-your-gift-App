
import { ModalPresentationIOS } from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/TransitionPresets';
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { getsubcatfilter, modelSelector } from '../Slices/model';


const { width, height } = Dimensions.get("window")
export default function Subcategoriesheader(props, navigation) {
  const dispatch = useDispatch()

  const getmodelon = () => {
    dispatch(getsubcatfilter(true))
  }

  return (
    <View style={{ width: "100%", height: height * 0.075, backgroundColor: "#f4f7fe", alignItems: "center", flexDirection: "row", justifyContent: "space-evenly" }} >
      <Card style={{ width: "90%", height: "70%" }} >
        <Pressable onPress={() => getmodelon()} style={{ width: "100%", height: "100%", flexDirection: "row", alignItems: "center" }} >
          <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
            <Text style={styles.title2} >Brand</Text>
          </View>
          <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
            <Image style={{ width: "40%", height: "40%", alignSelf: "center", resizeMode: "contain" }} source={require("../Assets/down.png")} />
          </View>
        </Pressable>

      </Card>
      {/* <Card style={{ width: "40%", height: "70%", }} >
        <Pressable onPress={() => getmodelon()} style={{ width: "100%", height: "100%", flexDirection: "row", alignItems: "center" }} >
          <View style={{ width: "70%", height: "100%", justifyContent: "center" }} >
            <Text style={styles.title2} >Type</Text>
          </View>
          <View style={{ width: "30%", height: "100%", justifyContent: "center" }} >
            <Image style={{ width: "40%", height: "40%", alignSelf: "center", resizeMode: "contain" }} source={require("../Assets/down.png")} />
          </View>
        </Pressable>
      </Card> */}
    </View>
  )

}

const styles = StyleSheet.create({
  conatiner: {
    width: width,
    height: height * 0.01,
    backgroundColor: "#d3d3d33d"
  },
  title2: {
    fontFamily: "Roboto-Regular",
    fontWeight: "600",
    fontSize: width * 0.0365,
    color: "black",
    marginLeft:"4%"
  },
})