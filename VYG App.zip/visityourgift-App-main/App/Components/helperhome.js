
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
const {width,height} = Dimensions.get("window")
export default function Helperhome (props,navigation) {
    
return(
   <View style={styles.conatiner} >

   </View>
)
}
const styles = StyleSheet.create({
    conatiner:{
        width:width,
        height:height*0.01,
        backgroundColor:"#d3d3d33d"
    }
})