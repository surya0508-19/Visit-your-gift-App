// FlipkartSuperCoinsGif.js
import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Image, Text } from 'react-native';
import Animated, { Easing } from 'react-native-reanimated';

const {
    Value,
    timing,
} = Animated;

const FlipkartSuperCoinsGif = () => {
    const [animationValue] = useState(new Value(0));

    useEffect(() => {
        const animation = timing(animationValue, {
            toValue: 1,
            duration: 2000,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
        });

        animation.start();
    }, [animationValue]);

    const opacity = animationValue.interpolate({
        inputRange: [0, 1],
        outputRange: [0, 1],
    });

    return (
        <View style={styles.container}>
            <Text style={styles.contentText}>Here is some background content</Text>
            <Animated.View style={[styles.gifContainer, { opacity }]}>
                <Image
                    style={styles.gif}
                    source={require("../Assets/output-onlinegiftools.gif")} // Replace with your GIF URL
                />
            </Animated.View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    contentText: {
        fontSize: 18,
        textAlign: 'center',
    },
    gifContainer: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -100 }, { translateY: -100 }], // Adjust based on GIF size
    },
    gif: {
        width: 200,
        height: 200,
    },
});

export default FlipkartSuperCoinsGif;
