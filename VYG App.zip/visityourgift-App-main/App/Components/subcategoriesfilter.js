import React, { useState, useEffect, Component } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Modal, TextInput, StyleSheet, FlatList, ToastAndroid, ScrollView, Keyboard } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar';
import { countSelector } from '../Slices/count';
import { getdetail, getmodel, getsubcatfilter, modelSelector } from '../Slices/model';
import Carthelp from './carthelp';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import CheckBox from '@react-native-community/checkbox';
import { activebrand, brandSelector, clearbrand, searchbrand, selectbrand, unclearbrand, updatebrandsts } from '../Slices/brand';
import { homedataSelector } from '../Slices/homedata';
import { categoriesproductSliceSelector, fetchcatproducts, updatemainloader, updatepagination } from '../Slices/categoriesproduct';
import { cartSelector } from '../Slices/cart';
import { authSelector } from '../Slices/auth';
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';

const { width, height } = Dimensions.get("window")
export default function Subcategoriesfilter(props, navigation) {
    const { brandsts, brands, active_brand } = useSelector(brandSelector)
    const { active_category } = useSelector(homedataSelector)
    const { cart_products } = useSelector(cartSelector)
    const { token } = useSelector(authSelector)
    const [active, setActive] = useState(false)
    const [boardshow, setBoardsetshow] = useState(false)
    const [search, setSearch] = useState('')
    const dispatch = useDispatch()
    const { subcategoriesfilter } = useSelector(modelSelector)
    const { states } = useSelector(categoriesproductSliceSelector)
    console.log("states", states)

    const [select, setSelect] = useState(-1)
    const [countryid, setcountryid] = useState("")
    const [stateid, setstateid] = useState("")
    const [price_filter, setprice_filter] = useState("")

    const [selectState, setselectState] = useState(-1)

    const [radioindex, setradioindex] = useState(-1)

    const data = 'rgba(52, 52, 52, 0.8)'
    useEffect(() => {

    }, [brands])

    useEffect(() => {

        const keyboardDidShowListener = Keyboard.addListener(
            'keyboardDidShow',
            () => {
                setBoardsetshow(true)
            }
        );

        const keyboardDidHideListener = Keyboard.addListener(
            'keyboardDidHide',
            () => {
                setBoardsetshow(false) // or some other action
            }
        );

        return () => {
            keyboardDidHideListener.remove();
            keyboardDidShowListener.remove();
        };
    }, [])

    const modelclose = () => {
        dispatch(updatebrandsts(false))
        //    console.log("activebrand",active_brand)
        //         var data ={
        //             cat_id:active_category.id,
        //             page:1,
        //             cartdata:cart_products,
        //             brand:active_brand,
        //             type:''
        //         }
        //         dispatch(fetchcatproducts(data))
    }

    const Change = (value, index, id) => {

        console.log("ccccccc", id)
        setSelect(index)
        setcountryid(id)
        setselectState(-1)
        setstateid("")
        var data = {
            cat_id: active_category.id,
            page: 1,
            cartdata: cart_products,
            brand: id,
            type: '',
            token: token,
            state: "",
            sort: ""


        }
        dispatch(fetchcatproducts(data))


        // console.log("index",index)
        // dispatch(selectbrand(index))
        //  dispatch(updatepagination())

    }

    const Change11 = (value, index, id) => {

        setstateid(id)
        setselectState(index)

        // console.log("index",index)
        // dispatch(selectbrand(index))
        //  dispatch(updatepagination())

    }
    const searchvalidate = (text) => {
        var data = {
            id: active_category.id,
            name: text,
            oldata: brands
        }

        dispatch(searchbrand(data))
        setSearch(text)
    }

    const apply = () => {
        dispatch(updatepagination())
        var filter = brands.filter(e => {
            if (e.active)
                return e
        })
        var filterarr = filter.map(e => e.id)
        var data = {
            cat_id: active_category.id,
            page: 1,
            cartdata: cart_products,
            brand: countryid,
            type: '',
            token: token,
            state: stateid,
            sort: price_filter
        }
        dispatch(fetchcatproducts(data))
        // dispatch(activebrand(filterarr))
        dispatch(updatebrandsts(false))
    }
    const clear = () => {
        dispatch(updatepagination())
        dispatch(unclearbrand(brands))
        var data = {
            cat_id: active_category.id,
            page: 1,
            cartdata: cart_products,
            type: '',
            token: token,
            brand: "",
            state: "",
            sort: ""
        }
        dispatch(fetchcatproducts(data))

        setstateid("")
        setcountryid("")
        setSelect(-1)
    }


    const onSelect = (index, value) => {
        setradioindex(index)

        console.log("value", value)

        setprice_filter(value)

    }


    return (

        <Modal
            animationType="slide"
            transparent={true}
            visible={brandsts}

        >
            <Statusbar dataParentToChild={data} />
            <View style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)" }} >
                <View onStartShouldSetResponder={() => modelclose()} style={{ width: width, height: "25%", }} >
                    <TouchableOpacity onPress={() => modelclose()} style={style.colse} >
                        <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../Assets/reject.png')} />
                    </TouchableOpacity>
                </View>
                <View style={{ width: width, height: "75%", }} >
                    <ScrollView>
                        <Card style={style.container} >


                            <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "3%", }} >Price Filter</Text>
                            <View style={{ justifyContent: "center", width: "100%", marginTop: "5%", borderWidth: width * 0.002, borderColor: "gray", flexDirection: "row" }} >




                                <RadioGroup
                                    style={{ width: "80%", alignSelf: "center", justifyContent: "space-between" }}
                                    formHorizontal={true}
                                    labelHorizontal={true}
                                    color="#00a4ff"
                                    size={width * 0.05}
                                    thickness={width * 0.004}
                                    selectedIndex={radioindex}
                                    onSelect={(index, value) => onSelect(index, value)}
                                >
                                    <RadioButton value={'lowtohigh'} style={{ alignItems: 'center' }} >
                                        <View>
                                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "#00a4ff", marginLeft: "5%" }} >Low to High</Text>
                                        </View>
                                    </RadioButton>
                                    <RadioButton value={'hightolow'} style={{ alignItems: 'center' }} >
                                        <View>
                                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "#00a4ff", marginLeft: "5%" }} >High to Low</Text>
                                        </View>
                                    </RadioButton>
                                </RadioGroup>




                            </View>


                            <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "3%", }} >Country Filter</Text>
                            <View style={{ justifyContent: "center", width: "100%", height: height * 0.4, marginTop: "5%", borderWidth: width * 0.002, borderColor: "gray", flexDirection: "row" }} >
                                {brands.length > 0 ?
                                    <View style={{ width: "95%", height: "100%", }} >

                                        <View style={{ width: "100%", height: height * 0.53, marginTop: "2.5%", }} >

                                            <FlatList
                                                data={brands}
                                                renderItem={({ item, index }) => (
                                                    <View style={{ width: "100%", height: height * 0.06, marginTop: '1%', flexDirection: "row" }} >
                                                        <View style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                                                            <CheckBox
                                                                style={{ width: "80%", height: "80%", alignSelf: "center" }}
                                                                value={select == index}
                                                                onValueChange={(value) => Change(value, index, item.name)}
                                                            />
                                                        </View>

                                                        <View style={{ width: "70%", height: "100%", justifyContent: "center" }} >
                                                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "black", marginLeft: "3%" }} >{item.name}</Text>
                                                        </View>


                                                    </View>
                                                )
                                                }
                                            />



                                        </View>

                                    </View>
                                    :
                                    <View style={{ width: "100%", justifyContent: "center", alignItems: "center" }} >
                                        <Image style={{ width: width * 0.2, height: height * 0.2, resizeMode: "contain" }} source={require('../Assets/cloud.png')} />
                                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "black", }} >No brands found</Text>
                                    </View>}

                            </View>

                            {/* <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "3%", }} >State Filter</Text>
                            <View style={{ justifyContent: "center", width: "100%", height: height * 0.3, marginTop: "5%", borderWidth: width * 0.002, borderColor: "gray", flexDirection: "row" }} >
                                {states.length > 0 ?
                                    <View style={{ width: "95%", height: "100%", }} >



                                        <View style={{ width: "100%", height: height * 0.53, marginTop: "2.5%", }} >

                                            <FlatList
                                                data={states}
                                                renderItem={({ item, index }) => (
                                                    <View style={{ width: "100%", height: height * 0.06, marginTop: '1%', flexDirection: "row" }} >
                                                        <View style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                                                            <CheckBox
                                                                style={{ width: "80%", height: "80%", alignSelf: "center" }}
                                                                value={selectState == index}
                                                                onValueChange={(value) => Change11(value, index, item.id)}
                                                            />
                                                        </View>

                                                        <View style={{ width: "70%", height: "100%", justifyContent: "center" }} >
                                                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "black", marginLeft: "3%" }} >{item.type}</Text>
                                                        </View>


                                                    </View>
                                                )
                                                }
                                            />



                                        </View>

                                    </View>
                                    :
                                    <View style={{ width: "100%", justifyContent: "center", alignItems: "center" }} >
                                        <Image style={{ width: width * 0.2, height: height * 0.2, resizeMode: "contain" }} source={require('../Assets/cloud.png')} />
                                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "black", }} >No states found</Text>
                                    </View>}

                            </View> */}



                            {brands.length > 0 ?
                                <View style={{ width: "100%", height: height * 0.09, flexDirection: "row", alignItems: "center", justifyContent: "space-evenly" }}  >
                                    <TouchableOpacity onPress={() => clear()} style={{ width: "45%", backgroundColor: "white", height: "80%", borderRadius: width * 0.02, justifyContent: "center", borderWidth: width * 0.002, borderColor: "#00a4ff" }} >
                                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "#00a4ff", textAlign: "center" }} >Clear Filter</Text>
                                    </TouchableOpacity>

                                    <TouchableOpacity onPress={() => apply()} style={{ width: "45%", backgroundColor: "#00a4ff", height: "80%", borderRadius: width * 0.02, justifyContent: "center" }} >
                                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, color: "white", textAlign: "center" }} >Apply</Text>
                                    </TouchableOpacity>

                                </View> : null}
                        </Card>
                    </ScrollView>
                </View>
            </View>

        </Modal>

    )

}
const style = StyleSheet.create({
    container: {
        width: width,
        height: "100%",
        backgroundColor: "white",
        borderRadius: width * 0.035,
        // top:"23.25%"
    },
    container1: {
        width: width,
        height: height * 0.75,
        backgroundColor: "white",
        top: "2%",
        borderRadius: width * 0.035
    },

    colse: {
        width: width * 0.11,
        height: height * 0.055,
        backgroundColor: "black",
        borderRadius: width * 0.07,
        // top:"20%",
        alignSelf: "center",
        justifyContent: "center",
        position: "absolute",
        bottom: "10%"
    },
    colse1: {
        width: width * 0.11,
        height: height * 0.055,
        backgroundColor: "black",
        borderRadius: width * 0.07,

        alignSelf: "center",
        justifyContent: "center"
    },


    title1: {
        fontFamily: "Roboto-Medium",
        fontWeight: "600",
        fontSize: width * 0.0425,
        color: "black",
        marginTop: "3%",
        marginLeft: "3%"
    },
    text: {
        fontFamily: "Roboto-Light",
        fontWeight: "600",
        fontSize: width * 0.0375,
        color: "black",
        marginTop: "1%",
        marginLeft: "3%",
        width: "95%"
    },
    youmight_container: {
        width: width,
        height: height * 0.425,
        marginBottom: "25%"
    },
    youmight_container1: {
        width: width,
        height: height * 0.425,
        marginBottom: "5%"
    },
    left_text: {
        fontFamily: "Roboto-Regular",
        fontSize: width * 0.043,
        color: "black",
        marginLeft: "10%"
    },
    left_text1: {
        fontFamily: "Roboto-Bold",
        fontSize: width * 0.043,
        color: "#00a4ff",
        marginLeft: "10%"
    }
})