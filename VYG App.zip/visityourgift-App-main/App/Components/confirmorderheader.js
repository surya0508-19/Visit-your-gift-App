import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import {useDispatch, useSelector} from 'react-redux';
import { countSelector,getcount} from '../Slices/count';
const {width,height} = Dimensions.get("window")
export default function Confirmorderheader (props,navigation) {
  return(
    <View style={{width:width,height:"20%",backgroundColor:"#00a4ff"}} >
       <View style={{width:width,height:"30%",flexDirection:"row",alignItems:"center",marginTop:"5%"}} >
         <TouchableOpacity onPress={() => props.Back() } style={{width:"15%",height:"100%",justifyContent:"center"}} >
         <Image style={styles.back} source={require("../Assets/leftwhite.png")} />
         </TouchableOpacity>

         <View style={{width:"70%",height:"100%",justifyContent:"center"}} >
         <Text style={{fontFamily:"Roboto-Regular",fontSize:width*0.04,textAlign:"center",color:"white"}} >Express store</Text>
         {/* <Text style={{fontFamily:"Roboto-Regular",fontSize:width*0.0375,textAlign:"center",color:"white"}} >KK nagar madurai</Text> */}
        </View>
       </View>

       <View style={{width:width,height:"50%",alignItems:"center",justifyContent:"space-evenly",}} >
       <Text style={{fontFamily:"Roboto-Bold",fontSize:width*0.07,textAlign:"center",color:"white"}} >Order is confirmed</Text>
            {/* <View style={{width:"50%",backgroundColor:"#3c8c51",height:"40%",borderRadius:width*0.015,justifyContent:"center"}} >
            <Text style={{fontFamily:"Roboto-Regular",fontSize:width*0.042,textAlign:"center",color:"white"}} >Arriving in 15 minutes</Text>
            </View> */}
        </View>

       
    </View>
  )
}
const styles = StyleSheet.create({
  back:{
     width:width*0.055,
     height:height*0.035,
     alignSelf:"center", 
  },
  })