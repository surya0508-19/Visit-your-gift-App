
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar/index';
export default function Helper (props,navigation) {
    const {width,height} = Dimensions.get("window")
    return(
        <View style={{width:width,height:height*0.03}} >

        </View>
    )
}