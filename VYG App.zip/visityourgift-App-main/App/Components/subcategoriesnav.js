
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { brandSelector, updatebrandsts } from '../Slices/brand';
import { getsubcatfilter } from '../Slices/model';

const { width, height } = Dimensions.get("window")
export default function Subcategoriesnav(props, navigation) {
    const{active_brand} = useSelector(brandSelector)
    const dispatch = useDispatch()
    const getmodelon = () => {
        dispatch(updatebrandsts(true))
    }
    return (
        <View style={{ width: "100%", height:"8%", backgroundColor: "#00a4ff", flexDirection: 'row', alignItems: "center", justifyContent: "space-evenly" }} >
            <Card style={{ width: "90%", height: "70%" }} >
                <Pressable onPress={() => getmodelon()} style={{ width: "100%", height: "100%", flexDirection: "row", alignItems: "center" }} >
                    <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                       {/* {active_brand.length > 0 ?
                       <Text style={styles.title2} >Brand ({active_brand.length})</Text>:
                        <Text style={styles.title2} >Brand</Text>} */}
                        <Text style={styles.title2} >All Filters</Text>
                    </View>
                    <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "40%", height: "40%", alignSelf: "center", resizeMode: "contain" }} source={require("../Assets/down.png")} />
                    </View>
                </Pressable>

            </Card>
            {/* <Card style={{ width: "40%", height: "70%", }} >
                <Pressable onPress={() => getmodelon()} style={{ width: "100%", height: "100%", flexDirection: "row", alignItems: "center" }} >
                    <View style={{ width: "70%", height: "100%", justifyContent: "center" }} >
                        <Text style={styles.title2} >Type</Text>
                    </View>
                    <View style={{ width: "30%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "40%", height: "40%", alignSelf: "center", resizeMode: "contain" }} source={require("../Assets/down.png")} />
                    </View>
                </Pressable>
            </Card> */}
        </View>
    )

}

const styles = StyleSheet.create({
    conatiner: {
        width: width,
        height: height * 0.01,
        backgroundColor: "#d3d3d33d"
    },
    title2: {
        fontFamily: "Roboto-Medium",
        fontWeight: "600",
        fontSize: 16,
        color: "grey",
        marginLeft:"4%"
    },
})