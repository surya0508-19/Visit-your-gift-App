import React, { useState, useEffect, Component } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Modal, TextInput, StyleSheet, FlatList } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar';
import { countSelector } from '../Slices/count';
import { getdetail, getmodel, modelSelector, updatemodel } from '../Slices/model';
import Carthelp from './carthelp';
import { ScrollView } from 'react-native-gesture-handler';
import Toast from 'react-native-simple-toast';
import { Menu, MenuOptions, MenuOption, MenuTrigger } from 'react-native-popup-menu';
import { MenuProvider } from 'react-native-popup-menu';
import { Recommendedproduct } from '../Screens/TestData/data';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { categoriesproductSliceSelector, fetchcatproducts, upatecatpro_byaddpro, updatecatloader, update_cat_wishlist } from '../Slices/categoriesproduct';
import { IMAGE_URL_PRODUCTS } from '../Constants';
import { homedataSelector } from '../Slices/homedata';
import { addtocart, cartSelector, fetchcart, update_maincart } from '../Slices/cart';
import { authSelector } from '../Slices/auth';
import { fetchprodetail, updateloader } from '../Slices/productdetail';
import { Addwishlist, update_active_wishlist } from '../Slices/whishlist';
const { width, height } = Dimensions.get("window")
export default function Categoryproducts(props, navigation) {
  const { cart_products } = useSelector(cartSelector)
  const { categoriesproduct, max_count, current_count } = useSelector(categoriesproductSliceSelector)
  const { active_category } = useSelector(homedataSelector)
  const { token } = useSelector(authSelector)
  const dispatch = useDispatch()
  const [page, setPage] = useState(1)
  const [scrollBegin, setscrollBegin] = useState(false)

  const nextpage = () => {

    var update = Math.round(max_count / 16) + 1


    console.log("updateupdate", update)
    if (current_count < update) {
      var data = {
        cat_id: active_category.id,
        page: current_count + 1,
        cartdata: cart_products,
        token: token,
        brand: "",
        state: "",
        sort: ""

      }
      dispatch(updatecatloader(true))
      dispatch(fetchcatproducts(data))
      setPage(page + 1)
    }
  }
  const updatecart = (index, type, variantcount) => {



    if (token) {

      if (variantcount == 1) {

        var data = [...categoriesproduct]
        if (data[index].qty >= data[index].actual_qty && type == "increment") {
          Toast.show("You reached maximun stock", Toast.SHORT);
        }
        else {
          //update cart 
          dispatch(upatecatpro_byaddpro({ value: index, key: type }))

          if (type == "increment" && data[index].qty == 0) {

            var price = {
              productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price) * 1,
              cartlength: 1,
              type: "addtocart"
            }
            dispatch(update_maincart(price))
          }
          else if (data[index].qty > 0) {
            if (type == "increment") {
              var price = {
                productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price) * Number(1),
                cartlength: 0,
                type: type
              }
              dispatch(update_maincart(price))
            }
            else {
              var price = {
                productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price) * Number(-1),
                cartlength: (data[index].qty == 1 ? Number(-1) : Number(0)),
                type: type
              }
              dispatch(update_maincart(price))
            }
          }


          //update cart with api call
          var data = {
            "product_id": data[index].product_id,
            "product_variant_id": data[index].variant_id,
            "quantity": 1,
            "type": type
          }
          var payload = {
            data: data,
            token: token
          }
          dispatch(addtocart(payload))
          dispatch(fetchcart(token))
        }
      } else {

        detail(index)
      }

    }
    else {

      props.logincall()

    }



  }

  const detail = (index) => {
    var data = {
      type: "categorydata",
      status: true,
      wishlist: categoriesproduct[index].wishlist
    }
    dispatch(updatemodel(data))

    dispatch(updateloader(true))
    var data = [...categoriesproduct]
    var postdata = {
      id: data[index].product_id,
      cartdata: data,
      type: "prodetail"
    }
    console.log("token", token)
    if (token) {
      dispatch(fetchcart(token, postdata))

    }
    else {
      dispatch(fetchprodetail(postdata))
    }
    // dispatch(update_active_wishlist(data[index].wishlist))
  }

  const addwishlist = (index) => {

    if (token) {

      var data = {
        index: index,
        type: "cat_pro"
      }
      dispatch(update_cat_wishlist(data))

      if (categoriesproduct[index].wishlist) {
        var postdata = {
          id: categoriesproduct[index].product_id,
          token: token,
          type: 'remove'
        }
        dispatch(Addwishlist(postdata))
      }
      else {
        var postdata = {
          id: categoriesproduct[index].product_id,
          token: token,
          type: 'add'
        }
        dispatch(Addwishlist(postdata))
      }

    }

    else {


      props.logincall()

    }
  }
  return (
    <FlatList
      data={categoriesproduct}
      numColumns={2}
      onEndReachedThreshold={0.01}
      onEndReached={() => nextpage()}
      showsVerticalScrollIndicator={true}
      renderItem={({ item, index }) => (
        <Card style={{ width: width * 0.45, height: height * 0.3, marginTop: 5, marginLeft: 5, marginBottom: 5 }} >
          {/* <Pressable onPress={() => detail(index)} > */}

          <View style={{ width: "100%", height: "10%", flexDirection: "row" }} >
            <View style={{ width: "70%", height: "100%" }} >
              {(item.discount > 0) ?
                <View style={{ width: "60%", height: "80%", backgroundColor: "#538bf5", marginLeft: "5%", borderRadius: width * 0.01, justifyContent: "center" }} >
                  <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.028, textAlign: "center", color: "white" }} >{item.discount}% OFF</Text>
                </View> : null}
            </View>

            <TouchableOpacity onPress={() => addwishlist(index)} style={{ width: "30%", height: "100%", justifyContent: "center" }} >
              {!item.wishlist ?
                <Image style={{ width: "90%", height: "90%", resizeMode: "contain", alignSelf: "center", }} source={require("../Assets/heart1.png")} /> :
                <Image style={{ width: "90%", height: "90%", resizeMode: "contain", alignSelf: "center", }} source={require("../Assets/heart2.png")} />}
            </TouchableOpacity>

          </View>
          <TouchableOpacity style={{ height: "73%" }} onPress={() => detail(index)} >
            <View style={{ width: "100%", height: "75%", justifyContent: "center" }} >
              <Image style={{ width: "90%", height: "90%", alignSelf: "center", resizeMode: "contain" }} source={{ uri: `${IMAGE_URL_PRODUCTS}` + item.image }} />
            </View>
            <View style={{ width: "100%", height: "25%", }} >
              <Text numberOfLines={2} style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0335, color: "black", marginLeft: "5%" }} >{item.productname}</Text>
              <Text numberOfLines={2} style={{ fontFamily: "Roboto-Light", fontWeight: "600", fontSize: width * 0.0275, color: "black", marginLeft: "5%", marginTop: "2.5%" }} >({item.variant_value})</Text>
            </View>
          </TouchableOpacity>

          <View style={{ width: "100%", height: "17%", alignItems: "center", flexDirection: "row" }} >
            <View style={{ width: "40%", height: "100%", justifyContent: "center" }} >
              {item.offer_price > 0 ?
                <>
                  <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.0325, color: "black", marginLeft: "10%", textDecorationLine: 'line-through', color: "grey" }} >$ {parseFloat(item.price).toFixed(2)}</Text>
                </> :
                null}

              <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0325, color: "black", marginLeft: "10%" }} >$ {(item.offer_price > 0) ? parseFloat(item.offer_price).toFixed(2) : parseFloat(item.price).toFixed(2)}</Text>
            </View>

            <View style={{ width: "60%", height: "100%", justifyContent: "center" }} >




              {item.actual_qty > 0 ? (

                !item.check ? (
                  <TouchableOpacity onPress={() => updatecart(index, "increment", item.variant_count)} style={{ width: "90%", height: "70%", backgroundColor: "#f8fff8", alignSelf: "center", borderRadius: width * 0.01, borderWidth: width * 0.002, borderColor: "#00a4ff", justifyContent: "center" }} >
                    <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, textAlign: "center", color: "#00a4ff" }} >ADD</Text>
                  </TouchableOpacity>

                )
                  : (item.variant_count > 1 ? (

                    <TouchableOpacity onPress={() => updatecart(index, "increment", item.variant_count)} style={{ width: "90%", height: "70%", backgroundColor: "#f8fff8", alignSelf: "center", borderRadius: width * 0.01, borderWidth: width * 0.002, borderColor: "#00a4ff", justifyContent: "center" }} >
                      <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, textAlign: "center", color: "#00a4ff" }} >ADD</Text>
                    </TouchableOpacity>

                  )

                    :
                    (<View style={{ width: "90%", height: "70%", backgroundColor: "#00a4ff", alignSelf: "center", borderRadius: width * 0.01, alignItems: "center", flexDirection: "row" }} >
                      <Pressable onPress={() => updatecart(index, "decrement", item.variant_count)} style={{ width: "25%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "80%", height: "80%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/minus1.png')} />
                      </Pressable>

                      <View style={{ width: "50%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, textAlign: "center", color: "white" }} >{item.qty}</Text>
                      </View>

                      <Pressable onPress={() => updatecart(index, "increment", item.variant_count)} style={{ width: "25%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "80%", height: "80%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/plus1.png')} />
                      </Pressable>
                    </View>
                    )
                  )

              )
                : (

                  <Text style={{ fontSize: width * 0.035, color: "red", fontFamily: "Roboto-Medium", textAlign: "center" }} >out of stock</Text>


                )
              }

            </View>
          </View>
          {/* </Pressable> */}




        </Card>
      )}
    />
  )
}
const style = StyleSheet.create({
  container: {
    width: width,
    height: height * 0.875,
    backgroundColor: "white",
    borderRadius: width * 0.035,
    top: "11.25%"
  },
  container1: {
    width: width,
    height: height * 0.6,
    backgroundColor: "white",
    position: "absolute",
    bottom: 0,
    borderRadius: width * 0.035
  },
  title1: {
    fontFamily: "Roboto-Medium",
    fontWeight: "600",
    fontSize: width * 0.035,
    color: "black",
    marginLeft: "5%"
  },
  price_text: {
    fontFamily: "Roboto-Medium",
    fontWeight: "600",
    fontSize: width * 0.035,
    color: "black",
    marginLeft: "5%"
  },
  add_text: {
    fontFamily: "Roboto-Regular",
    fontWeight: "600",
    fontSize: width * 0.035,
    color: "#00a4ff",
    textAlign: "center"
  },
  text: {
    fontFamily: "Roboto-Light",
    fontWeight: "600",
    fontSize: width * 0.03,
    color: "black",
    marginTop: "1%",
    marginLeft: "5%",
    width: "95%"
  }
})