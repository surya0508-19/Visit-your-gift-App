import React, { useState, useEffect, Component } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Modal, TextInput, StyleSheet, FlatList, ToastAndroid } from 'react-native';

import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { homedataSelector } from '../Slices/homedata';
import { categoriesproductSliceSelector, updatepagination } from '../Slices/categoriesproduct';


const { width, height } = Dimensions.get("window")
export default function Productcategoryheader(props, navigation) {
    const dispatch = useDispatch()
    const { max_count } = useSelector(categoriesproductSliceSelector)
    const { active_category } = useSelector(homedataSelector)
    const back = () => {
        dispatch(updatepagination())
        props.backbutton()
    }
    return (

        <View style={{ width: width, height: "8%", backgroundColor: "#00a4ff", flexDirection: "row" }} >
            <Pressable onPress={() => back()} style={{ width: "15%", height: '100%', alignItems: "center", justifyContent: "center", }} >
                <Image style={style.back} source={require("../Assets/back-arrow.png")} />
            </Pressable>
            <View style={{ width: "65%", height: '100%', justifyContent: "center", }} >
                <Text style={style.text1} >{active_category.name}</Text>
                <Text style={style.text2} >{max_count} products</Text>
            </View>
            {/* <Pressable onPress={() =>  props.seachcall()}> */}
            <TouchableOpacity onPress={() => props.seachcall()} style={{ width: "20%", height: '100%', justifyContent: "center" }} >
                <Image style={style.search} source={require("../Assets/search.png")} />
            </TouchableOpacity>
            {/* </Pressable> */}
        </View>
    )

}
const style = StyleSheet.create({

    back: {
        width: width * 0.045,
        height: height * 0.025,
        alignSelf: "center",
    },
    text1: {
        fontSize: width * 0.0425,
        fontFamily: "Roboto-Bold",
        color: "white"
    },
    text2: {
        fontSize: width * 0.035,
        fontFamily: "Roboto-Light",
        color: "white"
    },
    search: {
        width: 22,
        height: 22,
        alignSelf: "center",
    },
})

