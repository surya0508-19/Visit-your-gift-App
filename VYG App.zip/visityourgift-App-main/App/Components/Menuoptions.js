import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import { useDispatch, useSelector } from 'react-redux';
import { countSelector, getcount } from '../Slices/count';
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
const { width, height } = Dimensions.get("window")
export default function Menuoptions(props, navigation) {
  return (
    <Menu onSelect={value => onMenuSelect(value, props.billing_address_id, props)}>
      <MenuTrigger style={{ padding: 5 }} >

        <View style={{ width: "50%", height: "78%", backgroundColor: "white", borderRadius: width * 0.1, alignSelf: "center", borderWidth: width * 0.001, borderColor: "gray", alignItems: "center", flexDirection: "row", justifyContent: "center" }} >
          <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
          <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
          <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>


        </View>

      </MenuTrigger>

      <MenuOptions  >
        <View style={{flex:1,backgroundColor:"#00a4ff",marginTop:"10%"}}>
          <MenuOption value={1} style={{ padding: 5, height: 30,}} >
            <View style={{   }} >
              <Text >Edit</Text>
            </View>
          </MenuOption>
          <MenuOption value={2} style={{ padding: 5, backgroundColor: "red", height: 30 }} >
            <View style={{ width: width * 0.30, height: height * 0.2 }}>
              <Text >Delete</Text>
            </View>
          </MenuOption>
          <MenuOption value={3} style={{ padding: 5, backgroundColor: "red", height: 30 }} >
            <View style={{ width: width * 0.30, height: height * 0.2 }} >
              <Text>Add New</Text>
            </View>
          </MenuOption>
        </View>
      </MenuOptions>

    </Menu>
  )
}
