
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { addtocart, cartSelector, fetchaddtionalcart, update_cart_products } from '../Slices/cart';
import { IMAGE_URL_PRODUCTS } from '../Constants';

const { width, height } = Dimensions.get("window")
export default function Checkoutproducts(props, navigation) {
   const dispatch = useDispatch()
   const { cart_products } = useSelector(cartSelector)
   return (
      <FlatList
         data={cart_products}
         renderItem={({ item, index }) => (
            <View style={{ width: "100%", height: height * 0.12, flexDirection: "row", marginTop: "2.5%" }} >
               <View style={{ width: "25%", height: "100%", alignItems: "center", justifyContent: "center" }} >
                  <View style={{ width: "90%", height: "90%", alignSelf: "center", borderWidth: width * 0.002, borderColor: "#ececec", borderRadius: width * 0.02, justifyContent: "center" }} >
                     <Image source={{ uri: `${IMAGE_URL_PRODUCTS}` + item.image }} style={{ width: "80%", height: "80%", alignSelf: "center", resizeMode: "contain" }} />
                  </View>
               </View>
               <View style={{ width: "50%", height: "100%", }} >
                  <Text numberOfLines={2} style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0375, color: "black", marginLeft: "5%", marginTop: "5%", width: "90%" }} >{item.productname}</Text>
                  <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.036, color: "black", marginLeft: "5%", marginTop: "1%" }} >{item.variant_value}</Text>
                  {item.offer_price > 0 ?
                     <View style={{ flexDirection: "row" }} >
                        <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.036, color: "black", marginLeft: "5%", marginTop: "1%" }} >({parseFloat(item.offer_price).toFixed(2)} x {item.qty})</Text>
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black", marginLeft: "5%", marginTop: "1%" }} >$ {parseFloat(item.offer_price * item.qty).toFixed(2)}</Text>
                     </View> :
                     <View style={{ flexDirection: "row" }} >
                        <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.036, color: "black", marginLeft: "5%", marginTop: "1%" }} >({parseFloat(item.price).toFixed(2)} x {item.qty})</Text>
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black", marginLeft: "5%", marginTop: "1%" }} >$ {parseFloat(item.price * item.qty).toFixed(2)}</Text>
                     </View>
                  }
               </View>

            </View>
         )}
      />
   )


}