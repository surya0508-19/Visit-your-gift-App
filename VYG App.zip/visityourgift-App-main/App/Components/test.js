import React, { useState, useEffect, Component } from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,Modal, TextInput,StyleSheet,FlatList} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar';
import { countSelector } from '../Slices/count';
import { getmodel, modelSelector } from '../Slices/model';
import Carthelp from './carthelp';
import { ScrollView } from 'react-native-gesture-handler';
import Toast from 'react-native-simple-toast';
import { Menu, MenuOptions, MenuOption, MenuTrigger} from 'react-native-popup-menu';
import {MenuProvider} from 'react-native-popup-menu';
import { Recommendedproduct } from '../Screens/TestData/data';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { productSelector } from '../Slices/product';
const {width,height}=Dimensions.get("window")

export default function test (props,navigation) {
   const {recommended} = useSelector(productSelector)

//    const [data,setData]=useState([])
//    useEffect(() => {
//     setData(recommended)
//    },[])
//    const [recommended,setRecommended]=useState([{
//     name:"Dairy milk silk",
//     quantity:"10 kg",
//     image:require("../Assets/product1.png"),
//     salesprice:150,
//     marketprice:170,
//     offer:"",
//     updatequantity:0,
//     active:false
//  },
//  {
//      name:"Dark Fantasy",
//      quantity:"250 g",
//      image:require("../Assets/product2.jpg"),
//      salesprice:35,
//      marketprice:40,
//      offer:4,
//      updatequantity:0,
//      active:false
//  },
//  {
//      name:"Parasoot oil",
//      quantity:"250 L",
//      image:require("../Assets/product3.png"),
//      salesprice:120,
//      marketprice:130,
//      offer:8,
//      updatequantity:0,
//      active:false
//  },
//  {
//      name:"Garnier men face wash",
//      quantity:"150 g",
//      image:require("../Assets/product4.png"),
//      salesprice:90,
//      marketprice:110,
//      offer:'',
//      updatequantity:0,
//      active:false
//  },

//  {
//      name:"Oreo Biscuit",
//      quantity:"20 g",
//      image:require("../Assets/product5.jpg"),
//      salesprice:25,
//      marketprice:30,
//      offer:'',
//      updatequantity:0,
//      active:false
//  },

//  {
//      name:"Basmathi Rice",
//      quantity:"5 kg ",
//      image:require("../Assets/Rice.jpg"),
//      salesprice:150,
//      marketprice:180,
//      offer:'',
//      updatequantity:0,
//      active:false
//  },])

  const addtocart = (index) => {
    // var data1=[...recommended]
    recommended[index].active=true
    recommended[index].updatequantity=recommended[index].updatequantity+1
    // setData(data)
    console.log("test",recommended[0])
  }

  return(
    <View style={{flex:1}} >
       <FlatList 
       data={recommended}
       numColumns={2}
       renderItem={({item,index}) => (
        <View style={{width:"50%",height:'auto',backgroundColor:"white",margin:0.75}} >
            <Pressable onPress={() => detail()} >
            <View style={{width:"100%",height:height*0.03,marginTop:"2.5%",flexDirection:"row"}} >
                <View style={{width:"70%",height:"100%"}} >
                {item.offer ?
              <View style={{width:"50%",height:height*0.025,backgroundColor:"#538bf5",borderRadius:width*0.0125,marginLeft:"5%",justifyContent:"center"}} >
               <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.028,textAlign:"center",color:"white"}} >{item.offer}% OFF</Text>
              </View>:null}
                </View>
{/* 
                <Pressable onPress={() => setValue(index) } style={{width:"30%",height:"100%",justifyContent:"center"}} >
                {!(value == index) ?
                <Image style={{width:"90%",height:"90%",resizeMode:"contain",alignSelf:"center",}} source={require("../Assets/heart1.png") }  />:
                <Image style={{width:"90%",height:"90%",resizeMode:"contain",alignSelf:"center",}} source={require("../Assets/heart2.png") }  />}
                </Pressable> */}
          
            </View>
              
            <View style={{width:"100%",height:height*0.2,justifyContent:"center",}} >
              <Image style={{width:"70%",height:"90%",alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={item.image} />
            
            </View>
          <Text style={{fontFamily:"Roboto-Medium",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.0375,marginTop:"5%"}} >{item.name}</Text>
          <Text style={{fontFamily:"Roboto-Light",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.035,marginTop:"2%"}} >{item.quantity}</Text>
          <View style={{flexDirection:"row",width:"60%",marginLeft:"5%",marginTop:"2%",}} >
          <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.035,}} >$ {item.salesprice}</Text>
          <Text style={{fontFamily:"Roboto-Light",fontWeight:"600",fontSize:width*0.035,textDecorationLine:"line-through",marginLeft:"5%"}} >$ {item.marketprice}</Text>
          </View>
          </Pressable>
           {!item.active ?
          <Pressable onPress={() => addtocart(index)} style={{width:"90%",height:height*0.045,backgroundColor:"#f8fff8",borderRadius:width*0.025,alignSelf:"center",marginTop:"5%",marginBottom:"5%",borderWidth:width*0.003,borderColor:"#00a4ff",justifyContent:"center"}} >
          <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.0375,textAlign:"center",color:"#00a4ff"}} >ADD</Text>
          </Pressable>:
          <View onPress={() => addtocart(index)} style={{width:"90%",height:height*0.045,backgroundColor:"#00a4ff",borderRadius:width*0.025,alignSelf:"center",marginTop:"5%",marginBottom:"5%",justifyContent:"center",flexDirection:"row"}} >
              <TouchableOpacity onPress={() => updatecart('decrementent',index,count.cartlength,count.price) } style={{width:"20%",height:"100%",justifyContent:"center"}} >
              <Image style={{width:"37.5%",height:"37.5%",margin:5,alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={require('../Assets/minus.png')} />
            </TouchableOpacity>

              <View style={{width:"60%",height:"100%",justifyContent:"center"}} >
              <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.04,textAlign:"center",color:"white"}} >{item.updatequantity}</Text>
              </View>

              <TouchableOpacity onPress={() => updatecart('increment',index,count.cartlength,count.price) } style={{width:"20%",height:"100%",justifyContent:"center"}} >
              <Image style={{width:"40%",height:"40%",margin:5,alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={require('../Assets/plus.png')} />
              </TouchableOpacity>
          </View>}


         </View>
       )
    }
/> 

    </View>
  )

}