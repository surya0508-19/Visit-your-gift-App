import React, { useState, useEffect, Component } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Modal, Share, StyleSheet, FlatList, ToastAndroid, ActivityIndicator, Pressable, Linking } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar';
import { countSelector } from '../Slices/count';
import { getdetail, getmodel, modelSelector, updatemodel } from '../Slices/model';
import Carthelp from './carthelp';
import { ScrollView } from 'react-native-gesture-handler';
import { productpics } from '../Screens/TestData/data';
import { Menu, MenuOptions, MenuOption, MenuTrigger } from 'react-native-popup-menu';
import { MenuProvider } from 'react-native-popup-menu';
import Similarproducts from './similarproducts';
import Toast from 'react-native-simple-toast';

import RadioButtonRN from 'radio-buttons-react-native';
import { productdetailSelector } from '../Slices/productdetail';
import { IMAGE_URL_PRODUCTS } from '../Constants';
import { categoriesproductSliceSelector, update_cat_wishlist } from '../Slices/categoriesproduct';
import { authSelector } from '../Slices/auth';
import { addtocart, cartSelector, fetchcart } from '../Slices/cart';
import { Addwishlist, deletewishlist, wishlistSelector } from '../Slices/whishlist';
import { update_search_wishlist } from '../Slices/searchproducts';
import { update_wish_buy } from '../Slices/buyagainlist';
import RenderHtml from 'react-native-render-html';

const { width, height } = Dimensions.get("window")
export default function Productdetail(props, navigation) {
  const { modelshow, type } = useSelector(modelSelector)
  const [whishlist, setWishlist] = useState(false)
  const [moredetail, setMoredetail] = useState(false)
  const { productdeail, attributes, detailsts, first_element } = useSelector(productdetailSelector)
  const { token } = useSelector(authSelector)
  const { cart_products, cart_length } = useSelector(cartSelector)
  const { categoriesproduct } = useSelector(categoriesproductSliceSelector)
  const [qty, setQty] = useState(0)
  const dispatch = useDispatch()
  const [selctindex, setSelctindex] = useState(0)
  const { active_wishlist } = useSelector(modelSelector)



  const [check, setCheck] = useState(false)

  console.log("productdeail", productdeail)

  useEffect(() => {
    validate()
  }, [selctindex, detailsts])

  // useEffect(() => {
  //   if (productdeail) {
  //     var output = wishlist_products.find(e => e.product_id == productdeail.id)
  //     if (output) {
  //       setWishlist(true)
  //     }
  //   }
  // }, [productdeail])

  useEffect(() => {
    setWishlist(active_wishlist)
  }, [active_wishlist])


  const validate = () => {
    if (attributes.length) {
      if (cart_products.length) {
        var quantity = cart_products.find(e => e.variant_id == attributes[selctindex].id)
        if (quantity) {
          setActive(true)
          setQty(quantity.qty)
        }
        else {
          setActive(false)
          setQty(0)
        }
      }

    }
  }

  const [active, setActive] = useState(false)

  const data = "rgba(52, 52, 52, 0.8)"
  const modelclose = () => {
    setWishlist(false)
    setMoredetail(false)


    var data = {
      type: "",
      status: false
    }
    dispatch(updatemodel(data))
    setQty(0)
    setActive(false)
    setSelctindex(0)

  }


  const data1 = [
    {
      label: '2 X 200g   out of stock '
    },
    {
      label: '200g                  $ 26 '
    }
  ];

  const addwhislist = (value) => {
    if (token) {

      if (value) {
        setWishlist(false)
        var data = {
          id: productdeail.id,
          token: token,
          type: "remove"
        }
        dispatch(Addwishlist(data))
        dispatch(fetchcart(token))
      }
      else {
        setWishlist(true)
        var data = {
          id: productdeail.id,
          token: token,
          type: "add"
        }
        dispatch(Addwishlist(data))
        dispatch(fetchcart(token))
      }

      var data1 = {
        index: productdeail.id,
        type: "details"
      }
      dispatch(update_cat_wishlist(data1))
      dispatch(update_search_wishlist(productdeail.id))
      dispatch(update_wish_buy(productdeail.id))

    } else {

      Logincall()
    }
  }

  const viewphotos = () => {
    // alert("tset")
    dispatch(getdetail(false))
    props.viewdetailcall()

  }


  const Logincall = () => {
    Toast.show("Please Login to Purchase", Toast.SHORT);

  }




  const updatecart = (type) => {
    if ((qty >= attributes[selctindex].quantity) && type == "increment") {
      Toast.show("You reached maximun stock", Toast.SHORT);
    }
    else {

      if (type == "increment" && qty == 0) {
        setQty(qty + 1)
        setActive(true)
      }
      else if (type == 'increment' && qty > 0) {
        setQty(qty + 1)
        setActive(true)
      }
      else {
        if (qty == 1) {
          setActive(false)
          setQty(0)
        }
        else {
          setQty(qty - 1)
        }
      }


      //update cart with api call
      var data = {
        "product_id": productdeail.id,
        "product_variant_id": attributes[selctindex].id,
        "quantity": 1,
        "type": type
      }
      var payload = {
        data: data,
        token: token
      }
      dispatch(addtocart(payload))
      dispatch(fetchcart(token))

      //update cat products 
      var catdata = [...categoriesproduct]
      var confict = catdata.findIndex(e => ((e.product_id == productdeail.id) && (e.variant_id == attributes[selctindex].id)))

      if (confict > -1) {
        if (qty == 1) {
          catdata[confict].qty = Number(0)
          catdata[confict].check = false
        }
        else {
          catdata[confict].qty = Number(qty + 1)
          catdata[confict].check = true
        }
      }

    }

  }

  const onShare = async () => {
    try {
      const result = await Share.share({
        title: 'App link',
        message: 'Please install this app and stay safe , AppLink :https://play.google.com/store/apps/details?id=com.snacks_ballons',
        url: 'https://play.google.com/store/apps/details?id=com.snacks_ballons'
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };

  return (

    <Modal
      animationType="slide"
      transparent={true}
      visible={modelshow}

    >
      <Statusbar dataParentToChild={data} />
      <View style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)" }} >

        <>
          <TouchableOpacity onPress={() => modelclose()} style={{ width: 45, height: 45, backgroundColor: "black", borderRadius: width * 0.07, top: "7%", alignSelf: "center", justifyContent: "center" }} >
            <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../Assets/reject.png')} />
          </TouchableOpacity>
          <Card style={style.container} >
            {!detailsts ?
              <ScrollView>

                <Card style={{ alignSelf: "center", width: width, height: height * 0.3, margin: width * 0.03, justifyContent: "center" }} >

                  <Pressable style={{ width: "100%", height: "100%", justifyContent: "center" }} >
                    <Image style={{ width: "60%", height: "60%", alignSelf: "center", resizeMode: "contain" }} source={{ uri: `${IMAGE_URL_PRODUCTS}` + productdeail.image }} />
                  </Pressable>

                </Card>
                <View style={{ width: width * 0.95, alignSelf: "center", height: height * 0.065, marginTop: "1%", flexDirection: "row", alignItems: "center", }} >
                  <View style={{ width: "85%", height: "100%", justifyContent: "center" }} >
                    {productdeail.name ?
                      <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.045, color: "black" }} >{productdeail.name}</Text> : null}
                  </View>
                  <View style={{ width: "15%", height: "100%", alignItems: "center", justifyContent: "center" }} >
                    <TouchableOpacity onPress={() => onShare()} style={{ width: "60%", height: "60%", borderRadius: width * 0.045, borderWidth: width * 0.001, borderColor: "gray", justifyContent: "center" }} >
                      <Image style={{ width: "50%", height: "50%", resizeMode: "contain", alignSelf: "center" }} source={require("../Assets/share.png")} />
                    </TouchableOpacity>
                  </View>
                </View>

                {/* <View style={{ width: width * 0.95, alignSelf: "center", height: height * 0.075, marginTop: "1%", flexDirection: "row", alignItems: "center", borderBottomWidth: width * 0.001, borderColor: "gray", }} >
                  <View style={{ width: "50%", height: "100%", justifyContent: "space-around", }} >
                    

                    <View style={{ flexDirection: "row" }}>
                      <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "black" }} >$ 10.00</Text>
                      <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "grey", textDecorationLine: "line-through", marginLeft: 20 }} >$ 20.00</Text>

                    </View>
                  </View>

                  <View style={{ width: "50%", height: "100%", justifyContent: "center", }} >
                    {!check ?
                      <TouchableOpacity onPress={() => setCheck(true)} style={{ width: "45%", height: "50%", alignSelf: "flex-end", borderRadius: width * 0.015, backgroundColor: "#f8fff8", borderColor: "#00a4ff", borderWidth: width * 0.001, justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >ADD</Text>
                      </TouchableOpacity>
                      :
                      <View style={{ width: "45%", height: "50%", backgroundColor: "#00a4ff", borderRadius: width * 0.01, alignSelf: "flex-end", marginTop: "5%", marginBottom: "5%", justifyContent: "center", flexDirection: "row" }} >
                        <TouchableOpacity style={{ width: "30%", height: "100%", justifyContent: "center" }} >
                          <Image style={{ width: "37.5%", height: "37.5%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/minus.png')} />
                        </TouchableOpacity>

                        <View style={{ width: "40%", height: "100%", justifyContent: "center" }} >
                          <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, textAlign: "center", color: "white" }} >1</Text>
                        </View>

                        <TouchableOpacity style={{ width: "30%", height: "100%", justifyContent: "center" }} >
                          <Image style={{ width: "40%", height: "40%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/plus.png')} />
                        </TouchableOpacity>
                      </View>
                    }

                  </View>
                </View> */}

                <View style={{ width: width * 0.95, alignSelf: "center", height: 'auto', flexDirection: "row" }} >

                  <FlatList
                    data={attributes}
                    // horizontal={false}
                    // numColumns={2}
                    renderItem={({ item, index }) => (
                      <>
                        {index == selctindex ?
                          <View style={{ borderWidth: 1, borderColor: "#00a4ff", alignItems: "center", height: 62, width: "60%", marginTop: 10, borderRadius: width * 0.01, margin: 5 }}>
                            <View style={{ height: 60, borderBottomWidth: 1, borderColor: "#00a4ff", alignItems: "center", width: "100%", flexDirection: 'row', }}>
                              <View style={{ width: "17%", height: height * 0.028, marginLeft: "3%", borderRadius: width * 0.05, borderWidth: 2.5, borderColor: "#00a4ff", justifyContent: "center", alignItems: "center" }}>
                                <View style={{ width: width * 0.025, height: height * 0.013, backgroundColor: "#00a4ff", marginLeft: "2%", borderRadius: width * 0.05, }}></View>
                              </View>

                              <View style={{ width: "83%", marginLeft: "3%" }}>
                                <Text style={{ fontSize: width * 0.035, fontFamily: "Roboto-Bold", color: "black", width: width, }}>({item.variant_value})</Text>
                                <View style={{ width: width * 0.25, flexDirection: "row", justifyContent: "space-between" }}>

                                  <Text style={{ fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "black", }}>$ {item.offer_price ? item.offer_price : item.price}</Text>
                                  {item.offer_price ?
                                    <Text style={{ textDecorationLine: "line-through", fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "grey", }}>${parseFloat(item.price).toFixed(2)}</Text> : null}
                                </View>
                              </View>
                            </View>
                            {/* <View style={{ height: 28, width: "100%", justifyContent: "center", alignItems: "center", backgroundColor: "#5b72b3" }}>
                              <Text style={{ fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "white", }}> {item.discount}% off</Text>
                            </View> */}

                          </View>


                          :

                          <View style={{ borderWidth: 1, borderColor: "#00a4ff", alignItems: "center", height: 62, width: "60%", marginTop: 10, borderRadius: width * 0.01, margin: 5 }}>
                            <TouchableOpacity onPress={() => setSelctindex(index)} style={{ width: "100%", height: "100%" }} >
                              <View style={{ height: 60, borderBottomWidth: 1, borderColor: "#00a4ff", alignItems: "center", width: "100%", flexDirection: 'row', }}>
                                <View style={{ width: "17%", height: height * 0.028, marginLeft: "3%", borderRadius: width * 0.05, borderWidth: 2.5, borderColor: "#00a4ff", justifyContent: "center", alignItems: "center" }}>

                                </View>

                                <View style={{ width: "83%", marginLeft: "3%" }}>
                                  <Text style={{ fontSize: width * 0.035, fontFamily: "Roboto-Bold", color: "black", width: width, }}>({item.variant_value})</Text>
                                  <View style={{ width: width * 0.25, flexDirection: "row", justifyContent: "space-between" }}>
                                    <Text style={{ fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "black", }}>${item.offer_price ? item.offer_price : item.price}</Text>
                                    {item.offer_price ?
                                      <Text style={{ textDecorationLine: "line-through", fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "grey", }}>${parseFloat(item.price).toFixed(2)}</Text> : null}
                                  </View>
                                </View>
                              </View>
                              {/* <View style={{ borderRadius: width * 0.05, height: 28, width: "100%", justifyContent: "center", alignItems: "center", backgroundColor: "#f8fff8" }}>
                                <Text style={{ fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "#00a4ff", }}> {item.discount}% off</Text>
                              </View> */}
                            </TouchableOpacity>
                          </View>}
                      </>
                    )}
                  />

                  {!token ? (
                    <TouchableOpacity onPress={() => Logincall()} style={{ width: "32.5%", height: height * 0.05, borderRadius: width * 0.015, backgroundColor: "#f8fff8", borderColor: "#00a4ff", borderWidth: width * 0.001, justifyContent: "center", marginLeft: "5%", marginTop: "5%" }} >
                      <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >ADD</Text>
                    </TouchableOpacity>


                  ) : (
                    !active ?
                      <TouchableOpacity onPress={() => updatecart("increment")} style={{ width: "32.5%", height: height * 0.05, borderRadius: width * 0.015, backgroundColor: "#f8fff8", borderColor: "#00a4ff", borderWidth: width * 0.001, justifyContent: "center", marginLeft: "5%", marginTop: "5%" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >ADD</Text>
                      </TouchableOpacity> :
                      <View style={{ width: "32.5%", height: height * 0.05, borderRadius: width * 0.015, backgroundColor: "#00a4ff", borderWidth: width * 0.001, marginLeft: "5%", marginTop: "5%", flexDirection: "row" }} >
                        <Pressable onPress={() => updatecart("decrement")} style={{ width: "25%", height: "100%", justifyContent: "center" }} >
                          <Image style={{ width: "60%", height: "60%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/minus1.png')} />
                        </Pressable>

                        <View style={{ width: "50%", height: "100%", justifyContent: "center" }} >
                          <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, textAlign: "center", color: "white" }} >{qty}</Text>
                        </View>

                        <Pressable onPress={() => updatecart("increment")} style={{ width: "25%", height: "100%", justifyContent: "center" }} >
                          <Image style={{ width: "60%", height: "60%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/plus1.png')} />
                        </Pressable>
                      </View>

                  )}

                </View>




                <View style={{ marginTop: "5%", marginLeft: "3%", width: "95%", alignItems: "center", flexDirection: "row", height: height * 0.05 }}>
                  <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "700", fontSize: width * 0.045, color: "black", width: "80%" }} >Product Details</Text>

                  <TouchableOpacity onPress={() => addwhislist(whishlist)} style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                    {!whishlist ?
                      <Image style={{ width: "50%", height: "50%", resizeMode: "contain", alignSelf: "center", }} source={require("../Assets/heart1.png")} /> :
                      <Image style={{ width: "50%", height: "50%", resizeMode: "contain", alignSelf: "center", }} source={require("../Assets/heart2.png")} />}
                  </TouchableOpacity>

                </View>
                {/* {productdeail.category.name ?
            <>
            <Text style={style.title1} >Category</Text>
            <Text style={style.text} >{productdeail.category.name}</Text>
            </>:null} */}

                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Text style={{
                    fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0425, color: "black", marginLeft: "3%"
                  }} >Product Code  :</Text>
                  <Text style={{ fontFamily: "Roboto-Light", fontWeight: "600", fontSize: width * 0.0375, color: "black", marginLeft: "2%", width: "95%" }}>{productdeail.product_id}</Text>
                </View>


                <Text style={style.title1} >Descrpition</Text>
                <View style={{ width: "100%", marginLeft: "3%", marginRight: "2%", }}>
                  <RenderHtml
                    contentWidth={10}
                    source={{
                      html: `${productdeail.description}`
                    }}
                  />

                </View>



                <View style={{ flexDirection: "row", alignItems: "center", marginTop: 5, }}>
                  <Text style={{

                    fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0425, color: "black", marginLeft: "3%"
                  }} >Pack Size       : </Text>
                  <Text style={{ fontFamily: "Roboto-Light", fontWeight: "600", fontSize: width * 0.0375, color: "black", marginLeft: "2%", width: "95%" }}>{first_element.variant_value}</Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", marginTop: 5, }}>
                  <Text style={{
                    fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0425, color: "black", marginLeft: "3%"
                  }} >Country          : </Text>
                  <Text style={{ fontFamily: "Roboto-Light", fontWeight: "600", fontSize: width * 0.0375, color: "black", marginLeft: "2%", width: "95%" }}>{productdeail.brand_name}</Text>
                </View>

                <View style={{ flexDirection: "row", alignItems: "center", marginTop: 5, }}>
                  <Text style={{
                    fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0425, color: "black", marginLeft: "3%"
                  }} >Product Life  : </Text>
                  <Text style={{ fontFamily: "Roboto-Light", fontWeight: "600", fontSize: width * 0.0375, color: "black", marginLeft: "2%", width: "95%" }}>{productdeail.unit_type}</Text>
                </View>
                <Pressable onPress={()=>Linking.openURL(`https://wa.me/${productdeail.whatsapp_no}`)}>
                  <Card style={{ flexDirection: "row", width: "90%", alignSelf: "center", height: 50, justifyContent: "center", alignItems: "center", backgroundColor: "green", marginBottom: "15%", marginTop: "2%" }}>
                    <Image style={{ height: 20, width: 20, resizeMode: "contain" }} source={require("../Assets/whatsapp.png")}></Image>
                    <Text style={{ fontSize: 17, fontWeight: "600", color: "white", marginLeft: 5 }}>Click Here Live Demo</Text>
                  </Card>
                </Pressable>
                {/* <>
                      <Text style={style.title1} >Stock availability</Text>
                      <Text style={style.text} >{productdeail.status == "inStack" ? "In stock" : "Out of stock"}</Text>
                    </> */}
                {/* 
                    <Text style={style.title1} >Selling Information</Text>
                    <Text style={style.text} >Foorti (p) ltd ,maharastra ,mumbai,954822</Text> */}

                {/* } */}
                {/* {type == "homedata" ?
                  <View style={{ width: width, height: height * 0.425, marginTop: "5%", marginBottom: "10%" }} >
                    <Text style={style.title1} >Similar Products</Text>
                    <Similarproducts />
                  </View> : null} */}

              </ScrollView>
              : <ActivityIndicator color={'black'} />}
          </Card>
        </>
      </View>
      {/* {cart_length >= 1 ?
        <Carthelp cartcall={() => cartfn()} /> : null} */}
    </Modal>

  )

}
const style = StyleSheet.create({
  container: {
    width: width,
    height: height * 0.9,
    backgroundColor: "white",
    borderRadius: width * 0.035,
    top: "8.75%"
  },
  container1: {
    width: width,
    height: height * 0.6,
    backgroundColor: "white",
    position: "absolute",
    bottom: 0,
    borderRadius: width * 0.035
  },
  title1: {
    fontFamily: "Roboto-Medium",
    fontWeight: "600",
    fontSize: width * 0.0425,
    color: "black",
    marginTop: "3%",
    marginLeft: "3%"
  },
  text: {
    fontFamily: "Roboto-Light",
    fontWeight: "600",
    fontSize: width * 0.0375,
    color: "black",
    marginTop: "1%",
    marginLeft: "3%",
    width: "95%"
  },
  youmight_container: {
    width: width,
    height: height * 0.425,
    marginBottom: "25%"
  },
  youmight_container1: {
    width: width,
    height: height * 0.425,
    marginBottom: "5%"
  }
})