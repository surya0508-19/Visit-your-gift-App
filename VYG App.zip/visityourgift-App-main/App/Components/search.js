import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar} from 'react-native';
import { Card } from 'react-native-shadow-cards';
export default function Search (props,navigation) {
    const {width,height}=Dimensions.get("window")
    return(
   
      <View style={{width:"100%",height:height*0.08,justifyContent:"center",bottom:"30%"}} >
           <Card style={{alignSelf:"center",width:"95%",height:"70%",backgroundColor:"white"}} >
              <TouchableOpacity onPress={() => props.Searchcalls()} style={{flexDirection:"row",alignItems:"center",width:"100%",height:"100%"}}  >
               <View style={{width:"15%",height:"100%",justifyContent:"center",}} >
               <Image source={require("../Assets/search.png")} style={{width:width*0.055,height:height*0.0275,alignSelf:"center"}} />
               </View>
               <View style={{width:"80%",height:"100%",justifyContent:"center"}} >
               <Text  style={{fontSize:width*0.0425,fontFamily:"Roboto-Light",}} >Search for atta,dal,coke and more</Text>
               </View>
               </TouchableOpacity>
            </Card>
      </View>

    )
}