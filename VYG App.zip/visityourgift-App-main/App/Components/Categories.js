
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { IMAGE_URL_CATEGORY } from '../Constants';
import { authSelector } from '../Slices/auth';
import { fetchcatbrand } from '../Slices/brand';
import { cartSelector, fetchcart } from '../Slices/cart';
import { fetchcatproducts, updatemainloader } from '../Slices/categoriesproduct';
import { homedataSelector, select_category, switch_cat_head } from '../Slices/homedata';

const { width, height } = Dimensions.get("window")
export default function Categories(props, navigation) {
    const dispatch = useDispatch()
    const { cart_products } = useSelector(cartSelector)
    const { categories, categorycount } = useSelector(homedataSelector)
    const { token } = useSelector(authSelector)
    const viewdetail = async (index) => {
        var savedata = categories[index]
        var data = [...categories]
        if (index > -1) {
            data.splice(index, 1);
        }
        data.unshift(savedata)
        dispatch(select_category(data))
        dispatch(switch_cat_head(categories[index]))
        dispatch(fetchcart(token))
        dispatch(fetchcatbrand(categories[index].id))
        var data = {
            cat_id: categories[index].id,
            page: 1,
            cartdata: cart_products,
            type: '',
            brand: "",
            state: "",
            sort: ""

        }
        dispatch(updatemainloader(true))
        dispatch(fetchcatproducts(data))
        props.Searchcall()
    }

    return (
        <FlatList
            data={categories}
            numColumns={2}
            renderItem={({ item, index }) => (

                <TouchableOpacity onPress={() => viewdetail(index)} style={{ width: "47%", borderRadius: width * 0.02, backgroundColor: "#FBF9F9", marginLeft: 5, height: height * 0.12, margin: 5, justifyContent: 'space-evenly' }} >
                    {/* <Pressable onPress={() => viewdetail(index)} style={{ width: "30%", height: height * 0.17, backgroundColor: "#f3f7ff", margin: 5, borderRadius: width * 0.02, justifyContent: 'space-evenly' }} >
                        <Text style={{ color: "black", fontFamily: "Roboto-Medium", fontSize: width * 0.035, textAlign: "center", width: "90%", marginTop: "5%", }} >{item.name}</Text>
                        <Image style={{ width: "50%", height: "50%", resizeMode: "contain", alignSelf: "center", marginTop: "5%", marginBottom: "5%" }} source={{ uri: `${IMAGE_URL_CATEGORY}` + item.image }} />
                    </Pressable> */}

                    <View style={{ backgroundColor: "#F1EFEF", height: 80, justifyContent: 'space-evenly', borderTopRightRadius: width * 0.02, borderTopLeftRadius: width * 0.02, }} >
                        <Image style={{ width: 100, height: 75, resizeMode: "contain", alignSelf: "flex-end", marginTop: "5%", marginBottom: "5%" }} source={{ uri: `${IMAGE_URL_CATEGORY}` + item.image }} />
                    </View>

                    <Text style={{ color: "black", fontFamily: "Roboto-Bold", fontSize: width * 0.035, width: "90%", marginBottom: 8, marginTop: 4, marginLeft: 6 }} >{item.name}</Text>

                </TouchableOpacity>
            )
            }
        />
    )
}
const styles = StyleSheet.create({
    conatiner: {
        width: width,
        height: height * 0.01,
        backgroundColor: "#d3d3d33d"
    }
})