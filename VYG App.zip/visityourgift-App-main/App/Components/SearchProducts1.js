
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { countSelector, getcount } from '../Slices/count';
import { getdetail, getmodel, modelSelector, updatemodel } from '../Slices/model';
import { IMAGE_URL_PRODUCTS } from '../Constants';
import { homedataSelector, upate_recommended, update_seachdata, update_ser_wishlist } from '../Slices/searchproducts';

import { addtocart, cartSelector, fetchaddtionalcart, fetchcart, update_cart_top, update_maincart } from '../Slices/cart';
import { authSelector } from '../Slices/auth';
import Toast from 'react-native-simple-toast';

import { fetchprodetail, updateloader } from '../Slices/productdetail';
import { Addwishlist } from '../Slices/whishlist';
const { width, height } = Dimensions.get("window")
export default function Homeproducts(props, navigation) {
    const { token } = useSelector(authSelector)
    const { cart_products } = useSelector(cartSelector)
    const [value, setValue] = useState(0)
    const dispatch = useDispatch();





    const updatecart = (index, type, variantcount) => {

        // alert(variantcount)

        if (token) {

            if (variantcount == 1) {

                if (props.dataParentToChild.key == "seaching") {
                    var data = [...props.dataParentToChild.data]
                    console.log(data[index].qty)
                    if (data[index].qty >= data[index].actual_qty && type == "increment") {
                        Toast.show("You reached maximun stock", Toast.SHORT);
                    }
                    else {
                        //update cart 
                        if (type == "increment" && data[index].qty == 0) {
                            var price = {
                                productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price) * 1,
                                cartlength: 1,
                                type: "addtocart"
                            }
                            dispatch(update_maincart(price))
                        }
                        else if (data[index].qty > 0) {
                            if (type == "increment") {
                                var price = {
                                    productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price) * Number(1),
                                    cartlength: 0,
                                    type: type
                                }
                                dispatch(update_maincart(price))
                            }
                            else {
                                var price = {
                                    productprice: Number(data[index].offer_price ? data[index].offer_price : data[index].price) * Number(-1),
                                    cartlength: (data[index].qty == 1 ? Number(-1) : Number(0)),
                                    type: type
                                }
                                dispatch(update_maincart(price))
                            }
                        }

                        dispatch(update_seachdata({ value: index, key: type }))
                        //update cart with api call
                        var data = {
                            "product_id": data[index].product_id,
                            "product_variant_id": data[index].variant_id,
                            "quantity": 1,
                            "type": type
                        }
                        var payload = {
                            data: data,
                            token: token
                        }
                        dispatch(addtocart(payload))
                    }

                }

                dispatch(fetchaddtionalcart(token, props.dataParentToChild.data))

            } else {

                detail(index)
            }
        }
        else {

            props.logincall()

        }
    }
    const detail = (index) => {
        var data = {
            type: "searchdata",
            status: true,
            wishlist: props.dataParentToChild.data[index].wishlist
        }
        dispatch(updatemodel(data))
        dispatch(updateloader(true))
        var data = [...props.dataParentToChild.data]
        var postdata = {
            id: data[index].product_id,
            cartdata: props.dataParentToChild.data,
        }
        if (token) {
            dispatch(fetchcart(token, postdata))

        }
        else {
            dispatch(fetchprodetail(postdata))
        }

    }

    const addingwishlist = (index) => {

        if (token) {

            dispatch(update_ser_wishlist(index))
            if (props.dataParentToChild.data[index].wishlist) {
                var postdata = {
                    id: props.dataParentToChild.data[index].product_id,
                    token: token,
                    type: 'remove'
                }
                dispatch(Addwishlist(postdata))
            }
            else {
                var postdata = {
                    id: props.dataParentToChild.data[index].product_id,
                    token: token,
                    type: 'add'
                }
                dispatch(Addwishlist(postdata))
            }
        }
        else {


            props.logincall()

        }
    }
    return (
        <FlatList
            data={props.dataParentToChild.data}
            numColumns={2}
            renderItem={({ item, index }) => (
                <View style={{ width: "50%", height: 'auto', backgroundColor: "white", margin: 0.85 }} >
                    <Pressable onPress={() => detail(index)} >
                        <View style={{ width: "100%", height: height * 0.03, marginTop: "2.5%", flexDirection: "row" }} >
                            <View style={{ width: "70%", height: "100%" }} >
                                {(item.discount > 0) ?
                                    <View style={{ width: "50%", height: height * 0.025, backgroundColor: "#538bf5", borderRadius: width * 0.0125, marginLeft: "5%", justifyContent: "center" }} >
                                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.028, textAlign: "center", color: "white" }} >{item.discount}% OFF</Text>
                                    </View> : null}
                            </View>

                            <Pressable onPress={() => addingwishlist(index)} style={{ width: "30%", height: "100%", justifyContent: "center" }} >
                                {!item.wishlist ?
                                    <Image style={{ width: "90%", height: "90%", resizeMode: "contain", alignSelf: "center", }} source={require("../Assets/heart1.png")} /> :
                                    <Image style={{ width: "90%", height: "90%", resizeMode: "contain", alignSelf: "center", }} source={require("../Assets/heart2.png")} />}
                            </Pressable>

                        </View>

                        <View style={{ width: "100%", height: height * 0.2, justifyContent: "center", }} >
                            <Image style={{ width: "70%", height: "90%", alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={{ uri: `${IMAGE_URL_PRODUCTS}` + item.image }} />

                        </View>
                        <Text numberOfLines={1} style={{ fontFamily: "Roboto-Medium", marginLeft: "5%", width: "90%", fontWeight: "600", fontSize: width * 0.0375, marginTop: "5%", }}  >{item.productname}</Text>
                        <Text style={{ fontFamily: "Roboto-Light", marginLeft: "5%", width: "90%", fontWeight: "600", fontSize: width * 0.035, marginTop: "2%" }} >({item.variant_value})</Text>
                        <View style={{ flexDirection: "row", width: "60%", marginLeft: "5%", marginTop: "2%", }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, }} >$ {parseFloat(item.offer_price).toFixed(2)}</Text>
                            <Text style={{ fontFamily: "Roboto-Light", fontWeight: "600", fontSize: width * 0.035, textDecorationLine: "line-through", marginLeft: "5%" }} >$ {parseFloat(item.price).toFixed(2)}</Text>
                        </View>
                    </Pressable>
                    {item.actual_qty > 0 ?
                        (!item.check ?

                            (
                                <TouchableWithoutFeedback onPress={() => updatecart(index, "increment", item.variant_count)} style={{ width: "90%", height: height * 0.045, backgroundColor: "#f8fff8", borderRadius: width * 0.025, alignSelf: "center", marginTop: "5%", marginBottom: "5%", borderWidth: width * 0.003, borderColor: "#00a4ff", justifyContent: "center" }} >
                                    <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0375, textAlign: "center", color: "#00a4ff" }} >ADD</Text>
                                </TouchableWithoutFeedback>
                            )

                            : (item.variant_count > 1 ? (


                                <TouchableWithoutFeedback onPress={() => updatecart(index, "increment", item.variant_count)} style={{ width: "90%", height: height * 0.045, backgroundColor: "#f8fff8", borderRadius: width * 0.025, alignSelf: "center", marginTop: "5%", marginBottom: "5%", borderWidth: width * 0.003, borderColor: "#00a4ff", justifyContent: "center" }} >
                                    <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0375, textAlign: "center", color: "#00a4ff" }} >ADD</Text>
                                </TouchableWithoutFeedback>
                            )
                                :




                                <View style={{ width: "90%", height: height * 0.045, backgroundColor: "#00a4ff", borderRadius: width * 0.025, alignSelf: "center", marginTop: "5%", marginBottom: "5%", justifyContent: "center", flexDirection: "row" }} >
                                    <Pressable onPress={() => updatecart(index, "decrement", item.variant_count)} style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                                        <Image style={{ width: "60%", height: "60%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/minus1.png')} />
                                    </Pressable>

                                    <View style={{ width: "60%", height: "100%", justifyContent: "center" }} >
                                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, textAlign: "center", color: "white" }} >{item.qty}</Text>
                                    </View>

                                    <Pressable onPress={() => updatecart(index, "increment", item.variant_count)} style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                                        <Image style={{ width: "60%", height: "60%", margin: 5, alignSelf: "center", borderRadius: width * 0.02, resizeMode: "contain" }} source={require('../Assets/plus1.png')} />
                                    </Pressable>
                                </View>
                            )
                        ) :
                        (
                            <View>
                                <Text style={{ fontSize: width * 0.045, color: "red", fontFamily: "Roboto-Medium", textAlign: "center" }} >out of stock</Text>
                            </View>
                        )}



                </View>
            )
            }
        />
    )
}
const styles = StyleSheet.create({
    conatiner: {
        width: width,
        height: height * 0.01,
        backgroundColor: "#d3d3d33d"
    }
})