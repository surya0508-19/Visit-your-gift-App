
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { countSelector, getcount } from '../Slices/count';
import { getdetail, getmodel, modelSelector } from '../Slices/model';
import { ordersSelector } from '../Slices/orders';

const { width, height } = Dimensions.get("window")
export default function Allorders(props, { navigation }) {

    var { count } = useSelector(countSelector);
    const { orders } = useSelector(ordersSelector)
    console.log("orders", orders)
    const [value, setValue] = useState(0)
    // const [products, setProducts] = useState([])
    const dispatch = useDispatch();
    useEffect(() => {
        console.log("TYPE", props.dataParentToChild)
    }, [props.dataParentToChild])




    return (
        <FlatList
            data={orders}

            renderItem={({ item, index }) => (
                <>
                    {props.dataParentToChild == "all" ?
                        <TouchableOpacity onPress={() => props.orderdetailscall(item.id)}>
                            <View style={{ width: "95%", height: width * 0.42, backgroundColor: "white", margin: 3, borderRadius: width * 0.030, alignSelf: "center", }} >

                                <View style={{ justifyContent: "space-between", width: "100%", borderTopRightRadius: width * 0.030, borderTopLeftRadius: width * 0.030, height: width * 0.20, backgroundColor: "white", flexDirection: "row", alignSelf: "center", borderWidth: 1, borderColor: "#eaeaea" }} >
                                    <View style={{ flexDirection: "row", marginLeft: "3%", alignItems: "center" }}>
                                        <Image style={{ width: 50, height: 50, resizeMode: "contain", }} source={require('../Assets/ordericon.png')} />

                                        <View style={{ marginLeft: "5%" }}>
                                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.045, color: "black" }} >Order id #{item.id}</Text>
                                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "#737373" }} >Total Amount : $ {item.grand_total}</Text>

                                        </View>
                                    </View>
                                    <View style={{ flexDirection: "row", marginTop: "2.5%" }}>

                                        <View style={item.status == "Cancelled" ? styles.cancel : styles.normal}>
                                            <Text style={item.status == "Cancelled" ? { fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "white" } : { fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "#277fed" }} >{item.status}</Text>
                                        </View>


                                    </View>


                                </View>
                                <View style={{ justifyContent: "space-evenly", width: "100%", height: width * 0.22, backgroundColor: "white", borderWidth: 0.50, borderColor: "#eaeaea", borderBottomRightRadius: width * 0.030, borderBottomLeftRadius: width * 0.030, }}>

                                    <View style={{ width: "93%", backgroundColor: "white", flexDirection: "row", justifyContent: 'space-between', alignSelf: "center" }}>

                                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.045, color: "#737373", marginLeft: "3%", }} >{Number(item.order_list_count) > 1 ? item.order_list_count + " items" : item.order_list_count + " item"} </Text>
                                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.040, color: "#737373", }} >{item.created_at}</Text>

                                    </View>

                                    <Text ellipsizeMode="clip" style={{ width: width * 0.9, alignSelf: "center", color: "#dddddd" }}> - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  - - - - - - - - -  - - - - </Text>


                                </View>
                            </View>
                        </TouchableOpacity> :
                        item.status == "Cancelled" ?
                            <TouchableOpacity onPress={() => props.orderdetailscall(item.id)}>
                                <View style={{ width: "95%", height: width * 0.42, backgroundColor: "white", margin: 3, borderRadius: width * 0.030, alignSelf: "center", }} >

                                    <View style={{ justifyContent: "space-between", width: "100%", borderTopRightRadius: width * 0.030, borderTopLeftRadius: width * 0.030, height: width * 0.20, backgroundColor: "white", flexDirection: "row", alignSelf: "center", borderWidth: 1, borderColor: "#eaeaea" }} >
                                        <View style={{ flexDirection: "row", marginLeft: "3%", alignItems: "center" }}>
                                            <Image style={{ width: 50, height: 50, resizeMode: "contain", }} source={require('../Assets/ordericon.png')} />

                                            <View style={{ marginLeft: "5%" }}>
                                                <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.045, color: "black" }} >Order id #{item.id}</Text>
                                                <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "#737373" }} >Total Amount : $ {item.grand_total}</Text>

                                            </View>
                                        </View>
                                        <View style={{ flexDirection: "row", marginTop: "2.5%" }}>

                                            <View style={item.status == "Cancelled" ? styles.cancel : styles.normal}>
                                                <Text style={item.status == "Cancelled" ? { fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "white" } : { fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "#277fed" }} >{item.status}</Text>
                                            </View>


                                        </View>


                                    </View>
                                    <View style={{ justifyContent: "space-evenly", width: "100%", height: width * 0.22, backgroundColor: "white", borderWidth: 0.50, borderColor: "#eaeaea", borderBottomRightRadius: width * 0.030, borderBottomLeftRadius: width * 0.030, }}>

                                        <View style={{ width: "93%", backgroundColor: "white", flexDirection: "row", justifyContent: 'space-between', alignSelf: "center" }}>

                                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.045, color: "#737373", marginLeft: "3%", }} >{item.order_list_count} items</Text>
                                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.040, color: "#737373", }} >{item.created_at}</Text>

                                        </View>

                                        <Text ellipsizeMode="clip" style={{ width: width * 0.9, alignSelf: "center", color: "#dddddd" }}> - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  - - - - - - - - -  - - - - </Text>


                                    </View>
                                </View>
                            </TouchableOpacity> : null
                    }
                </>
            )
            }
        />
    )
}
const styles = StyleSheet.create({
    conatiner: {
        width: width,
        height: height * 0.01,
        backgroundColor: "#d3d3d33d"
    },
    normal: {
        marginLeft: "6%",
        width: width * 0.2,
        height: height * 0.034,
        justifyContent: "center",
        alignItems: "center",
        borderWidth: 1,
        borderColor: "#277fed",
        borderRadius: width * 0.010,
    },
    cancel: {
        marginLeft: "6%",
        width: width * 0.2,
        height: height * 0.034,
        justifyContent: "center",
        alignItems: "center",
        borderWidth: 1,
        borderColor: "red",
        borderRadius: width * 0.010,
        backgroundColor: "#f006"
    },

})