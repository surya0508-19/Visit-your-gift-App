
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { IMAGE_URL_PRODUCTS } from '../Constants';
import { orderitemss } from '../Screens/TestData/data';

const { width, height } = Dimensions.get("window")
export default function OrderItems(props, navigation) {
   return (
      <FlatList
         data={props.orderproducts}
         renderItem={({ item, index }) => (
            <View style={{ width: "100%", height: height * 0.10, flexDirection: "row", marginTop: "2.5%", }} >
               <View style={{ width: "25%", height: "100%", alignItems: "center", justifyContent: "center" }} >
                  <View style={{ width: "90%", height: "90%", alignSelf: "center", borderWidth: width * 0.002, borderColor: "#ececec", borderRadius: width * 0.02, justifyContent: "center" }} >
                     <Image source={{uri:`${IMAGE_URL_PRODUCTS}`+item.item.image}} style={{ width: "80%", height: "80%", alignSelf: "center", resizeMode: "contain" }} />
                  </View>
               </View>
               <View style={{ width: "75%", height: "100%",}} >
                  <Text numberOfLines={2} style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0375, color: "black", marginLeft: "5%", marginTop: "5%" }} >{item.item.name}</Text>
                  <View style={{ width: "90%", height: "100%",flexDirection:"row",justifyContent:"space-between",alignSelf:"center",marginTop: "5%"}} >
                     <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.034, color: "black",  }} >({item.item_variant.price} X {item.quantity}) </Text>
                     <Text style={{ fontWeight: "600", fontFamily: "Roboto-Light", fontSize: width * 0.034, color: "black", fontWeight:"700" }} >$ {item.total}</Text>

                  </View>
               </View>

            </View>
         )}
      />
   )


}