
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { cartproducts } from '../Screens/TestData/data';
import { useDispatch, useSelector } from 'react-redux';
import { addtocart, cartSelector, fetchaddtionalcart, update_cart_products } from '../Slices/cart';
import { IMAGE_URL_PRODUCTS } from '../Constants';
import { authSelector } from '../Slices/auth';
import Toast from 'react-native-simple-toast';
import { categoriesproductSliceSelector } from '../Slices/categoriesproduct';
const {width,height} = Dimensions.get("window")
export default function Cartproducts (props,navigation) {
   const dispatch = useDispatch()
   const {cart_products} =useSelector(cartSelector)
   const {categoriesproduct} = useSelector(categoriesproductSliceSelector)
   const {token} = useSelector(authSelector)
 const updatecart = (index,type) => {
   if( (cart_products[index].qty >= cart_products[index].actual_qty) && type == "increment")
             {
                Toast.show("You reached maximun stock", Toast.SHORT);
             }
 else
  {

   var data={
      value:index,
      key:type
   }
   dispatch(update_cart_products(data))
   var data={
      "product_id":cart_products[index].product_id,
      "product_variant_id":cart_products[index].variant_id,
      "quantity":1,
       "type":type
  }
  var payload ={
      data:data,
      token:token
  }
  dispatch(addtocart(payload))
//   var data={
//      type:"updatecatdata",
//      data:categoriesproduct
//   }
//   dispatch(fetchaddtionalcart(token,data))
}
 }
return(
    <FlatList 
       data={cart_products}
       renderItem={({item,index}) => (
            <View style={{width:"100%",height:height*0.12,flexDirection:"row",marginTop:"2.5%"}} >
                 <View style={{width:"25%",height:"100%",alignItems:"center",justifyContent:"center"}} >
                    <View style={{width:"90%",height:"90%",alignSelf:"center",borderWidth:width*0.002,borderColor:"#ececec",borderRadius:width*0.02,justifyContent:"center"}} >
                       <Image source={{uri:`${IMAGE_URL_PRODUCTS}`+item.image}} style={{width:"80%",height:"80%",alignSelf:"center",resizeMode:"contain"}} />
                    </View>
                 </View>
                 <View style={{width:"50%",height:"100%",}} >
                 <Text numberOfLines={2} style={{fontFamily:"Roboto-Medium",fontSize:width*0.0375,color:"black",marginLeft:"5%",marginTop:"5%",width:"90%"}} >{item.productname}</Text>
                 <Text style={{fontFamily:"Roboto-Light",fontSize:width*0.036,color:"black",marginLeft:"5%",marginTop:"1%"}} >{item.variant_value}</Text>
                 {item.offer_price > 0 ?
                 <View style={{flexDirection:"row"}} >
                 <Text style={{fontFamily:"Roboto-Light",fontSize:width*0.036,color:"black",marginLeft:"5%",marginTop:"1%"}} >({parseFloat(item.offer_price).toFixed(2)} x {item.qty})</Text>
                 <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.036,color:"black",marginLeft:"5%",marginTop:"1%"}} >$ {parseFloat(item.offer_price*item.qty).toFixed(2)}</Text>
                 </View>:
                    <View style={{flexDirection:"row"}} >
                    <Text style={{fontFamily:"Roboto-Light",fontSize:width*0.036,color:"black",marginLeft:"5%",marginTop:"1%"}} >({parseFloat(item.price).toFixed(2)} x {item.qty})</Text>
                    <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.036,color:"black",marginLeft:"5%",marginTop:"1%"}} >$ {parseFloat(item.price*item.qty).toFixed(2)}</Text>
                    </View>
                 }
                    </View>
                    <View style={{width:"25%",height:"100%",justifyContent:"center"}} >
                       <View style={{width:"95%",height:"30%",backgroundColor:"#00a4ff",alignSelf:"center",borderRadius:width*0.02,flexDirection:"row",alignItems:"center"}} >
                          <TouchableOpacity onPress={() => updatecart(index,"decrement")} style={{width:"30%",height:"100%",justifyContent:"center"}} >
                          <Image source={require("../Assets/minus1.png")} style={{width:"60%",height:"60%",alignSelf:"center",resizeMode:"contain"}} />
                          </TouchableOpacity>

                          <View style={{width:"40%",height:"100%",justifyContent:"center"}} >
                          <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.036,color:"white",textAlign:"center"}} >{item.qty}</Text>
                          </View>

                          <TouchableOpacity onPress={() => updatecart(index,"increment")} style={{width:"30%",height:"100%",justifyContent:"center"}} >
                          <Image source={require("../Assets/plus1.png")} style={{width:"60%",height:"60%",alignSelf:"center",resizeMode:"contain"}} />
                          </TouchableOpacity>
                       </View>
                    </View>
            </View>
       )}
       />
)


}