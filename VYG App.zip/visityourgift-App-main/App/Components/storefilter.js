import React, { useState, useEffect, Component } from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,Modal, TextInput,StyleSheet,FlatList,ToastAndroid, ScrollView,Keyboard} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../Screens/Statusbar';
import { countSelector } from '../Slices/count';
import { getdetail, getmodel, getStores, getsubcatfilter, modelSelector } from '../Slices/model';
import Carthelp from './carthelp';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import CheckBox from '@react-native-community/checkbox';
import LinearGradient from 'react-native-linear-gradient';
import StarRating from 'react-native-star-rating-widget';
const {width,height}=Dimensions.get("window")
export default function Storefilter (props,navigation) {
    
    const dispatch = useDispatch()
    const{stores} =useSelector(modelSelector)
    const data='rgba(52, 52, 52, 0.8)'


const modelclose = () => {

    dispatch(getStores(false))
}

const [rating,setRating]=useState([
    {
        title:"neslae",
        Rating:1,
        active:false
    },
    {
        title:"catboury",
        Rating:2,
        active:false
    },
    {
        title:"5star",
        Rating:3,
        active:false
    },
    {
        title:"lays",
        Rating:4,
        active:false
    },
    {
        title:"lays",
        Rating:5,
        active:false
    }

])
 
const Rating =(value,index) => {
    var data1=[...rating]
    data1[index].Rating=value
    setRating(data1)
 }

 const Change = (value,index) => {
    var data=[...rating]
      if(data[index].active)
      {
       data[index].active=false
       setRating(data)
      }
      else
      {
       data[index].active=true
       setRating(data)
      }
    
   }

   const clearfilter = () => {
    var data=rating.map(e => ({
         active:false,
         Rating:e.Rating,
         title:e.title
        }))
      setRating(data)
   }
 
    return(
      
        <Modal 
        animationType="slide"
        transparent={true}
        visible={stores}
        
        >
         <Statusbar dataParentToChild={data} />
         <View    style={{flex:1,backgroundColor:"rgba(52, 52, 52, 0.8)"}} >
            <TouchableOpacity onPress={() => modelclose()}  style={style.colse} >
                  <Image  style={{width:'55%',height:"55%",resizeMode:"contain",alignSelf:"center"}} source={require('../Assets/reject.png')} />
            </TouchableOpacity>
        <Card style={  style.container } >
        <LinearGradient  colors={['#f7cb48', '#fef290', '#fff5b0']} style={{width:"100%",height:"10%",backgroundColor:'red',justifyContent:"center",borderTopLeftRadius:width*0.035,borderTopRightRadius:width*0.035,}} >
        <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.045,textAlign:"center"}} >Filter by rating of stores</Text>
            </LinearGradient>
        <Text style={{fontFamily:"Roboto-Regular",fontSize:width*0.045,marginLeft:"2.5%",marginTop:"2.5%"}} >Select the rating</Text>
         <View style={{width:"100%",height:"60%",marginTop:"2.5%"}} >
         <FlatList 
       data={rating}
       renderItem={({item,index}) => (
        <View style={{width:width*0.9,height:height*0.075,marginTop:'1%',flexDirection:"row",alignSelf:"center"}} >
            <View style={{width:"15%",height:"100%",justifyContent:"center"}} >
            <CheckBox
             style={{width:"80%",height:"80%",alignSelf:"center"}}
             value={item.active}
             onValueChange={(value) => Change(value,index)}
  />
            </View>

            <View style={{width:"70%",height:"100%",justifyContent:"center"}} >
            <StarRating
           rating={item.Rating}
           starSize={width*0.07}
           starStyle={{width:width*0.05}}
           color={"#00a4ff"}
           maxStars={5}
           onChange={() => Rating(item.Rating,index) }
      />
            </View>

            <View style={{width:"15%",height:"100%",justifyContent:"center"}} >
            <Text style={{fontFamily:"Roboto-Light",fontSize:width*0.04, color:"black",}} >{index+1}/5</Text>
            </View>
         </View>
       )
       }
       />
         </View>

         <View style={{width:"100%",height:height*0.09,flexDirection:"row",alignItems:"center",justifyContent:"space-evenly"}}  >
            <Pressable onPress={() => clearfilter()}  style={{width:"45%",backgroundColor:"white",height:"80%",borderRadius:width*0.02,justifyContent:"center",borderWidth:width*0.002,borderColor:"#00a4ff"}} >
            <Text style={{fontFamily:"Roboto-Regular",fontSize:width*0.045, color:"#00a4ff",textAlign:"center"}} >Clear Filter</Text>
            </Pressable>

            <Pressable onPress={() => modelclose()} style={{width:"45%",backgroundColor:"#00a4ff",height:"80%",borderRadius:width*0.02,justifyContent:"center"}} >
            <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.045, color:"white",textAlign:"center"}} >Apply</Text>
            </Pressable>

</View>

        
        </Card>
        </View>
        
        </Modal>
      
    )

}
const style = StyleSheet.create({
    container:{
        width:width,
        height:height*0.75,
        backgroundColor:"white",
        borderRadius:width*0.035,
        top:"23.25%"
    },
    container1:{
        width:width,
        height:height*0.75,
        backgroundColor:"white",
        top:"2%",
        borderRadius:width*0.035
    },

   colse:{
    width:width*0.11,
    height:height*0.055,
    backgroundColor:"black",
    borderRadius:width*0.07,
    top:"20%",
    alignSelf:"center",
    justifyContent:"center"
   },
   colse1:{
    width:width*0.11,
    height:height*0.055,
    backgroundColor:"black",
    borderRadius:width*0.07,
   
    alignSelf:"center",
    justifyContent:"center"
   },


    title1:{
      fontFamily:"Roboto-Medium",
      fontWeight:"600",
      fontSize:width*0.0425,
      color:"black",
      marginTop:"3%",
      marginLeft:"3%"
    },
    text:{
      fontFamily:"Roboto-Light",
      fontWeight:"600",
      fontSize:width*0.0375,
      color:"black",
      marginTop:"1%",
      marginLeft:"3%",
      width:"95%"
    },
    youmight_container:{
      width:width,
      height:height*0.425,
      marginBottom:"25%"
    },
    youmight_container1:{
      width:width,
      height:height*0.425,
      marginBottom:"5%"
    },
    left_text:{
        fontFamily:"Roboto-Regular",
        fontSize:width*0.043,
        color:"black",
        marginLeft:"10%"
    },
    left_text1:{
        fontFamily:"Roboto-Bold",
        fontSize:width*0.043,
        color:"#00a4ff",
        marginLeft:"10%"
    }
})