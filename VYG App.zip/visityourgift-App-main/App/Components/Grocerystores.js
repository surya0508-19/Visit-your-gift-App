
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import StarRating from 'react-native-star-rating-widget';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';

const {width,height} = Dimensions.get("window")
export default function Grocerystores (props,navigation) {
    const [data,setData]=useState([
        {
          shop_image:require("../Assets/store1.jpg"),
          shop_name:"Rajan Rufus Departmental Store",
          Address:"kk nagar, madurai, 620015",
          shop_openings:"Monday to Saturday",
          Delivery_time:"09:00am to 08:00pm",
          Rating:4.5
        },
        {
            shop_image:require("../Assets/store2.jpg"),
            shop_name:"Guru Super Market",
            Address:"Anna nagar madurai 625002",
            shop_openings:"All Days",
            Delivery_time:"09:00am to 10:00pm",
            Rating:4
        },
        {
            shop_image:require("../Assets/store3.jpg"),
            shop_name:"Thasthakir Maligai",
            Address:"Mapalayam , madurai west junction,625024",
            shop_openings:"Monday to Friday",
            Delivery_time:"09:00am to 06:00pm",
            Rating:5
        },
        {
            shop_image:require("../Assets/store4.jpg"),
            shop_name:"Sathya Trading store",
            Address:"k.Pudhur ,Madurai,625301",
            shop_openings:"Monday to Saturday",
            Delivery_time:"08:00am to 07:00pm",
            Rating:4
        },
        {
            shop_image:require("../Assets/store5.jpg"),
            shop_name:"Rajeshwari Store",
            Address:"Simmakal busstop,Madurai,625001",
            shop_openings:"All Days",
            Delivery_time:"09:00am to 09:00pm",
            Rating:3.5
        },
        {
            shop_image:require("../Assets/kannan.png"),
            shop_name:"Kannan Departmental Store",
            Address:"kk nagar madurai 620015",
            shop_openings:"Monday to Saturday",
            Delivery_time:"09:00am to 08:00pm",
            Rating:3
        },
      ])

    const Rating =(value,index) => {
       var data1=[...data]
       data1[index].Rating=value
       setData(data1)
    }
return(
<FlatList 
       data={data}
       numColumns={2}
       renderItem={({item,index}) => (
        <View style={{width:"50%",height:'auto',backgroundColor:"white",margin:0.75}} >
            <Pressable onPress={() => props.shopdetail()} style={{width:"100%",height:height*0.175,justifyContent:"center"}} >
              <Image style={{width:"90%",height:"100%",margin:5,alignSelf:"center",resizeMode:"contain",marginTop:"10%",borderColor:"#f7cb48",borderWidth:width*0.005,borderRadius:width*0.025}} source={item.shop_image} />
            </Pressable>
            <View style={{width:"100%",height:height*0.275,}} >
          <Text style={{fontFamily:"Roboto-Medium",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.041,marginTop:"10%",}} >{item.shop_name}</Text>
          <Text style={{fontFamily:"Roboto-Light",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.035,marginTop:"2%"}} >{item.Address}</Text>
          <View style={{width:"90%",flexDirection:"row",marginTop:"2%",marginLeft:"5%"}} >
          <Text style={{fontFamily:"Roboto-Light",width:"47.5%",fontWeight:"600",fontSize:width*0.035}} >Shop opens </Text>
          <Text style={{fontFamily:"Roboto-Light",width:"5%",fontWeight:"600",fontSize:width*0.035}} >: </Text>
          <Text style={{fontFamily:"Roboto-Light",width:"47.5%",fontWeight:"600",fontSize:width*0.035,}} >{item.shop_openings}</Text>
          </View>

          <View style={{width:"90%",flexDirection:"row",marginTop:"2%",marginLeft:"5%"}} >
          <Text style={{fontFamily:"Roboto-Light",width:"47.5%",fontWeight:"600",fontSize:width*0.035}} >Delivery Time </Text>
          <Text style={{fontFamily:"Roboto-Light",width:"5%",fontWeight:"600",fontSize:width*0.035}} >: </Text>
          <Text style={{fontFamily:"Roboto-Light",width:"47.5%",fontWeight:"600",fontSize:width*0.035,}} >{item.Delivery_time}</Text>
          </View>
          <View style={{width:"95%",height:height*0.04,alignSelf:"center",justifyContent:"center",position:"absolute",bottom:"5%"}} >
          <StarRating
           rating={3}
           starSize={width*0.055}
           starStyle={{width:width*0.03,}}
           color={"#00a4ff"}
           maxStars={5}
           onChange={() => Rating(item.Rating,index) }
      />
          </View>
          </View>

        
         </View>
       )
    }
/>
)
}
const styles = StyleSheet.create({
    conatiner:{
        width:width,
        height:height*0.01,
        backgroundColor:"#d3d3d33d"
    }
})