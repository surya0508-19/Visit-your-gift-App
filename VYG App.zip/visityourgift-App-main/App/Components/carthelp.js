
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useDispatch, useSelector } from 'react-redux';
import { addressSelector } from '../Slices/address';
import { cartSelector } from '../Slices/cart';
import { countSelector, getcount } from '../Slices/count';
import { deliverychargeSelector } from '../Slices/deliverycharge';
import FlipkartSuperCoinsGif from './GifAnimation';
const { width, height } = Dimensions.get("window")
export default function Carthelp(props, navigation) {

  const { cart_length, cart_total } = useSelector(cartSelector);
  const { minimum_charge, delivery_settings } = useSelector(deliverychargeSelector)
  const { address_list, add_status } = useSelector(addressSelector)

  console.log("delivery", delivery_settings)


  return (
    <View style={{ width: width * 0.95, height: height * 0.1, backgroundColor: "#f3f7ff", alignSelf: "center", bottom: "1%", borderTopLeftRadius: width * 0.025, borderTopRightRadius: width * 0.025, borderWidth: width * 0.002, borderColor: '#538bf5', position: "absolute" }} >

      <View style={{ width: "100%", height: "32.5%", flexDirection: "row", alignItems: "center", justifyContent: "center" }} >
        {/* <Image style={{width:15,height:15}} source={require("../Assets/offer.png")}  /> */}

        {Number(delivery_settings.minimum_order_amount) >= Number(cart_total) ?
          <Text style={{ marginLeft: "2.5%", color: "#538bf5", fontFamily: "Roboto-Bold", fontSize: width * 0.035, }} >Shop for $ {parseFloat(delivery_settings.minimum_order_amount - cart_total).toFixed(2)} more to get this order  </Text>
          :
          <Text style={{ marginLeft: "2.5%", color: "#538bf5", fontFamily: "Roboto-Bold", fontSize: width * 0.035, }} >Woohoo now you get this order</Text>
        }
      </View>

      <Pressable onPress={() => props.cartcall()} style={{ width: "100%", height: "67.5%", flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#00a4ff", borderTopLeftRadius: width * 0.025, borderTopRightRadius: width * 0.025 }} >
        <View style={{ width: "30%", height: "75%", marginLeft: "3%" }} >
          <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "white" }} >{cart_length} Items</Text>
          <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "white" }} >$  {parseFloat(cart_total).toFixed(2)}</Text>
        </View>

        <View style={{ width: "30%", height: "70%", flexDirection: "row", alignItems: "center", justifyContent: "space-evenly" }} >
          <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0375, color: "white" }} >View Cart</Text>
          <Image style={{ width: width * 0.0275, height: height * 0.0125 }} source={require("../Assets/rightarrow.png")} />
        </View>
      </Pressable>


    </View>
  )
}