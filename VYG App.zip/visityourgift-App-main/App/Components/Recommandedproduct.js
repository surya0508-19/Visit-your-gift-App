
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
const {width,height} = Dimensions.get("window")
export default function Recommandedproducts (props,navigation) {
    const [products,setProducts] =useState([
        {
           name:"Dairy milk silk",
           quantity:"10 kg",
           image:require("../Assets/product1.png"),
           salesprice:150,
           marketprice:170,
           offer:"",
           updatequantity:0,
           active:false
        },
        {
            name:"Dark Fantasy",
            quantity:"250 g",
            image:require("../Assets/product2.jpg"),
            salesprice:35,
            marketprice:40,
            offer:4,
            updatequantity:0,
            active:false
        },
        {
            name:"Parasoot oil",
            quantity:"250 L",
            image:require("../Assets/product3.png"),
            salesprice:120,
            marketprice:130,
            offer:8,
            updatequantity:0,
            active:false
        },
        {
            name:"Garnier men face wash",
            quantity:"150 g",
            image:require("../Assets/product4.png"),
            salesprice:90,
            marketprice:110,
            offer:'',
            updatequantity:0,
            active:false
        },

        {
            name:"Oreo Biscuit",
            quantity:"20 g",
            image:require("../Assets/product5.jpg"),
            salesprice:25,
            marketprice:30,
            offer:'',
            updatequantity:0,
            active:false
        },

        {
            name:"Basmathi Rice",
            quantity:"5 kg ",
            image:require("../Assets/Rice.jpg"),
            salesprice:150,
            marketprice:180,
            offer:'',
            updatequantity:0,
            active:false
        },
      ]);
    const addtocart = (index) => {
        var data=[...products]
        var count=data[index].updatequantity
        data[index].active=true
        data[index].updatequantity=count+1
        setProducts(data)
    }
    const updatecart = (value,index) => {
        if(value == "increment")
        {
            var data=[...products]
            var count=data[index].updatequantity
            data[index].active=true
            data[index].updatequantity=count+1
            setProducts(data)
        }
        else
        {
            var data=[...products]
            var count=data[index].updatequantity
            if(count>1)
            {
                data[index].active=true
                data[index].updatequantity=count-1
                setProducts(data)
            }
            else
            {
                data[index].active=false
                data[index].updatequantity=0
                setProducts(data)
            }
           
        }
    }
    
return(
<FlatList 
       data={products}
       numColumns={2}
       renderItem={({item,index}) => (
        <View style={{width:"50%",height:'auto',backgroundColor:"white",margin:0.75}} >
            <View style={{width:"100%",height:height*0.03,marginTop:"2.5%"}} >
             {item.offer ?
              <View style={{width:"27.5%",height:height*0.025,backgroundColor:"#538bf5",borderRadius:width*0.0125,top:"2%",marginLeft:"5%",justifyContent:"center"}} >
               <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.028,textAlign:"center",color:"white"}} >{item.offer}% OFF</Text>
              </View>:null}
            </View>
              
            <View style={{width:"100%",height:height*0.2,justifyContent:"center",}} >
              <Image style={{width:"70%",height:"100%",margin:5,alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={item.image} />
            
            </View>
          <Text style={{fontFamily:"Roboto-Medium",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.0375,marginTop:"5%"}} >{item.name}</Text>
          <Text style={{fontFamily:"Roboto-Light",marginLeft:"5%",width:"90%",fontWeight:"600",fontSize:width*0.035,marginTop:"2%"}} >{item.quantity}</Text>
          <View style={{flexDirection:"row",width:"60%",marginLeft:"5%",marginTop:"2%",}} >
          <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.035,}} >$ {item.salesprice}</Text>
          <Text style={{fontFamily:"Roboto-Light",fontWeight:"600",fontSize:width*0.035,textDecorationLine:"line-through",marginLeft:"5%"}} >$ {item.marketprice}</Text>
          </View>
           {!item.active ?
          <TouchableWithoutFeedback onPress={() => addtocart(index)} style={{width:"90%",height:height*0.045,backgroundColor:"#f8fff8",borderRadius:width*0.025,alignSelf:"center",marginTop:"5%",marginBottom:"5%",borderWidth:width*0.003,borderColor:"#00a4ff",justifyContent:"center"}} >
          <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.0375,textAlign:"center",color:"#00a4ff"}} >ADD</Text>
          </TouchableWithoutFeedback>:
          <View onPress={() => addtocart(index)} style={{width:"90%",height:height*0.045,backgroundColor:"#00a4ff",borderRadius:width*0.025,alignSelf:"center",marginTop:"5%",marginBottom:"5%",justifyContent:"center",flexDirection:"row"}} >
              <TouchableOpacity onPress={() => updatecart('decrementent',index) } style={{width:"20%",height:"100%",justifyContent:"center"}} >
              <Image style={{width:"37.5%",height:"37.5%",margin:5,alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={require('../Assets/minus.png')} />
            </TouchableOpacity>

              <View style={{width:"60%",height:"100%",justifyContent:"center"}} >
              <Text style={{fontFamily:"Roboto-Medium",fontWeight:"600",fontSize:width*0.04,textAlign:"center",color:"white"}} >{item.updatequantity}</Text>
              </View>

              <TouchableOpacity onPress={() => updatecart('increment',index) } style={{width:"20%",height:"100%",justifyContent:"center"}} >
              <Image style={{width:"40%",height:"40%",margin:5,alignSelf:"center",borderRadius:width*0.02,resizeMode:"contain"}} source={require('../Assets/plus.png')} />
              </TouchableOpacity>
          </View>}


         </View>
       )
    }
/>
)
}
const styles = StyleSheet.create({
    conatiner:{
        width:width,
        height:height*0.01,
        backgroundColor:"#d3d3d33d"
    }
})