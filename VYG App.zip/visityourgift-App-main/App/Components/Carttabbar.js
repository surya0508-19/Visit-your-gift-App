
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar,FlatList,StyleSheet} from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { useSelector } from 'react-redux';
import { cartproducts } from '../Screens/TestData/data';
import { cartSelector } from '../Slices/cart';

const {width,height} = Dimensions.get("window")
export default function Cartnavnar (props,navigation) {
  const {cart_length,cart_total,discount} = useSelector(cartSelector);
  return(
    <View style={{width:"100%",height:height*0.06,backgroundColor:"#d9e8ff",flexDirection:'row',alignItems:"center",justifyContent:"space-evenly",marginBottom:"5%"}} >
           <View style={{width:"70%",height:"100%",justifyContent:"center"}} >
       <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.04,marginLeft:"4%",color:"#3077dd"}} >Your total savings</Text>
       </View>
       <View style={{width:"30%",height:"100%",justifyContent:"center"}} >
       <Text style={{fontFamily:"Roboto-Medium",fontSize:width*0.04,color:"#3077dd",textAlign:"center",alignSelf:"flex-end",marginRight:"10%"}} >$ {parseFloat(discount).toFixed(2)}</Text>
       </View>
    </View>
  )
}