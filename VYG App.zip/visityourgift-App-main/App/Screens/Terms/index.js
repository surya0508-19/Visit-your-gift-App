
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Linking,ScrollView, SafeAreaView } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';
import { get_terms } from '../Terms/api';
import RenderHtml from 'react-native-render-html';

export default function Terms(props) {
    const { width, height } = Dimensions.get("window")
    const [terms, setterms] = useState("")

    useEffect(() => {
        getterms()
    }, []);


    const data = {
        name: 'Terms & Conditions',
        search: false
    }

    const getterms = async () => {


        const get_fome = await get_terms()


        setterms(get_fome)

    }


    return (
        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />

            {/* {/ <View style={{ width: width, height: height  0.935, backgroundColor: "white", }}>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "black", width: "95%", marginLeft: "3%", marginTop: "2%" }} >{terms}</Text>
            </View> */}
            <ScrollView>
                <View style={{ width: "92%", marginLeft: "2%", marginRight: "2%", alignSelf: "center" }}>
                    <RenderHtml
                        contentWidth={1000}
                        source={{
                            html: `<div style="color:black;line-height: 22px;font-size:13px;padding:0px  1px;">${terms}<div>`
                        }}
                    />

                </View>
            </ScrollView>
        </SafeAreaView>
    )
}