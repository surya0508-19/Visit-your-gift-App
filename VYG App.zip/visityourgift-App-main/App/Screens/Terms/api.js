import { URL_TERMS } from '../../Constants'
import axios from 'axios';



export const get_terms = async () => {

    try {
        const getterms = await axios({
            method: "get",
            url: `${URL_TERMS}`,

        })

    // console.log(" getterms.data====>",  getterms.data)
    

        return getterms.data.terms_and_conditions;

    }

    catch (error) {
    console.log("error====>", error)
    console.log("400", error.response.data)

}
}

