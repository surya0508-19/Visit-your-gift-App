import axios from "axios";
import { APPLYCOUPON, URL_PLACEORDER } from "../../Constants";

export const applycoupen = async (coupen) => {
    try{
        console.log("Test",coupen)
        const reponse = await axios({
            method:"get",
            url: `${APPLYCOUPON}`+coupen.id,
            headers:{
                Authorization:coupen.token
            }
        })
        if(reponse.data)
        return reponse.data
        

    }
    catch(err)
    {
        console.log("Err",err.response.data)
        return err.response.data
    } 
    
}

export const createorder = async (data,token) => {
    try{
        const reponse = await axios({
            method:"post",
            url: `${URL_PLACEORDER}`,
            data:data,
            headers:{
                Authorization:token
            }
        })
        if(reponse.data)
        console.log("test",reponse.data)
        
        return reponse.data
        
    }
    catch(err)
    {
        console.log("Err",err.response.data)
        return err.response.data
    } 


}