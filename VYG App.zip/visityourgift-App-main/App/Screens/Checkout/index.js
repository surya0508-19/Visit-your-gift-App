import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Keyboard, Dimensions, ActivityIndicator, StyleSheet, TextInput, ImageBackground, FlatList, Modal, ScrollView, SafeAreaView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import { Savedaddress } from '../TestData/data';
import CheckBox from '@react-native-community/checkbox';
import { addressSelector, deleteaddress, fetchaddress, setactiveaddress, updateaddress } from '../../Slices/address';
import { useDispatch, useSelector } from 'react-redux';
import { authSelector } from '../../Slices/auth';
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';
import Checkoutproducts from '../../Components/checkoutproducts';
import { cartSelector, cart_empty, fetchcart } from '../../Slices/cart';
import { applycoupen, createorder } from './api';
import Toast from 'react-native-simple-toast';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { deliverychargeSelector } from '../../Slices/deliverycharge';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { fetchprofile, getnotificationlist, profileSelector } from '../../Slices/profile';
import BlinkView from 'react-native-blink-view'

import Animated, { Easing } from 'react-native-reanimated';


const { width, height } = Dimensions.get("window")
export default function Checkout(props, navigation) {
  const dispatch = useDispatch()
  const { cart_total, discount } = useSelector(cartSelector)
  const { cart_products } = useSelector(cartSelector)
  const { profile } = useSelector(profileSelector)

  // console.log("profile", profile)

  const { token } = useSelector(authSelector)
  const [deliverytype, setDeliverytype] = useState("standard")
  const [paymentmode, setPaymentmode] = useState("")
  const { delivery } = useSelector(deliverychargeSelector)
  const { minimum_charge, delivery_settings } = useSelector(deliverychargeSelector)




  useEffect(() => {
    dispatch(fetchprofile(token))
  }, [])



  useEffect(() => {
    if (cart_total) {
      console.log("delivery", delivery)

      if (Number(delivery.rewardpoints.min_order) <= Number(cart_total)) {

        let pointsPerRupee = Number(delivery.rewardpoints.reward_points) / Number(delivery.rewardpoints.min_order);

        // Calculate the points for the target rupees
        let pointsFor124Rupees = pointsPerRupee * (Number(cart_total));

        console.log(`Points for 124 rupees: ${pointsFor124Rupees}`);
        setrewardss(Math.ceil(pointsFor124Rupees))


      }






    }
  }, [cart_total, pointamount])

  useEffect(() => {
    if (profile) {

      // Calculate rupees per point
      let rupeesPerPoint = Number(delivery.rewardpoints.usd) / Number(delivery.rewardpoints.reward_points);

      // Calculate the rupees for the target points
      let rupeesFor25Points = rupeesPerPoint * Number(profile.reward_points);

      console.log(`Rupees for 25 points: ${rupeesFor25Points}`);
      setpointamount(rupeesFor25Points.toFixed(2))
    }

  }, [profile,])







  const [rewardss, setrewardss] = useState(0)


  const [message, setmessage] = useState("")
  const [coinscheck, setCoinscheck] = useState(false)
  const [Animateing, setAnimateing] = useState(false)

  const [radioindex, setradioindex] = useState(0)


  const [pointamount, setpointamount] = useState(0)


  const [storeprice, setStoreprice] = useState({
    sub_total: 0,
    grandtotal: 0,
    pack_charge: 0,
    coupenamt: 0,
    shipping_chagre: 0
  })

  const [price, setPrice] = useState({
    coupenamt: Number(0),
    tax: Number(0),
    deliverycharge: Number(0),
    tipamount: Number(0),
    carttotal: Number(cart_total),
    grandtotal: Number(cart_total)
  })
  const [coupen, setCopen] = useState({
    coupenid: '',
    status: false,
    err: false,
    onfocuseff: false
  })

  const [points, setpoints] = useState(0)


  const [loader, setLoader] = useState({
    coupen: false,
    order: false
  })
  const [tip, setTip] = useState({
    five: false,
    fifteen: false,
    twentyfive: false,
    custom: false
  })
  const [show, setShow] = useState(false)
  const [customtip, setCustomtip] = useState(0)
  const data = {
    name: 'Checkout',
    search: false
  }

  const {
    Value,
    timing,
  } = Animated;


  const [animationValue] = useState(new Value(0));

  useEffect(() => {
    if (Animateing) {
      const animation = timing(animationValue, {
        toValue: 1,
        duration: 2000,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: true,
      });

      animation.start();

    }
  }, [animationValue, Animateing]);

  const opacity = animationValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });


  const EnableSuperIcons = (value) => {


    setCoinscheck(value)

    if (value == true) {
      setAnimateing(true)

      setTimeout(() => {
        setAnimateing(false)

      }, 2500);
      setpoints(profile.reward_points)

      // Calculate rupees per point
      let rupeesPerPoint = Number(delivery.rewardpoints.usd) / Number(delivery.rewardpoints.reward_points);

      // Calculate the rupees for the target points
      let rupeesFor25Points = rupeesPerPoint * Number(profile.reward_points);

      console.log(`Rupees for 25 points: ${rupeesFor25Points}`);
      setpointamount(rupeesFor25Points.toFixed(2))
      if (Number(delivery.rewardpoints.min_order) <= Number(cart_total) - Number(rupeesFor25Points)) {

        let pointsPerRupee = Number(delivery.rewardpoints.reward_points) / Number(delivery.rewardpoints.min_order);

        // Calculate the points for the target rupees
        console.log(`tot ${Number(cart_total) - Number(rupeesFor25Points)}`);


        let pointsFor124Rupees = pointsPerRupee * (Number(cart_total) - Number(rupeesFor25Points))

        console.log(`Points for 124 rupees: ${pointsFor124Rupees}`);
        setrewardss(Math.round(pointsFor124Rupees))


      }

    }
    else {

      setpoints(0)

    }



  }


  console.log("Animateing", Animateing)

  const selecttype = (index, value) => {
    setDeliverytype(value)
    setradioindex(index)

    if (value == "sameday") {
      var data = { ...storeprice }
      data.grandtotal = data.sub_total + Number(delivery_settings.express_delivery_charge) + cart_total + data.pack_charge
      data.shipping_chagre = data.sub_total + Number(delivery_settings.express_delivery_charge)
      console.log("data.grandtotal", data.grandtotal)
      setStoreprice(data)

    }
    else {

      var data = { ...storeprice }
      data.grandtotal = data.sub_total + cart_total + data.pack_charge
      data.shipping_chagre = data.sub_total
      console.log("data.grandtotal", data.grandtotal)
      setStoreprice(data)

    }



  }
  useEffect(() => {
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setShow(false)

      }
    );
    return () => {
      keyboardDidHideListener.remove();
    };
  }, [])

  useEffect(() => {



    if (delivery.products) {
      const tax = delivery.products.map(e => {
        return Number(e.tax)
      })
      const sum = tax.reduce((a, b) => a + b, 0)

      var prices = { ...price }
      prices.tax = Number(sum)
      prices.grandtotal = Number(prices.carttotal) + Number(sum)
      setPrice(prices)
    }

    getallquantity()

  }, [delivery])

  const getallquantity = () => {



    const all_qty = cart_products.map(e => {
      return Number(e.qty)
    })
    const sum_all_qty = all_qty.reduce((a, b) => a + b, 0)

    console.log("sum_all_qty", sum_all_qty)
    console.log("delivery_settings", delivery_settings.shipping_charge_per_quantity)

    const sub_total = sum_all_qty * Number(delivery_settings.shipping_charge_per_quantity)
    console.log("sub_total", sub_total)

    const total = sub_total + Number(delivery_settings.minimum_shipping_charge)
    console.log("total", total)

    var data = { ...storeprice }
    data.sub_total = total
    data.shipping_chagre = total
    data.grandtotal = total + cart_total + Number(delivery_settings.packing_price)
    data.pack_charge = Number(delivery_settings.packing_price)
    setStoreprice(data)

  }


  const coupenapply = async () => {
    if (!coupen.coupenid) {
      Toast.show("Please enter the coupon code", Toast.SHORT);
    }
    else {
      var load = { ...loader }
      load.coupen = true
      setLoader(load)
      var data = {
        id: coupen.coupenid,
        token: token
      }

      const output = await applycoupen(data)


      if (output.coupon_discount) {

        var data1 = { ...storeprice }

        // var prices = { ...price }
        var discount = ((cart_total) * Number(output.coupon_discount)) / 100
        //  prices.coupenamt = Number(discount)
        //  prices.carttotal = Number(cart_total) - Number(discount)
        //  prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) + Number(prices.tipamount) - Number(discount)
        //  setPrice(prices)
        data1.coupenamt = Number(discount)

        console.log("output.coupon_discount", Number(discount))

        console.log("output.coupon_discount", data1.grandtotal)

        setStoreprice(data1)


        var success = { ...coupen }
        success.status = true
        setCopen(success)

        var load = { ...loader }
        load.coupen = false
        setLoader(load)
      }
      else if (output.errors.coupon == "The selected coupon is invalid.") {
        // Toast.show("The selected coupon is invalid.", Toast.SHORT);
        var err = { ...coupen }
        err.err = true
        setCopen(err)
        var load = { ...loader }
        load.coupen = false
        setLoader(load)

        // var data={...coupen}
        // data.status = false
        // data.coupenid =""
        // setCopen(data)
      }
      else {
        Toast.show("You already applied this coupon", Toast.SHORT);
        var load = { ...loader }
        load.coupen = false
        setLoader(load)

        // var data={...coupen}
        // data.status = false
        // data.coupenid =""
        // setCopen(data)
      }
    }
  }

  const tipvalidate = (key) => {
    var data = { ...tip }
    switch (key) {
      case "five":
        if (data.five) {
          data.five = false
          data.fifteen = false
          data.twentyfive = false
          data.custom = false
          setCustomtip(0)
          var prices = { ...price }
          prices.tipamount = Number(0)
          prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) - Number(0) - Number(prices.coupenamt)
          setPrice(prices)
        }
        else {
          data.five = true
          data.fifteen = false
          data.twentyfive = false
          data.custom = false
          setCustomtip(0)
          var prices = { ...price }
          prices.tipamount = Number(5)
          prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) + Number(5) - Number(prices.coupenamt)
          setPrice(prices)
        }
        break;
      case "fifteen":
        if (data.fifteen) {
          data.five = false
          data.fifteen = false
          data.twentyfive = false
          data.custom = false
          setCustomtip(0)

          var prices = { ...price }
          prices.tipamount = Number(0)
          prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) - Number(0) - Number(prices.coupenamt)
          setPrice(prices)
        }
        else {
          data.five = false
          data.fifteen = true
          data.twentyfive = false
          data.custom = false
          setCustomtip(0)
          var prices = { ...price }
          prices.tipamount = Number(15)
          prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) + Number(15) - Number(prices.coupenamt)
          setPrice(prices)
        }
        break;
      case "twentyfive":
        if (data.twentyfive) {
          data.five = false
          data.fifteen = false
          data.twentyfive = false
          data.custom = false
          setCustomtip(0)
          var prices = { ...price }
          prices.tipamount = Number(0)
          prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) - Number(0) - Number(prices.coupenamt)
          setPrice(prices)
        }
        else {
          data.five = false
          data.fifteen = false
          data.twentyfive = true
          data.custom = false
          setCustomtip(0)
          var prices = { ...price }
          prices.tipamount = Number(25)
          prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) + Number(25) - Number(prices.coupenamt)
          setPrice(prices)
        }
        break;

      case "custom":
        if (data.twentyfive) {
          data.five = false
          data.fifteen = false
          data.twentyfive = false
          data.custom = true

        }
        else {
          data.five = false
          data.fifteen = false
          data.twentyfive = false
          data.custom = true

        }
        break;

      case "uncustom":

        data.five = false
        data.fifteen = false
        data.twentyfive = false
        data.custom = false
        var prices = { ...price }
        prices.tipamount = Number(0)
        prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) - Number(0) - Number(prices.coupenamt)
        setPrice(prices)
        break;

    }
    setTip(data)

  }

  const addcustom = () => {
    if (!customtip) {
      Toast.show("Please enter tip amount", Toast.SHORT);
    }
    else if (customtip < 1) {
      Toast.show("Please enter above 1 doller", Toast.SHORT);
    }
    else {
      tipvalidate("uncustom")
      var prices = { ...price }
      prices.tipamount = Number(customtip)
      prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) + Number(customtip) - Number(prices.coupenamt)
      setPrice(prices)
    }

  }

  const submit = async () => {




    const TOKEN = await AsyncStorage.getItem("UserToken")
    // console.log("TOKENTOKENTOKEN", TOKEN)
    var slicetoken = token.slice(7)
    console.log("test", slicetoken)

    var data = {
      "token": slicetoken,
      "d_type": deliverytype,
      "coupon": (coupen.status ? coupen.coupenid : ""),
      "note": message,
      "reward_amount_credit": points,
    }
    props.navigation.navigate("PaypalWebview1", {
      getdata: data
    })
  
    
  }

  const clearcoupen = () => {
    var data = { ...coupen }
    data.status = false
    data.coupenid = ""
    setCopen(data)


    var data1 = { ...storeprice }
    data1.coupenamt = 0
    setStoreprice(data1)
  }

  const PointsEntry = (text) => {


    console.log("text", text)
    if (Number(text) <= Number(profile.reward_points)) {
      setpoints(text)





      // Calculate rupees per point
      let rupeesPerPoint = Number(delivery.rewardpoints.usd) / Number(delivery.rewardpoints.reward_points);

      // Calculate the rupees for the target points
      let rupeesFor25Points = rupeesPerPoint * Number(text);

      console.log(`Rupees for 25 points: ${rupeesFor25Points}`);
      setpointamount(rupeesFor25Points.toFixed(2))


      if (Number(delivery.rewardpoints.min_order) <= Number(cart_total) - Number(rupeesFor25Points)) {

        let pointsPerRupee = Number(delivery.rewardpoints.reward_points) / Number(delivery.rewardpoints.min_order);

        // Calculate the points for the target rupees
        console.log(`tot ${Number(cart_total) - Number(rupeesFor25Points)}`);


        let pointsFor124Rupees = pointsPerRupee * (Number(cart_total) - Number(rupeesFor25Points))

        console.log(`Points for 124 rupees: ${pointsFor124Rupees}`);
        setrewardss(Math.round(pointsFor124Rupees))
        
      }
    }


  }
  const clearcustomtip = () => {
    var data = { ...tip }
    data.custom = false
    data.five = false
    data.fifteen = false
    data.twentyfive = false
    setCustomtip(0)
    setTip(data)

    var prices = { ...price }
    prices.tipamount = Number(0)
    prices.grandtotal = Number(prices.deliverycharge) + Number(cart_total) + Number(prices.tax) - Number(0) - Number(prices.coupenamt)
    setPrice(prices)

  }

  const selectpayment = (index, value) => {
    setPaymentmode(value)
  }
  console.log(`setrewardsssetrewardss: ${rewardss}`);

  return (
    <SafeAreaView style={{ width: "100%", height: "100%" }} >
      {/* <Header dataParentToChild={data} Back={() => props.navigation.goBack()} /> */}
      <View style={{ width: "100%", height: "7%", backgroundColor: "white", flexDirection: "row" }} >
        <View style={{ width: "15%", height: "100%", justifyContent: "center" }}  >
          <TouchableOpacity onPress={() => props.navigation.goBack()}  >
            <Image style={styles.back} source={require("../../Assets/back.png")} />
          </TouchableOpacity>
        </View>
        <View style={{ width: "70%", height: "100%", justifyContent: "center", }} >
          <Text style={styles.text1} >Checkout</Text>
        </View>
      </View>
      <View style={{ width: width, height: "68%", backgroundColor: "#f4f7fe" }} >
        <ScrollView>
          <Card style={{ width: width * 0.925, height: 'auto', marginTop: "5%", alignSelf: "center" }} >
            <Checkoutproducts />
          </Card>
          {coupen.status ?
            <Card style={{ width: width * 0.925, marginTop: "5%", alignSelf: "center" }} >
              <View style={{ flexDirection: "row" }}>
                <View style={{ width: "70%", justifyContent: "space-evenly" }} >
                  <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.04, marginLeft: "5%", color: "black" }} >SubTotal</Text>
                  <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.04, marginLeft: "5%", color: "black" }} >Coupon Discount</Text>
                  <Text style={{ marginTop: "5%", marginBottom: "5%", fontFamily: "Roboto-Medium", fontSize: width * 0.044, marginLeft: "5%", color: "black" }} >Cart Total</Text>
                </View>
                <View style={{ width: "30%", justifyContent: "space-evenly" }} >
                  <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "black", alignSelf: "flex-end", marginRight: "15%" }} >$ {parseFloat(cart_total).toFixed(2)}</Text>
                  <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "black", alignSelf: "flex-end", marginRight: "15%" }} >-$ {parseFloat(storeprice.coupenamt).toFixed(2)}</Text>
                  <Text style={{ marginTop: "5%", marginBottom: "5%", fontFamily: "Roboto-Medium", fontSize: width * 0.044, marginLeft: "5%", color: "black", alignSelf: "flex-end", marginRight: "15%" }} >$ {parseFloat(storeprice.sub_total + cart_total - storeprice.coupenamt).toFixed(2)}</Text>
                </View>
              </View>

            </Card>
            :
            <Card style={{ width: width * 0.92, marginTop: "5%", alignSelf: "center", justifyContent: "center", height: 50 }} >
              <View style={{ flexDirection: "row" }}>

                <View style={{ width: "70%", justifyContent: "center" }} >
                  <Text style={{ marginTop: "5%", fontFamily: "Roboto-Medium", fontSize: width * 0.044, marginLeft: "5%", color: "black" }} >SubTotal</Text>
                </View>
                <View style={{ width: "30%", justifyContent: "center", flexDirection: "row", alignItems: "center" }} >
                  {discount > 0 ?
                    <Text style={{ marginTop: "10%", marginRight: "6%", fontFamily: "Roboto-Light", fontSize: width * 0.035, color: "black", textDecorationLine: "line-through" }} >$ {parseFloat(cart_total + discount).toFixed(2)}</Text> : null}
                  <Text style={{ marginTop: "5%", fontFamily: "Roboto-Medium", fontSize: width * 0.044, color: "black", alignSelf: "flex-end", marginRight: "15%" }} >$ {parseFloat(cart_total).toFixed(2)}</Text>

                </View>
              </View>


              {/* <Card style={{ alignSelf: "center", borderRadius: 8, width: "70%", height: 30, backgroundColor: "#00a4ff", marginTop: 10, marginBottom: 15, justifyContent: "center", alignItems: "center" }}>
                <Text style={{ color: "white", fontSize: 15 }}>Your total savings  $ {parseFloat(discount).toFixed(2)}</Text>
              </Card> */}


            </Card>


          }

          <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginLeft: "5%", color: "black", marginTop: "5%" }} >Use Coupon code</Text>

          <Card style={{ width: width * 0.925, height: height * 0.1, marginTop: "2.5%", alignSelf: "center", flexDirection: "row", alignItems: "center" }} >
            <View style={{ width: "70%", height: "70%", justifyContent: "center" }} >
              {!coupen.status ?
                <Card style={show ? styles.card_container1 : styles.card_container}>

                  <TextInput
                    value={coupen.coupenid}
                    onFocus={() => setShow(true)}
                    onChangeText={(text) => {
                      var data = { ...coupen }
                      data.coupenid = text
                      data.err = false
                      setCopen(data)
                    }}
                    style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                    placeholder={'Enter the coupon code'}

                  />
                </Card>
                : <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "#00a4ff", marginLeft: "5%", marginTop: "2%" }} >Coupon Applied successfully!</Text>}
            </View>
            <View style={{ width: "30%", height: "55%", justifyContent: "center" }} >
              {!coupen.status ?
                <TouchableOpacity onPress={() => coupenapply()} style={{ width: "75%", height: "80%", alignSelf: 'center', backgroundColor: "#00a4ff", borderRadius: width * 0.015, justifyContent: "center" }} >
                  {loader.coupen ?
                    <ActivityIndicator color={"white"} /> :
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "white", textAlign: "center" }} >Apply</Text>}
                </TouchableOpacity> :
                <TouchableOpacity onPress={() => clearcoupen()} style={{ width: "75%", height: "80%", alignSelf: 'center', backgroundColor: "#00a4ff", borderRadius: width * 0.015, justifyContent: "center" }} >
                  <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "white", textAlign: "center" }} >Clear</Text>
                </TouchableOpacity>}

            </View>
          </Card>

          {/* {coupen.status ?
                 <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "#00a4ff",marginLeft:"5%",marginTop:"2%"}} >Coupen Applied successfully!</Text>:null} */}
          {coupen.err ?
            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "red", marginLeft: "5%", marginTop: "2%" }} >Please enter valid coupon*</Text> : null}






          {profile.reward_points !== '0' ?
            <Card style={{ width: width * 0.925, height: "auto", marginTop: "2.5%", paddingTop: 10, paddingBottom: 10, alignSelf: "center", }} >
              <View style={{ flexDirection: "row", marginLeft: 5 }} >
                <CheckBox
                  value={coinscheck}
                  tintColors={{ true: '#00a4ff', false: 'grey' }}
                  onValueChange={(value) => EnableSuperIcons(value)}
                />
                <View style={{ marginLeft: 2 }}>
                  <Text style={{ fontSize: 18, fontWeight: "700", color: "#00a4ff" }}>Pay Using SuperCoins</Text>
                  <View style={{ flexDirection: "row", alignItems: "center", marginTop: 3, }}>
                    <Text style={{ fontSize: 17, fontWeight: "400", color: "black" }}>Available Balance :</Text>
                    <View style={{ flexDirection: "row", alignItems: "center", marginLeft: 5 }}>
                      <Image style={{ height: 20, width: 20, resizeMode: "contain" }} source={require("../../Assets/star.png")}></Image>
                      <Text style={{ fontSize: 17, fontWeight: "400", color: "black", marginLeft: 2 }}>{profile.reward_points} </Text>
                    </View>
                  </View>
                </View>
              </View>
              {coinscheck ?
                <>
                  <Card style={{
                    width: "50%",
                    height: 50,
                    marginLeft: "10%",
                    borderRadius: width * 0.015,
                    justifyContent: "center",

                    borderWidth: width * 0.0025,
                    marginTop: 10,
                    marginBottom: 10
                  }}>

                    <TextInput
                      value={points}
                      onChangeText={(text) => PointsEntry(text)}
                      keyboardType='numeric'
                      style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", }}
                      placeholder={'Enter the coins'}

                    />
                  </Card>

                  <View style={{ flexDirection: "row", alignItems: "center", marginTop: 3, }}>
                    <Text style={{ fontSize: 16, fontWeight: "bold", color: "black", marginLeft: "10%" }}>Reducing Amount :</Text>
                    <View style={{ flexDirection: "row", alignItems: "center", marginLeft: 5 }}>
                      <Text style={{ fontSize: 16, fontWeight: "bold", color: "black", marginLeft: 2 }}>$ {pointamount} </Text>
                    </View>
                  </View>
                </>

                : null}

              {Animateing ?
                <Animated.View style={[styles.gifContainer, { opacity }]}>
                  <Image
                    style={styles.gif}
                    source={require("../../Assets/output-onlinegiftools.gif")} // Replace with your GIF URL
                  />
                </Animated.View>
                : null}
            </Card>


            : null}








          {/****************************Delivery Charge******************************************/}

          <>
            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginLeft: "5%", color: "black", marginTop: "5%" }} >Select Delivery Type</Text>
            <Card style={{ width: width * 0.925, height: height * 0.15, alignSelf: "center", borderRadius: width * 0.03, marginTop: "2.5%", flexDirection: "row", }} >
              <RadioGroup
                style={{ width: "100%", justifyContent: "center" }}
                formHorizontal={false}
                labelHorizontal={true}
                color="#00a4ff"
                size={width * 0.05}
                selectedIndex={radioindex}
                thickness={width * 0.004}
                onSelect={(index, value) => selecttype(index, value)}
              >
                <RadioButton style={{ alignItems: 'center' }} value={'standard'} >
                  <View style={{ width: "100%", flexDirection: "row" }} >
                    <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0435, color: "black", marginLeft: "3%" }} >Standard Delivery</Text>
                    <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.0435, color: "black", marginLeft: "3%" }} >(Within 48 hours)</Text>
                  </View>
                </RadioButton>
                <RadioButton style={{ alignItems: 'center' }} value={'sameday'}>
                  <View style={{ width: "100%", flexDirection: "row" }} >
                    <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0435, color: "black", marginLeft: "3%" }} >Express Delivery</Text>
                    <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.0435, color: "black", marginLeft: "3%" }} >(Within 24 hours)</Text>
                  </View>
                </RadioButton>
              </RadioGroup>

            </Card>
          </>

          {/****************************Delivery Tip******************************************/}

          {props.route.params.type == "Delivery" ?
            <Card style={{ width: width * 0.925, height: height * 0.2, alignSelf: "center", borderRadius: width * 0.03, marginTop: "5%", }} >
              <View style={{ width: "100%", height: "55%", justifyContent: "center" }}  >
                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.044, color: "black", marginLeft: "5%" }} >Tip your delivery partner</Text>
                <Text style={{ width: "75%", fontFamily: "Roboto-Light", fontSize: width * 0.035, color: "black", marginLeft: "5%" }} >Your kindness means a lot! 100% of your tip will go directly to your partner</Text>
              </View>

              <View style={{ width: "100%", height: "45%", alignItems: "center", flexDirection: "row", justifyContent: "space-evenly" }}  >

                {tip.custom ?

                  <View style={{ width: "100%", height: "45%", alignItems: "center", flexDirection: "row", justifyContent: "space-evenly" }}  >

                    <TouchableOpacity onPress={() => tipvalidate("uncustom")} style={{ marginTop: "5%", marginBottom: "5%", width: "26%", height: "100%", borderWidth: width * 0.002, borderColor: "#00a4ff", borderRadius: width * 0.03, alignItems: "center", flexDirection: "row", justifyContent: "space-evenly", backgroundColor: "#d0f0c0" }} >
                      <Image style={{ width: 18, height: 18, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/party.png")} />
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >Custom</Text>
                    </TouchableOpacity>

                    <TextInput keyboardType='numeric'
                      value={customtip}
                      onChangeText={(value) => setCustomtip(value)}
                      style={{ color: "black", textAlign: "center", fontSize: 14, height: 40, color: "black", width: "45%", borderBottomWidth: 1, borderBottomColor: "#00a4ff" }}
                    />

                    <TouchableOpacity onPress={() => addcustom()} style={{ width: '15%', alignItems: "center", justifyContent: "center", marginTop: "5%", height: "100%" }}>
                      <Text style={{ fontSize: 17, textAlign: "center", color: "#00a4ff", fontWeight: "700" }}>Add</Text>
                    </TouchableOpacity>

                  </View> :
                  <>
                    <TouchableOpacity onPress={() => tipvalidate("five")} style={!tip.five ? styles.tip_amt : styles.tip_amt1} >
                      <Image style={{ width: 18, height: 18, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/smile.png")} />
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >$5</Text>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => tipvalidate("fifteen")} style={!tip.fifteen ? styles.tip_amt : styles.tip_amt1} >
                      <View style={!tip.fifteen ? { width: "100%", height: "65%", alignItems: "center", flexDirection: "row", justifyContent: "space-evenly" } : { width: "100%", height: "65%", alignItems: "center", flexDirection: "row", justifyContent: "space-evenly", backgroundColor: "#f8fff8" }} >
                        <Image style={{ width: 18, height: 18, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/care.png")} />
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >$15</Text>
                      </View>



                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => tipvalidate("twentyfive")} style={!tip.twentyfive ? styles.tip_amt : styles.tip_amt1} >
                      <Image style={{ width: 18, height: 18, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/emoji.png")} />
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >$25</Text>
                    </TouchableOpacity>



                    {customtip > 0 ?
                      <View style={{ width: "30%", height: "100%", justifyContent: "space-around" }} >

                        <TouchableOpacity onPress={() => tipvalidate("custom")} style={(customtip < 0) ? { width: "100%", height: "60%", borderWidth: width * 0.002, borderColor: "#9e9e9e57", borderRadius: width * 0.03, alignItems: "center", flexDirection: "row", justifyContent: "space-evenly" } : { width: "100%", height: "60%", borderWidth: width * 0.002, borderColor: "#00a4ff", borderRadius: width * 0.03, alignItems: "center", flexDirection: "row", justifyContent: "space-evenly", backgroundColor: "#f8fff8" }} >
                          <Image style={{ width: 18, height: 18, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/party.png")} />
                          {customtip < 0 ?
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >Custom</Text> :
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >${customtip}</Text>}
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => clearcustomtip()} style={{ width: "50%", height: "30%", alignSelf: "center", backgroundColor: "#00a4ff", borderRadius: 7, justifyContent: "center", alignItems: "center" }} >
                          <Text style={{ textAlign: "center", color: "white", width: "100%" }} >Clear</Text>
                        </TouchableOpacity>
                      </View>
                      :
                      <TouchableOpacity onPress={() => tipvalidate("custom")} style={{ width: "30%", height: "60%", borderWidth: width * 0.002, borderColor: "#9e9e9e57", borderRadius: width * 0.03, alignItems: "center", flexDirection: "row", justifyContent: "space-evenly" }} >
                        <Image style={{ width: 18, height: 18, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/party.png")} />

                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "black" }} >Custom</Text>
                      </TouchableOpacity>}

                  </>
                }



              </View>
            </Card> : null}



          {/****************************Over all Total******************************************/}
          <Card style={{ width: width * 0.925, height: "auto", alignSelf: "center", borderRadius: width * 0.03, marginTop: "5%", justifyContent: "space-evenly" }} >
            <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
              <View style={{ width: "65%" }}>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginLeft: "6%", }} >Cart total</Text>
              </View>
              <View style={{ width: "35%", flexDirection: "row", justifyContent: "flex-end", alignItems: "center" }}>

                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", textAlign: "right", marginRight: 5 }} >$ {parseFloat(cart_total - storeprice.coupenamt).toFixed(2)}</Text>
                {coinscheck ?
                  <View style={{ flexDirection: "row", alignItems: "center", }}>
                    <Text style={{ fontSize: 17, fontWeight: "400", color: "black", marginLeft: 2 }}>+ </Text>

                    <Image style={{ height: 20, width: 20, resizeMode: "contain" }} source={require("../../Assets/star.png")}></Image>
                    <Text style={{ fontSize: width * 0.035, fontWeight: "500", color: "black", marginLeft: 2 }}>{points} </Text>
                  </View>
                  :
                  null}
              </View>
            </View>

            <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
              <View style={{ width: "70%", flexDirection: "row", alignItems: "center" }}>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginLeft: "5%" }} >Packing Charge</Text>
                {/* <Image style={{ width: 17, height: 17, resizeMode: "contain", alignSelf: "center", marginLeft: "2%" }} source={require("../../Assets/iexample.png")} /> */}
              </View>
              <View style={{ width: "30%", }}>
                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", textAlign: "right", marginRight: "10%" }} >$ {parseFloat(storeprice.pack_charge).toFixed(2)}</Text>
              </View>
            </View>

            <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
              <View style={{ width: "70%", flexDirection: "row", alignItems: "center" }}>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginLeft: "5%" }} >Shipping Charge</Text>
                {/* <Image style={{ width: 17, height: 17, resizeMode: "contain", alignSelf: "center", marginLeft: "2%" }} source={require("../../Assets/iexample.png")} /> */}
              </View>
              <View style={{ width: "30%", }}>
                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", textAlign: "right", marginRight: "10%" }} >$ {parseFloat(storeprice.shipping_chagre).toFixed(2)}</Text>
              </View>
            </View>




            {price.deliverycharge > 0 ?
              <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
                <View style={{ width: "70%", flexDirection: "row", alignItems: "center" }}>
                  <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginLeft: "5%" }} >Delivery Charges</Text>
                  {/* <Image style={{ width: 17, height: 17, resizeMode: "contain", alignSelf: "center", marginLeft: "2%" }} source={require("../../Assets/iexample.png")} /> */}
                </View>
                <View style={{ width: "30%", }}>
                  <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", textAlign: "right", marginRight: "10%" }} >$ {parseFloat(price.deliverycharge).toFixed(2)}</Text>
                </View>
              </View>
              :
              (cart_total > minimum_charge) && (minimum_charge != 0) && (props.route.params.type == "Delivery") && deliverytype ?
                <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
                  <View style={{ width: "70%", flexDirection: "row", alignItems: "center" }}>
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginLeft: "5%" }} >Delivery Charges</Text>
                    {/* <Image style={{ width: 17, height: 17, resizeMode: "contain", alignSelf: "center", marginLeft: "2%" }} source={require("../../Assets/iexample.png")} /> */}
                  </View>
                  <View style={{ width: "30%", }}>
                    <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", textAlign: "right", marginRight: "10%" }} > <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "grey", textDecorationLine: "line-through" }}>{delivery.standard_charge.actual_shipping_charge}</Text>  FREE</Text>
                  </View>
                </View> : null}



            {storeprice.coupenamt > 0 ?
              <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
                <View style={{ width: "70%" }}>
                  <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginLeft: "5%" }} >Coupon amount</Text>
                </View>
                <View style={{ width: "30%" }}>
                  <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", textAlign: "right", marginRight: "10%" }} >- $ {parseFloat(storeprice.coupenamt).toFixed(2)}</Text>
                </View>
              </View> : null}



            <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center" }} >
              <View style={{ width: "60%" }}>
                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.044, color: "black", marginLeft: '6%' }} >Grand Total</Text>
              </View>
              <View style={{ width: "40%", flexDirection: "row", justifyContent: "flex-end", alignItems: "center" }}>
                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.044, color: "black", textAlign: "right", marginRight: 5 }} >$ {parseFloat(storeprice.grandtotal - storeprice.coupenamt).toFixed(2)}</Text>

                {coinscheck ?
                  <View style={{ flexDirection: "row", alignItems: "center", }}>
                    <Text style={{ fontSize: 17, fontWeight: "400", color: "black", marginLeft: 2 }}>+ </Text>

                    <Image style={{ height: 20, width: 20, resizeMode: "contain" }} source={require("../../Assets/star.png")}></Image>
                    <Text style={{ fontSize: width * 0.044, fontWeight: "500", color: "black", marginLeft: 2 }}>{points} </Text>
                  </View>
                  :
                  null}

              </View>
            </View>

            {rewardss != 0 ?
              <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center", justifyContent: "center" }} >

                <Text style={{ fontWeight: "500", fontStyle: "italic", fontSize: width * 0.035, color: "red", }} >You will get {rewardss} points for this order</Text>

              </View>
              :
              null}
          </Card>

          <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginLeft: "5%", color: "black", marginTop: "5%" }} >Notes :</Text>
          <Card style={{ borderColor: "f2f2f2", borderWidth: 1, width: "90%", height: 100, marginTop: 10, marginBottom: 20, borderRadius: 15, marginLeft: 15 }} >
            {/* <View style={{width:"50%"}}> */}

            <TextInput value={message} multiline={true} onChangeText={(newValue) => setmessage(newValue)} style={{ color: "black", padding: 10, width: "100%", }} />
            {/* </View> */}
          </Card>

          {/* <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginLeft: "5%", color: "black", marginTop: "5%" }} >Select Payment method</Text> */}
          {/* 
          <Card style={{ width: width * 0.925, marginBottom: "5%", height: height * 0.15, alignSelf: "center", borderRadius: width * 0.03, marginTop: "2.5%", flexDirection: "row", }} >
            <RadioGroup
              style={{ width: "100%", justifyContent: "center" }}
              formHorizontal={false}
              labelHorizontal={true}
              color="#00a4ff"
              size={width * 0.05}
              thickness={width * 0.004}
              // selectedIndex={0}
              onSelect={(index, value) => selectpayment(index, value)}
            >



              <RadioButton style={{ alignItems: 'center' }} value={'paypal'} >
                <View style={{ width: "100%", height: height * 0.025, }} >
                  <Image style={{ width: width * 0.2, height: height * 0.025, resizeMode: "cover", alignSelf: "center", marginLeft: "5%" }} source={require('../../Assets/paypal.png')} />
                </View>
              </RadioButton>

              <RadioButton style={{ alignItems: 'center' }} value={'cod'}>
                <View style={{ width: "100%", flexDirection: "row" }} >
                  <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0435, color: "black", marginLeft: "3%" }} >{props.route.params.type == "Delivery" ? "Pay at the time of Delivery" : "Pay at the time of Pickup"}</Text>
                </View>
              </RadioButton>
            </RadioGroup>

          </Card> */}


        </ScrollView>
      </View>





      <View style={{ width: width, height: "25%" }} >


        <Card style={{ width: "100%", height: "75%", backgroundColor: "white", borderTopLeftRadius: width * 0.04, borderTopRightRadius: width * 0.04 }} >

          <View style={{ width: "100%", height: "52.5%", flexDirection: "row", borderBottomWidth: width * 0.002, borderColor: '#9e9e9e57' }} >
            <View style={{ width: "15%", height: "100%", justifyContent: "center" }} >

              <Image style={{ width: 25, height: 25, resizeMode: "contain", alignSelf: "center", }} source={require("../../Assets/house1.png")} />
            </View>
            <View style={{ width: "67.5%", height: "100%", justifyContent: "center" }} >
              <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, color: "black" }} >{"Delivery to "}</Text>

              <Text numberOfLines={2} style={{ fontFamily: "Roboto-Light", fontSize: width * 0.03, color: "black" }} >{props.route.params.data.type},{props.route.params.data.address1},{props.route.params.data.address2}, {props.route.params.data.city}, {props.route.params.data.state}, {props.route.params.data.zipcode}</Text>

            </View>

          </View>


          <View style={{ width: "100%", height: "47.5%", flexDirection: "row", }} >
            <View style={{ width: "40%", height: "100%", justifyContent: "center" }} >
              <View style={{ width: "90%", height: "80%", alignSelf: "center", }} >
                <View style={{ width: "100%", height: "50%", flexDirection: "row", alignItems: "center", justifyContent: "space-evenly" }} >
                  <Image style={{ width: 17, height: 17 }} source={require("../../Assets/pay.png")} />
                  <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black" }} >{"PAY USING"}</Text>
                  {/* {paymentmode == "paypal" ?
                    <Image style={{ width: 17, height: 17 }} source={require("../../Assets/upward.png")} /> : null} */}
                </View>

                <View style={{ width: "100%", height: 20, justifyContent: "center", }} >

                  <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.0375, color: "black", textAlign: "center" }} >Paypal</Text>

                </View>

              </View>
            </View>

            <View style={{ width: "60%", height: "100%", justifyContent: "center" }} >
              <Card style={{ width: "90%", height: 50, backgroundColor: '#00a4ff', borderRadius: width * 0.03, alignSelf: "center", }} >
                {loader.order ?
                  <ActivityIndicator color={"white"} /> :
                  <Pressable onPress={() => submit()} style={{ width: "100%", height: "100%", flexDirection: "row", alignItems: "center", }}  >
                    <View style={{ width: "30%", marginLeft: "5%", }} >
                      {coinscheck ?
                        <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.04, color: "white" }} >$ {parseFloat((storeprice.grandtotal - storeprice.coupenamt) - pointamount).toFixed(2)}</Text>
                        :
                        <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.04, color: "white" }} >$ {parseFloat(storeprice.grandtotal - storeprice.coupenamt).toFixed(2)}</Text>
                      }

                      <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.035, color: "white" }} >TOTAL</Text>

                    </View>

                    <View style={{ width: "50%", flexDirection: "row", alignItems: "center", justifyContent: "space-around", marginLeft: "10%" }} >
                      <Text style={{ fontFamily: "Roboto-Regular", fontWeight: "600", fontSize: width * 0.0425, color: "white" }} >Place order</Text>
                      <Image style={{ width: 12, height: 12 }} source={require("../../Assets/rightarrow.png")} />
                    </View>
                  </Pressable>}
              </Card>
            </View>

          </View>

        </Card>
      </View>
    </SafeAreaView >
  )


}

const styles = StyleSheet.create({



  gifContainer: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -100 }, { translateY: -100 }], // Adjust based on GIF size
  },
  gif: {
    width: 200,
    height: 200,
  },


  card_container: {
    width: width * 0.9,
    height: height * 0.06,
    alignSelf: "center",
    marginTop: "3%",
    borderRadius: width * 0.015,
    justifyContent: "center",
    borderColor: "gray",
    borderWidth: width * 0.00075
  },
  card_container1: {
    width: "95%",
    height: "80%",
    alignSelf: "center",
    borderRadius: width * 0.015,
    justifyContent: "center",
    borderColor: "#00a4ff",
    borderWidth: width * 0.0025
  },
  card_container: {
    width: "95%",
    height: "80%",
    alignSelf: "center",
    borderRadius: width * 0.015,
    justifyContent: "center",
    borderColor: "gray",
    borderWidth: width * 0.001
  },
  tip_amt: {
    width: "20%",
    height: "60%",
    borderWidth: width * 0.002,
    borderColor: "#9e9e9e57",
    borderRadius: width * 0.03,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-evenly"
  },
  tip_amt1:
  {
    width: "20%",
    height: "60%",
    borderWidth: width * 0.002,
    borderColor: "#00a4ff",
    borderRadius: width * 0.03,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-evenly",
    backgroundColor: "#f8fff8"
  },
  header: {
    width: "100%",
    height: height * 0.075,
    backgroundColor: "white",
    flexDirection: "row",
    alignItems: "center"
  },
  back: {
    width: width * 0.05,
    height: height * 0.03,
    alignSelf: "center",
  },
  text1: {
    fontSize: width * 0.0475,
    fontFamily: "Roboto-Bold",
    color: "black"
  },
})