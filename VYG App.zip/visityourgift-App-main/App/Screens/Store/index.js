import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions,StyleSheet, ImageBackground,Animated,FlatList,Modal, ScrollView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import Search from '../../Components/search';
import { AnimatedScrollView } from '@kanelloc/react-native-animated-header-scroll-view';
import StarRating from 'react-native-star-rating-widget';
import Homeproducts from '../../Components/Homeproducts';
import { Recommendedproduct, TopsellingProducts } from '../TestData/data';
import Categories from '../../Components/Categories';
import Helperhome from '../../Components/helperhome';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import Productdetail from '../../Components/productdetail';

const{width,height}=Dimensions.get("window")
export default function Store (props,navigation) {
    const[heart,setHeart]=useState(false)
    const data = {
        name:'Store detail',
        search:false
    }
    return(
        <View style={styles.container} >
        <Header Back={() => props.navigation.goBack()} dataParentToChild={data}/>
        <Helperhome/>
        <ScrollView>
       
        <Card style={{width:width*0.95,height:height*0.175,alignSelf:"center",marginTop:"5%",flexDirection:"row"}} >
            <View style={{width:"30%",height:"100%",justifyContent:"space-evenly",alignItems:"center",}} >
                  <View style={{width:"80%",height:"70%",borderWidth:width*0.005,borderColor:'#f7cb48',alignSelf:"center",borderRadius:width*0.025}} >
                        <Image style={{width:"100%",height:"100%",borderRadius:width*0.02}} source={require('../../Assets/store1.jpg')} />
                  </View>
                  <View style={{width:"80%",height:"17%",justifyContent:"center"}} >
                  <StarRating
           rating={4}
           starSize={width*0.045}
           starStyle={{width:width*0.015,}}
           color={"#00a4ff"}
           maxStars={5}
        //    onChange={() => Rating(3) }
      />
                  </View>
               
            </View>
            <View style={{width:"70%",height:"90%",alignSelf:"center",justifyContent:"space-evenly"}} >
                <View style={{width:"100%",height:"auto",flexDirection:'row'}} >
                    <View style={{width:"75%",height:"auto",}} >
                    <Text style={{color:"black",fontFamily:"Roboto-Bold",fontSize:width*0.04}} >Guru Maligai (p) ltd </Text>
                    </View>
                   <Pressable onPress={() => {heart ? setHeart(false) : setHeart(true)}} style={{width:"12.5%",height:height*0.03,justifyContent:"center"}} >
                   {heart ?
                        <Image style={{width:"80%",height:"80%",resizeMode:"contain",alignSelf:"center"}} source={require("../../Assets/heart1.png")}  />:
                        <Image style={{width:"80%",height:"80%",resizeMode:"contain",alignSelf:"center"}} source={require("../../Assets/heart2.png")}  />}
                   </Pressable>
                   <View style={{width:"12.5%",height:height*0.03,justifyContent:"center"}} >
                        <Image style={{width:"80%",height:"80%",resizeMode:"contain",alignSelf:"center"}} source={require("../../Assets/share.png")}  />
                   </View>
                </View>

             <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >Kk nagar idbi bank,madurai,tamilnadu</Text>
             <View style={{width:"100%",height:"auto",flexDirection:"row",}} >
              <View style={{width:"40%",height:"100%",}} >
              <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >Shop opens</Text>
              <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >Delivery Times</Text>
              </View>
              <View style={{width:"5%",height:"100%",}} >
              <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >:</Text>
              <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >:</Text>
              </View>
              <View style={{width:"55%",height:"100%",}} >
              <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >Monday to Friday</Text>
              <Text style={{color:"black",fontFamily:"Roboto-Light",fontSize:width*0.0325,marginTop:"1%"}} >09:00am to 08:00pm</Text>
              </View>
             </View>

             <View>

             </View>
            </View>

        </Card>
   
   <Text style={{fontFamily:"Roboto-Medium",marginLeft:"2.5%",fontSize:width*0.045,marginTop:"5%"}} >Top Selling Products</Text>
      <Text style={{fontFamily:"Roboto-Light",marginLeft:"2.5%",fontSize:width*0.035}} >56 Products</Text>

         <View style={{width:"100%",height:"auto",backgroundColor:"#d3d3d33d",marginTop:"2.5%",marginBottom:"2.5%",alignItems:"center"}} >
      <Homeproducts dataParentToChild={TopsellingProducts} />
      </View>

    <Helperhome/>
       <Text style={{fontFamily:"Roboto-Medium",marginLeft:"2.5%",fontSize:width*0.045,marginTop:"2.5%",}} >Categories</Text>
      <View style={{width:"100%",height:"auto",backgroundColor:"white",marginTop:"2.5%",alignItems:"center",marginBottom:"2.5%",}} >
      <Categories Searchcall={() => props.navigation.navigate("Productscategory")}  />
      </View>
      <Helperhome/>
      <Text style={{fontFamily:"Roboto-Medium",marginLeft:"2.5%",fontSize:width*0.045,marginTop:"2.5%",}} >Recommanded Products</Text>
      <View style={{width:"100%",height:"auto",backgroundColor:"#d3d3d33d",marginTop:"2.5%",marginBottom:"30%",alignItems:"center"}} >
      <Homeproducts dataParentToChild={Recommendedproduct} />
      </View>

        </ScrollView>
        <Productdetail  viewdetailcall ={() => props.navigation.navigate("Imagegallery") } />
        </View>
    )

}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"white"
    },
    header:{
        width:"100%",
        height:height*0.075,
        backgroundColor:"white",
        flexDirection:"row",
        alignItems:"center"
    },
    back:{
        width:width*0.05,
        height:height*0.03,
        alignSelf:"center", 
    },
    text1:{
        fontSize:width*0.0475,
        // fontWeight:"600",
        textAlign:"center",
        marginLeft:"5%",
        fontFamily:"Roboto-Bold"
    },
   
})