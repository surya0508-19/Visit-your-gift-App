import React, { useEffect } from "react";
import { View, Text, TouchableOpacity, Modal, Image, SafeAreaView } from "react-native";
import { WebView } from 'react-native-webview'
import { useDispatch, useSelector } from "react-redux";
import { cart_empty, fetchcart } from "../../Slices/cart";
import { authSelector } from '../../Slices/auth';
import { fetchorders } from "../../Slices/orders";
import { getnotificationlist } from "../../Slices/profile";
import { createorder } from "../Checkout/api";
import { PAYAPAL_URL } from "../../Constants";


export default function PaypalWebview1(props, { route }) {
    const dispatch = useDispatch()
    const { token } = useSelector(authSelector)
    useEffect(() => {

        console.log("gettdataa", props.route.params.getdata)


    }, [])

    const CashOnDelivery = async () => {



        var data = {
            "location_mode": "Delivery",
            "d_type": props.route.params.getdata.d_type,
            "coupon": props.route.params.getdata.coupon,
            "tip_amount": props.route.params.getdata.tip_amount,
            "note": props.route.params.getdata.note
        }
        console.log(data, "data")

        const output = await createorder(data, token)
        if (output.message == "Order created successfully") {

            props.navigation.navigate("Confirmorder", {
                order_id: output.order_id,
                token: token
            })
            dispatch(fetchcart(token))
            dispatch(cart_empty())
            dispatch(getnotificationlist(token))
            dispatch(fetchorders(token))
        }


    }


    const handleResponse = data => {

        console.log("responseeeee", data)
        if (data.url == `${PAYAPAL_URL}paypalsuccess`) {


            dispatch(fetchcart(token))
            dispatch(cart_empty())
            dispatch(getnotificationlist(token))
            dispatch(fetchorders(token))
            setTimeout(() => {
                props.navigation.navigate('Home')

            }, 3000);

        }
        if (data.url == `${PAYAPAL_URL}continue_shopping`) {


            props.navigation.navigate('Home')
        }
        if (data.url == `${PAYAPAL_URL}cash-on-delivery`) {


            var data = {
                "location_mode": "Delivery",
                "d_type": props.route.params.getdata.d_type,
                "coupon": props.route.params.getdata.coupon,
                "tip_amount": props.route.params.getdata.tip_amount,
                "note": props.route.params.getdata.note,
                'reward_amount_credit': props.route.params.getdata.reward_amount_credit,
            }

            props.navigation.navigate("Confirmorder", {
                body: data,

            })


        }
    };


    return (
        <SafeAreaView style={{ width: "100%", height: "100%" }}>
            <View style={{ width: "100%", height: "100%", justifyContent: "center", alignItems: "center" }}>


                <View style={{ width: "100%", height: "100%" }}>

                    <WebView
                        source={{ uri: `${PAYAPAL_URL}mobilePaypal/?token=` + props.route.params.getdata.token + "&reward_amount_credit=" + props.route.params.getdata.reward_amount_credit + "&coupon=" + props.route.params.getdata.coupon + "&delivery_type=" + props.route.params.getdata.d_type + "&note=" + props.route.params.getdata.note }}
                        onNavigationStateChange={data =>
                            handleResponse(data)
                        }
                        startInLoadingState={true}
                        scalesPageToFit={"isAndroid" ? false : true}
                        injectedJavaScript={`document.f1.submit()`}
                    />


                </View>


            </View>
        </SafeAreaView>

    );
}
