import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions,StyleSheet,TextInput, ImageBackground,Animated,FlatList,Modal, ScrollView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import Search from '../../Components/search';
import { AnimatedScrollView } from '@kanelloc/react-native-animated-header-scroll-view';
import StarRating from 'react-native-star-rating-widget';
import Homeproducts from '../../Components/Homeproducts';
import { Recommendedproduct, TopsellingProducts } from '../TestData/data';
import Categories from '../../Components/Categories';
import Helperhome from '../../Components/helperhome';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import Bestoffers from '../../Components/Bestoffers';
import Grocerystores from '../../Components/Grocerystores';
import { getStores, modelSelector } from '../../Slices/model';
import { useDispatch, useSelector } from 'react-redux';
import Storefilter from '../../Components/storefilter';

const{width,height}=Dimensions.get("window")
export default function Allstores (props,navigation) {
    const{stores} =useSelector(modelSelector)
    console.log("test",stores)
    const dispatch = useDispatch()
    const[search,setSearch]=useState('')

    const modelopen = () => {

        dispatch(getStores(true))
    }
  return(
    <View style={styles.container} >
    <View style={styles.header} >
    <View style={{width:"15%",height:"100%",justifyContent:"center"}}  >
    <TouchableOpacity onPress={() => props.navigation.goBack()}  >
    <Image style={styles.back} source={require("../../Assets/back.png")} />
    </TouchableOpacity>
    </View>
    <View style={{width:"65%",height:"100%",justifyContent:"center",}} >
    <Text style={styles.text1} >Stores in your location</Text>
    </View>
 
    <View style={{width:"20%",height:"100%",justifyContent:"center",}}  >
    <TouchableOpacity onPress={() => modelopen()}  >
    <Image style={styles.search} source={require("../../Assets/funnel.png")} />
    </TouchableOpacity>
    </View>
    </View>
   <Helperhome />
   <View style={{width:width,height:height*0.075,justifyContent:"center"}} >
       <Card style={{width:width*0.9,height:"80%",alignSelf:"center",flexDirection:"row"}} >
          <View style={{width:"15%",height:"100%",justifyContent:"center"}} >
          <Image style={styles.search} source={require("../../Assets/search.png")} />
          </View>
          <View style={{width:"70%",height:"100%",justifyContent:"center"}} >
          <TextInput
                   value={search}
                   onChangeText={(text) => setSearch(text)}
                  style={{width:"100%",height:"100%",fontSize:width*0.04,fontFamily:"Roboto-Regular",fontWeight:"600"}}
                  placeholder='Search' />
            </View>
            <Pressable  onPress={() => setSearch('') } style={{width:"15%",height:"100%",justifyContent:"center"}} >
          <Image style={styles.search} source={require("../../Assets/exit.png")} />
          </Pressable>
       </Card>

    
   </View>

   <View style={{width:width,height:height*0.84,marginTop:"2.5%",backgroundColor:"#d3d3d33d"}} >

    <Grocerystores shopdetail={() => props.navigation.navigate("Store") } />
   </View>
    <Storefilter />
    </View>

  )
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#ffffff'
    },
    header:{
        width:"100%",
        height:height*0.075,
        backgroundColor:"white",
        flexDirection:"row",
        alignItems:"center"
    },
    back:{
        width:width*0.05,
        height:height*0.03,
        alignSelf:"center", 
    },
    text1:{
        fontSize:width*0.0475,
        fontFamily:"Roboto-Bold"
    },
    search:{
        width:22,
        height:22,
        alignSelf:"center", 
     resizeMode:"contain"
    },
})