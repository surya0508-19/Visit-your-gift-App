import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, FlatList, StyleSheet } from 'react-native';
import { productpics } from '../TestData/data';
import { Card } from 'react-native-shadow-cards';
import GallerySwiper from "react-native-gallery-swiper";
import Gallery from 'react-native-image-gallery';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import Helperhome from '../../Components/helperhome';
import { getdetail } from '../../Slices/model';
import { useDispatch, useSelector } from 'react-redux';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
const { width, height } = Dimensions.get("window")
export default function Imagegallery({ navigation }) {
    const dispatch = useDispatch()
    const flatlistRef = useRef(null)
    useEffect(() => {
        setHorizontal(productpics)
    }, [])
    const [horizontal, setHorizontal] = useState(0)

    const [active, setActive] = useState(0)

    const switchindex = (value) => {

        if (value > 0) {
            flatlistRef.current.scrollToIndex({ index: (value), animated: true })
        }

        setActive(value)
    }

    // const trigger = () => {
    //     if(value >0)
    //     {
    //         flatlistRef.current.scrollToIndex({ index:value, animated: true })
    //     }else
    //     {
    //         flatlistRef.current.scrollToIndex({ index:0 , animated: true })
    //     }
    // }

    // const onViewCallBack = React.useCallback((viewableItems) => {

    //     const muthu = [...viewableItems.viewableItems]
    //     var final = muthu.pop().index
    //     console.log("test",(final-2))
    //     setHorizontal(final - 2)

    //   }, [])

    const exit = () => {
        navigation.goBack()
        dispatch(getdetail(true))
    }
    return (
        <View style={{ flex: 1, backgroundColor: "white" }} >
            {/* <View style={{ width: width, height: height * 0.03 }} /> */}
            <View style={{ width: width, height: height * 0.8, alignItems: "center" }} >
                <View style={{ width: width, height: "12.5%", alignItems: "center", justifyContent: "center" }} >
                    <TouchableOpacity onPress={() => exit()} style={{ width: "12%", height: "60%", backgroundColor: '#b6b6b6', alignSelf: "flex-end", right: "5%", borderRadius: width * 0.1, justifyContent: "center" }} >
                        <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/reject.png')} />
                    </TouchableOpacity>
                </View>
                <View style={{ width: width, height: "80%", backgroundColor: "red", alignItems: "center" }} >
                    <GallerySwiper
                        sensitiveScroll={false}
                        style={{ flex: 1, backgroundColor: 'white' }}
                        images={productpics}
                        initialPage={active}
                        onPageSelected={(index) => switchindex(index)}
                    />
                </View>
            </View>
            <View style={{ width: width, height: height * 0.2, alignItems: "center", backgroundColor: "white", }} >
                <FlatList
                    data={productpics}
                    showsHorizontalScrollIndicator={false}
                    //    onViewableItemsChanged={onViewCallBack}
                    ref={flatlistRef}
                    horizontal={true}
                    renderItem={({ item, index }) => (
                        <Card style={(index == active) ? styles.conatiner : styles.conatiner1} >
                            <Pressable style={{ justifyContent: "center" }} onPress={() => switchindex(index)} >
                                <Image style={{ width: "80%", height: "80%", alignSelf: "center", resizeMode: "contain" }} source={item.source} />
                            </Pressable>
                        </Card>
                    )
                    }
                />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    conatiner: {
        width: width * 0.3,
        height: '80%',
        margin: width * 0.03,
        justifyContent: "center",
        borderWidth: width * 0.002,
        borderColor: '#00a4ff'
    },
    conatiner1: {
        width: width * 0.3,
        height: '80%',
        margin: width * 0.03,
        justifyContent: "center",
    }
})