
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, Linking } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';


export default function Faq(props) {
    const { width, height } = Dimensions.get("window")

    const data = {
        name:'FAQ',
        search:false
    }
    return (
        <View style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />

            <View style={{ width: width, height: height * 0.935, backgroundColor: "white",marginTop:"2%" }}>

                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "black", width: "95%", marginLeft: "3%" }} >     The following are our governing terms.

                    Kindly read the following terms of use. By using the platform, you acknowledge your willingness and consent to relieve us of all liability.

                    Kindly read the following terms of use. By using the platform, you acknowledge your willingness and consent to relieve us of all liability.

                    Kindly read the following terms of use. By using the

                    platform, you acknowledge your willingness and

                    consent to relieve us of all liability. Kindly read the following terms of use. By using the

                    platform, you acknowledge your willingness and

                    consent to relieve us of all liability.

                    Kindly read the following terms of use. By using the platform, you acknowledge your willingness and consent to relieve us of all liability.

                    Kindly read the following terms of use. By using the platform, you acknowledge your willingness and consent to relieve us of all liability. Kindly read the following terms of use. By using the

                    consent to relieve us of all liability

                    Done</Text>
            </View>

        </View>
    )
}