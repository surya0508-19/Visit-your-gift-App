import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, TextInput, KeyboardAvoidingView, SafeAreaView, ScrollView, ActivityIndicator } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-async-storage/async-storage';

import styles from './style';
import { useDispatch, useSelector } from 'react-redux';
import { addaddress, addressSelector, editaddress, updateaddress, updateerr } from '../../Slices/address';
import { authSelector } from '../../Slices/auth';
import { fetchdeivery } from '../../Slices/deliverycharge';
// import { SafeAreaView } from 'react-native-safe-area-context';


const Addaddress = (props, navigation) => {

    const dispatch = useDispatch()
    const { err, add_status } = useSelector(addressSelector)
    const { token } = useSelector(authSelector)
    const { width, height } = Dimensions.get("window")
    const [title, setTitle] = useState('')

    // useEffect(() => {
    //     setTitle(props.route.params.key)
    // },[])

    useEffect(() => {
        if (err) {
            Toast.show("Please enter valid zipcode", Toast.SHORT);
            dispatch(updateerr(false))
        }
    }, [err])

    useEffect(() => {
        if (add_status) {
            if (props.route.params.from) {
                props.navigation.navigate("Cart")
            }
            else {
                props.navigation.navigate("Address")
            }
            dispatch(updateaddress(false))
        }
    }, [add_status])

    const [active, setActive] = useState(() => {
        if (props.route.params.key == "Add") {
            return ({
                fname: "",
                lname: "",
                city: "",
                state: "",
                pincode: "",
                type: ""
            })
        }
        else {
            return ({
                fname: props.route.params.data.address1,
                lname: props.route.params.data.address2,
                city: props.route.params.data.city,
                state: props.route.params.data.state,
                pincode: props.route.params.data.zipcode,
                type: props.route.params.data.type
            })
        }
    })

    const [change, setChange] = useState({
        fname: false,
        lname: false,
        city: false,
        state: false,
        pincode: false,
        type: false

    })

    const profilevalidate = async (value, key) => {

        switch (key) {
            case "fname":
                var data1 = { ...active }
                data1.fname = value
                setActive(data1)
                break;

            case "lname":
                var data1 = { ...active }
                data1.lname = value
                setActive(data1)
                break;

            case "city":
                var data1 = { ...active }
                data1.city = value
                setActive(data1)
                break;
            case "state":
                var data1 = { ...active }
                data1.state = value
                setActive(data1)
                break;
            case "pincode":
                var data1 = { ...active }
                data1.pincode = value
                setActive(data1)
                break;
            case "type":
                var data1 = { ...active }
                data1.type = value
                setActive(data1)
                break;
        }
    }

    const changevalidate = async (key) => {
        switch (key) {
            case "fname":
                var data = { ...change }
                data.fname = true
                data.lname = false
                data.city = false
                data.state = false
                data.type = false
                data.pincode = false
                setChange(data)
                break;
            case "lname":
                var data = { ...change }
                data.fname = false
                data.lname = true
                data.city = false
                data.state = false
                data.type = false
                data.pincode = false
                setChange(data)
                break;
            case "city":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.city = true
                data.state = false
                data.type = false
                data.pincode = false
                setChange(data)
                break;

            case "state":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.city = false
                data.state = true
                data.type = false
                data.pincode = false
                setChange(data)
                break;
            case "pincode":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.city = false
                data.state = false
                data.type = false
                data.pincode = true
                setChange(data)
                break;
            case "type":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.state = false
                data.pincode = false
                data.type = true
                setChange(data)
                break;


        }
    }
    const submit = () => {

        if (!active.type) {
            Toast.show("Please enter address Type", Toast.SHORT);
        }
        else if (!active.fname) {
            Toast.show("Please enter address line1", Toast.SHORT);
        }
        else if (!active.city) {
            Toast.show("Please enter city", Toast.SHORT);
        }
        else if (!active.state) {
            Toast.show("Please enter state", Toast.SHORT);
        }
        else if (!active.pincode) {
            Toast.show("Please enter zipcode", Toast.SHORT);
        }
        else {
            if (props.route.params.key == "Add") {
                // dispatch(updateaddress(true))
                var add_data = {
                    "type": active.type,
                    "address1": active.fname,
                    "address2": active.lname,
                    "state": active.state,
                    "city": active.city,
                    "zipcode": active.pincode
                }
                var postdata = {
                    data: add_data,
                    token: token
                }
                dispatch(addaddress(postdata))


            }
            else {
                // dispatch(updateaddress(true))
                var add_data = {
                    "type": active.type,
                    "address1": active.fname,
                    "address2": active.lname,
                    "state": active.state,
                    "city": active.city,
                    "zipcode": active.pincode
                }
                var postdata = {
                    data: add_data,
                    token: token,
                    id: props.route.params.data.id
                }
                dispatch(editaddress(postdata))
            }

        }
    }

    const goback = () => {

        if (props.route.params.from) {
            props.navigation.navigate("Cart")
        }
        else {
            props.navigation.navigate("Address")
        }
    }


    return (
        <SafeAreaView style={{ height:"100%",width:"100%" }} >

            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}>
                <View style={{ width: "100%", height: 50, backgroundColor: "white", flexDirection: "row", alignItems: "center" }}>
                    <TouchableOpacity onPress={() => goback()} >
                        <Image style={{ width: 20, height: 25, resizeMode: "contain", marginLeft: 15 }} source={require('../../Assets/back.png')} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 18, color: "black", fontWeight: "bold", marginLeft: "5%" }}>{props.route.params.key == "Add" ? "Add Address" : "Edit Address"}</Text>
                </View>


                <View style={{ width: "100%", height: "93%" }}>

                    <ScrollView>

                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Address Type *</Text>



                        <Card style={change.type ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => profilevalidate(text, "type")}
                                value={active.type}
                                onFocus={() => changevalidate("type")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Ex. Home or Office'}

                            />
                        </Card>

                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Address Line 1 *</Text>



                        <Card style={change.fname ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => profilevalidate(text, "fname")}
                                value={active.fname}
                                onFocus={() => changevalidate("fname")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter the Address Line 1'}

                            />
                        </Card>

                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Address Line 2</Text>

                        <Card style={change.lname ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => profilevalidate(text, "lname")}
                                value={active.lname}
                                onFocus={() => changevalidate("lname")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter the Address Line 2'}

                            />
                        </Card>


                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >City *</Text>



                        <Card style={change.city ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => profilevalidate(text, "city")}
                                value={active.city}
                                onFocus={() => changevalidate("city")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter the City'}


                            />
                        </Card>



                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >State/Province *</Text>



                        <Card style={change.state ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => profilevalidate(text, "state")}
                                value={active.state}
                                onFocus={() => changevalidate("state")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter the State/Province'}



                            />
                        </Card>




                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Zip Code *</Text>


                        <Card style={change.pincode ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => profilevalidate(text, "pincode")}
                                value={active.pincode}
                                onFocus={() => changevalidate("pincode")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter the Zipcode'}
                                keyboardType="numeric"

                            />
                        </Card>

                        <TouchableOpacity onPress={() => submit()} style={{ marginTop: "10%",marginBottom:"15%" }} >
                            <Card style={{ width: '50%', alignSelf: 'center', height:45, borderRadius: 7, overflow: 'hidden', backgroundColor: '#00a4ff', alignItems: 'center', justifyContent: "center" }}>
                                {add_status ?
                                    <ActivityIndicator color={"white"} /> :
                                    <Text style={{ fontSize: 18, color: 'white', fontWeight: 'bold', textAlign: "center", marginBottom: "5%", marginTop: "5%" }}>Submit</Text>}
                            </Card>
                        </TouchableOpacity>

                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    )

}




export default Addaddress;