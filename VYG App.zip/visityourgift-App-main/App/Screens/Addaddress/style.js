import { Dimensions,StyleSheet} from "react-native"

const {width,height}=Dimensions.get("window")
export default styless = StyleSheet.create({
    container:{
        flex:1,

    },

    container1: {
        width: width,
        height: height * 0.5,
        backgroundColor: "white",
        borderTopLeftRadius: width * 0.035,
        borderTopRightRadius: width * 0.035,
        // position:"absolute",
        // bottom:0
       
      },

      
      container11: {
        width: width,
        height: height*0.75,
        backgroundColor: "white",
        borderRadius: width * 0.035,
        borderBottomLeftRadius: 0 ,
        borderBottomRightRadius: 0 ,
        
      },
    header:{
        width:"100%",
        height:height*0.075,
        backgroundColor:"white",
        flexDirection:"row",
        alignItems:"center"
    },
    back:{
        width:width*0.05,
        height:height*0.03,
        alignSelf:"center", 
    },
    text1:{
        fontSize:width*0.0475,
        marginLeft:"5%",
        fontFamily:"Roboto-Bold",
        marginTop: "3%"
    },
    text2:{
        fontSize:width*0.0425,
        textAlign:"center",
        marginTop:"5%",
        fontFamily:"Roboto-Light",
        fontWeight:"600"
    },
    text3:{
        fontSize:width*0.0425,
        textAlign:"center",
        fontFamily:"Roboto-Bold"
    },
    otp_container:{
        width:"60%",
        height:height*0.1,
        alignSelf:"center",
        alignItems:"center",
        justifyContent:"space-around",
        marginTop:"10%",
        flexDirection:"row"
    },
    box_container:{
        width:"20%",
        height:"67.5%",
        borderRadius:width*0.02,
        borderWidth:width*0.003,
        borderColor:'black'
    },
    box_container1:{
        width:"20%",
        height:"67.5%",
        borderRadius:width*0.02,
        borderWidth:width*0.003,
        borderColor:'gray'
    },
    text4:{
        fontSize:width*0.0425,
        textAlign:"center",
        fontWeight:"700",
        color:"#D3D3D3",
        marginTop:"5%"   ,
        fontFamily:"Roboto-Light",
    },
    card_container:{
        width: width * 0.9,
        height: height * 0.06,
        alignSelf: "center",
        marginTop: "3%",
        borderRadius: width * 0.015,
        justifyContent:"center",
        borderColor:"gray",
        borderWidth:width*0.00075 
    },
    card_container1:{
        width: width * 0.9,
        height: height * 0.06,
        alignSelf: "center",
        marginTop: "3%",
        borderRadius: width * 0.015,
        justifyContent:"center",
        borderColor:"#00a4ff",
        borderWidth:width*0.0025
    }
})