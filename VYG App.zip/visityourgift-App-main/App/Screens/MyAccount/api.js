import { URL_CHANGE_PASSWORD } from '../../Constants'
import axios from 'axios';
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-async-storage/async-storage';
export const changepass = async (token, postdata) => {

    try {
        const passwod_change = await axios({
            method: "post",
            url: `${URL_CHANGE_PASSWORD}`,
            headers: {
                Authorization: token
            },
            data: postdata
        })


        Toast.show(passwod_change.data.message, Toast.SHORT);

        return passwod_change.data;


    }
    catch (error) {
        console.log("error====>", error)
        console.log("400", error.response.data.toast_message)
        Toast.show(error.response.data.toast_message, Toast.SHORT);
        return "error";
    }
}





