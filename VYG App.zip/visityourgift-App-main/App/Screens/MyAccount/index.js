
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, ScrollView, Keyboard, TextInput, Modal, PermissionsAndroid, ActivityIndicator, KeyboardAvoidingView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';
import { getprofile, updateuserprofile, update_profile } from '../../Slices/profile';
import { useDispatch, useSelector } from 'react-redux';
import { profileSelector } from '../../Slices/profile';
import Toast from 'react-native-simple-toast';
import { authSelector } from '../../Slices/auth';
import { changepass } from './api';
import { IMAGE_URL_PRODUCTS, IMAGE_URL_PROFILE } from '../../Constants';

export default function Myorders(props) {
    const dispatch = useDispatch()
    const { width, height } = Dimensions.get("window")
    const { profile, proupdatestatus } = useSelector(profileSelector)
    const { token } = useSelector(authSelector)
    const [editprofile, setEditprofile] = useState(false)
    const [loader, setLoader] = useState(false)
    const [color, setColor] = useState('#fffffff')
    const [propicupdate, setPropicupdate] = useState(false)
    const [imagepath, setimagepath] = useState('');

    const data = {
        name: 'My Account',
        search: false
    }

    useEffect(() => {
        if (proupdatestatus) {
            Toast.show("Profile updated", Toast.SHORT);
            setLoader(false)
            dispatch(update_profile(false))
            setEditprofile(false)
        }
    }, [proupdatestatus])

    useEffect(() => {
        const keyboardDidHideListener = Keyboard.addListener(
            'keyboardDidHide',
            () => {
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = false
                data.new = false
                data.confirm = false
                setChange(data)
            }
        );
        return () => {
            keyboardDidHideListener.remove();
        };
    }, [])

    const [image, setImage] = useState('');
    const [noimage, setNoimage] = useState(false);
    const requestCameraPermission = async () => {

        if (Platform.OS === 'android') {
            try {

                const granted = await PermissionsAndroid.request(
                    PermissionsAndroid.PERMISSIONS.CAMERA,
                    {
                        title: 'Camera Permission',
                        message: 'App needs camera permission',
                    },
                );
                return granted === PermissionsAndroid.RESULTS.GRANTED;
            } catch (err) {
                console.warn(err);
                return false;
            }
        } else return true;
    }


    const requestExternalWritePermission = async () => {
        if (Platform.OS === 'android') {
            try {
                const granted = await PermissionsAndroid.request(
                    PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
                    {
                        title: 'External Storage Write Permission',
                        message: 'App needs write permission',
                    },
                );
                // If WRITE_EXTERNAL_STORAGE Permission is granted
                return granted === PermissionsAndroid.RESULTS.GRANTED;
            } catch (err) {
                console.warn(err);
                alert('Write permission err', err);
            }
            return false;
        } else return true;
    }

    const OpenCamera = async (type) => {
        let options = {
            mediaType: type,
            maxWidth: 300,
            maxHeight: 550,
            quality: 1,
            videoQuality: 'low',
            durationLimit: 30,
            saveToPhotos: true,
            base64: true,
            includeBase64: true,
        };
        let isCameraPermitted = await requestCameraPermission();
        let isStoragePermitted = await requestExternalWritePermission();
        if (isCameraPermitted && isStoragePermitted) {
            launchCamera(options, (response) => {
                // console.log('Response = ', response);
                setPropicupdate(false)
                if (response.didCancel) {
                    alert('User cancelled camera picker');
                    return;
                } else if (response.errorCode == 'camera_unavailable') {
                    alert('Camera not available on device');
                    return;
                } else if (response.errorCode == 'permission') {
                    alert('Permission not satisfied');
                    return;
                } else if (response.errorCode == 'others') {
                    alert(response.errorMessage);
                    return;
                }
                // console.log('base 64', response.assets[0].base64);
                setimagepath(response.assets[0].base64)
                setImage(response.assets[0].uri)
                setNoimage(true)

            });
        }



    };

    const OpenGallery = (type) => {
        let options = {
            mediaType: type,
            maxWidth: 300,
            maxHeight: 550,
            quality: 1,
            base64: true,
            includeBase64: true,
        };
        launchImageLibrary(options, (response) => {
            // console.log('Response = ', response);
            setPropicupdate(false)

            if (response.didCancel) {
                alert('User cancelled camera picker');
                return;
            } else if (response.errorCode == 'camera_unavailable') {
                alert('Camera not available on device');
                return;
            } else if (response.errorCode == 'permission') {
                alert('Permission not satisfied');
                return;
            } else if (response.errorCode == 'others') {
                alert(response.errorMessage);
                return;
            }
            else {

                // console.log('base 64', response.assets[0].base64);
                setimagepath(response.assets[0].base64)
                setImage(response.assets[0].uri)
                setNoimage(true)

            }

        });

    };





    const [active, setActive] = useState({
        fname: profile.fname,
        lname: profile.lname,
        email: profile.email,
        mobile: profile.mobile,
        image: profile.image,
        current: "",
        new: "",
        confirm: ""
    })

    const [change, setChange] = useState({
        fname: false,
        lname: false,
        mobile: false,
        current: false,
        new: false,
        confirm: false
    })

    const [address, setaddress] = useState({
        door: "",
        street: "",
        district: "",
        state: "",
        pincode: "",
    })
    const [editing, setediting] = useState(false)
    const [returnorder, setReturnorder] = useState(false)

    const [addres, setaddres] = useState("")


    const modelclose = () => {
        setReturnorder(false)

        var data1 = { ...active }
        data1.current = ""
        data1.new = ""
        data1.confirm = ""
        setActive(data1)
    }

    const changepss = (data) => {

        props.navigation.navigate("Changepassword")
    }
    const editaddress = () => {

        setediting(true)
    }
    const updateprofile = () => {
        if (!active.fname) {
            Toast.show("Please Enter Firstname", Toast.SHORT);
        }
        else if (!active.lname) {
            Toast.show("Please Enter lastname", Toast.SHORT);
        }
        else if (!active.mobile) {
            Toast.show("Please Enter mobile", Toast.SHORT);
        }
        else if (active.mobile.length < 10) {
            Toast.show("Please Enter 10digitmobile number", Toast.SHORT);
        }
        else {
            setLoader(true)
            var data = {
                "fname": active.fname,
                "mobile": active.mobile,
                "lname": active.lname,
                "email": active.email,
                "image": imagepath

            }
            var payload = {
                token: token,
                data: data
            }

            dispatch(updateuserprofile(payload))
        }
    }
    const profilevalidate = async (value, key) => {

        switch (key) {
            case "fname":
                var data1 = { ...active }
                data1.fname = value
                setActive(data1)
                break;

            case "lname":
                var data1 = { ...active }
                data1.lname = value
                setActive(data1)
                break;

            case "mobile":
                var data1 = { ...active }
                data1.mobile = value
                setActive(data1)
                break;
        }
    }

    const Passwordvalidate = async (value, key) => {

        switch (key) {
            case "current":
                var data1 = { ...active }
                data1.current = value
                setActive(data1)
                break;

            case "new":
                var data1 = { ...active }
                data1.new = value
                setActive(data1)
                break;

            case "confirm":
                var data1 = { ...active }
                data1.confirm = value
                setActive(data1)
                break;
        }
    }


    const changevalidate = async (key) => {
        switch (key) {
            case "fname":
                var data = { ...change }
                data.fname = true
                data.lname = false
                data.mobile = false
                data.current = false
                data.new = false
                data.confirm = false
                setChange(data)
                break;
            case "lname":
                var data = { ...change }
                data.fname = false
                data.lname = true
                data.mobile = false
                data.current = false
                data.new = false
                data.confirm = false
                setChange(data)
                break;
            case "mobile":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = true
                data.current = false
                data.new = false
                data.confirm = false
                setChange(data)
                break;

            case "current":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = true
                data.new = false
                data.confirm = false
                setChange(data)
                break;
            case "new":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = false
                data.new = true
                data.confirm = false
                setChange(data)
                break;

            case "confirm":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = false
                data.new = false
                data.confirm = true
                setChange(data)
                break;

        }





    }


    const PasswordChanged = async () => {


        if (active.current == "") {
            Toast.show("Enter Current Password ", Toast.SHORT);
        }
        else if (active.new == "") {
            Toast.show("Enter New Password ", Toast.SHORT);
        }
        else if (active.confirm == "") {
            Toast.show("Enter Confirm Password ", Toast.SHORT);
        }
        else if (!(active.new == active.confirm)) {
            Toast.show("Please Check New Password and Confirm Password", Toast.SHORT);
        }
        else {
            var data = {
                "current_password": active.current,
                "new_password": active.confirm,

            }
            const gett = await changepass(token, data)
            if (gett) {

                var data1 = { ...active }
                data1.current = ""
                data1.new = ""
                data1.confirm = ""
                setActive(data1)


                setReturnorder(false)


            }

            console.log("geeeee", gett)
        }
    }








    const updatepropic = () => {
        setPropicupdate(true)
        setColor("rgba(52, 52, 52, 0.8)")
    }
    const proupdateclose = () => {
        setPropicupdate(false)
        setColor('#fffffff')
    }

    const [boardshow, setBoardsetshow] = useState(false)

    useEffect(() => {

        const keyboardDidShowListener = Keyboard.addListener(
            'keyboardDidShow',
            () => {
                setBoardsetshow(true)
            }
        );

        const keyboardDidHideListener = Keyboard.addListener(
            'keyboardDidHide',
            () => {
                setBoardsetshow(false) // or some other action
            }
        );

        return () => {
            keyboardDidHideListener.remove();
            keyboardDidShowListener.remove();
        };
    }, [])

    const GoBack = () => {

        props.navigation.goBack()
    }

    return (


        <SafeAreaView style={styles.container}>
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}>
                <Header dataParentToChild={data} Back={() => GoBack()} />
                {/* <ScrollView> */}
                <View style={{ width: width, height: "92%", backgroundColor: "white" }} >
                    <ScrollView >
                        {/* <View> */}
                        <View style={{ width: width, justifyContent: "center", alignItems: "center", backgroundColor: "white" }}>
                            <View style={{ height: 135, width: (Platform.OS === 'ios') ? "35%" : "35%", borderRadius: 1000, justifyContent: "center", alignItems: "center", borderWidth: 3, borderColor: "#00a4ff" }} >


                                {noimage ?
                                    <Image resizeMode='contain'
                                        source={{ uri: image }}
                                        style={{ width: "100%", height: "100%", resizeMode: "contain", borderRadius: 100 }}
                                    />
                                    :
                                    active.image ?
                                        <Image resizeMode='contain'
                                            source={{ uri: IMAGE_URL_PROFILE + active.image }}
                                            style={{ width: "100%", height: "100%", resizeMode: "contain", borderRadius: 100 }}
                                        />

                                        :
                                        <Image source={require("../../Assets/boss.png")} style={{ width: width * 0.2, height: height * 0.2, resizeMode: "contain", }} />
                                }

                            </View>
                            {editprofile ?
                                <TouchableOpacity onPress={() => updatepropic()} style={{ height: 45, width: 45, backgroundColor: "#00a4ff", borderRadius: width * 0.07, alignItems: "center", justifyContent: "center", position: "absolute", bottom: 0, alignSelf: "flex-end", left: "53%" }} >
                                    <Image source={require("../../Assets/pencil.png")} style={{ width: 20, height: 20, resizeMode: "contain", }} />
                                </TouchableOpacity>
                                : null}
                        </View>

                        {/* <View style={{ width: width, height: "70%", backgroundColor: "white" }}> */}

                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "10%", }}></View>
                        <View style={{ flexDirection: "row", alignItems: "center", marginTop: "5%", }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginLeft: "4%", color: "black" }} >First Name</Text>
                            {!editprofile ?
                                <TouchableOpacity onPress={() => setEditprofile(true)} style={{ width: "20%", height: height * 0.04, backgroundColor: "#00a4ff", marginLeft: "47.5%", borderRadius: width * 0.01, justifyContent: "center" }} >
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "white", textAlign: "center" }} >Edit</Text>
                                </TouchableOpacity>
                                :
                                <TouchableOpacity onPress={() => updateprofile()} style={{ width: "20%", height: height * 0.04, backgroundColor: "#00a4ff", marginLeft: "47.5%", borderRadius: width * 0.01, justifyContent: "center" }} >
                                    {!loader ?
                                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "white", textAlign: "center" }} >Save</Text> :
                                        <ActivityIndicator color="white" />}
                                </TouchableOpacity>}
                        </View>

                        <Card style={change.fname ? styles.card_container1 : styles.card_container}>
                            {!editprofile ?
                                <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, marginLeft: "4%", color: "black" }} >{profile.fname}</Text> :
                                <TextInput
                                    onChangeText={(text) => profilevalidate(text, "fname")}
                                    value={active.fname}
                                    editable={true}
                                    onFocus={() => changevalidate("fname")}
                                    style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                    placeholder={'Enter the First Name'}
                                />}
                        </Card>

                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginTop: "5%", marginLeft: "4%", color: "black" }} >Last Name</Text>
                        <Card style={change.lname ? styles.card_container1 : styles.card_container}>
                            {!editprofile ?
                                <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, marginLeft: "4%", color: "black" }} >{profile.lname}</Text> :
                                <TextInput
                                    onChangeText={(text) => profilevalidate(text, "lname")}
                                    value={active.lname}
                                    onFocus={() => changevalidate("lname")}
                                    style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                    placeholder={'Enter the Last Name'}
                                />}
                        </Card>

                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginTop: "5%", marginLeft: "4%", color: "black" }} >Email</Text>
                        <Card style={{ width: width * 0.9, height: height * 0.06, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015, justifyContent: "center", borderColor: "gray", borderWidth: width * 0.00075 }}>
                            <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, marginLeft: "4%", color: "black" }} >{profile.email}</Text>
                        </Card>

                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginTop: "5%", marginLeft: "4%", color: "black" }} >Phone Number</Text>
                        <Card style={change.mobile ? styles.card_container1 : styles.card_container}>
                            {!editprofile ?
                                <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, marginLeft: "4%", color: "black" }} >{profile.mobile}</Text> :
                                <TextInput
                                    onChangeText={(text) => profilevalidate(text, "mobile")}
                                    value={active.mobile}
                                    maxLength={10}
                                    keyboardType='numeric'
                                    onFocus={() => changevalidate("mobile")}
                                    style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                    placeholder={'Enter the Last Name'}
                                />}
                        </Card>

                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "5%" }}></View>
                        {/* <TouchableOpacity onPress={() => changepss("pass")}>
                            <View style={{ flexDirection: "row", width: width * 0.9, height: height * 0.06, alignSelf: "center", borderRadius: width * 0.015, justifyContent: 'space-between', alignItems: "center" }}>

                                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.048, color: "black", }} >Change Password</Text>
                                <Image source={require("../../Assets/rightward.png")} style={{ width: 20, height: 20, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} />

                            </View>
                        </TouchableOpacity> */}

                        <TouchableOpacity onPress={() => changepss("pass")} style={{flexDirection:"row",alignItems:"center", alignSelf:"center", width: "80%", height: 50, backgroundColor: "#00a4ff",  borderRadius: width * 0.01, justifyContent: "space-evenly" }} >
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "white", textAlign: "center" }} >Change Password</Text>
                            {/* <Image source={require("../../Assets/rightAr.png")} style={{ width: 20, height: 20, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} /> */}
                   
                        </TouchableOpacity>





                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "2%" }}></View>
                        <Modal
                            animationType="slide"
                            transparent={true}
                            visible={propicupdate}

                        >

                            <View style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)" }} >
                                <TouchableOpacity onPress={() => proupdateclose()} style={{ width: 45, height: 45, backgroundColor: "black", borderRadius: width * 0.07, alignSelf: "center", justifyContent: "center", bottom: "25%", position: "absolute" }} >
                                    <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/reject.png')} />
                                </TouchableOpacity>
                                <Card style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-around", width: width, height: height * 0.2, position: "absolute", bottom: 0 }} >


                                    <TouchableOpacity onPress={() => OpenCamera('photo')}>
                                        <Card style={{ width: width * 0.24, height: height * 0.1, alignItems: "center", justifyContent: "center" }} >
                                            <Image style={{ width: '60%', height: "60%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/camera.png')} />
                                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "#00a4ff" }} >Open Camera</Text>

                                        </Card>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => OpenGallery('photo')}>

                                        <Card style={{ width: width * 0.24, height: height * 0.1, alignItems: "center", justifyContent: "center" }} >
                                            <Image style={{ width: '60%', height: "60%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/gallery.png')} />
                                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "#00a4ff" }} >Open Gallery</Text>

                                        </Card>
                                    </TouchableOpacity>
                                </Card>

                            </View>
                        </Modal>
                        {/* </View> */}
                        {/* </View> */}
                    </ScrollView>

                </View>
                {/* </ScrollView> */}
            </KeyboardAvoidingView>

        </SafeAreaView>
    )
}