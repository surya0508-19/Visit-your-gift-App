
import { useState } from 'react';
import {StatusBar} from 'react-native';
export default function Statusbar (props) {

    return(
        <StatusBar
        backgroundColor={props.dataParentToChild}
        barStyle="dark-content"
    />
    )
}
