
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, SafeAreaView } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';
import { Card } from 'react-native-shadow-cards';

export default function Terms(props) {
    const { width, height } = Dimensions.get("window")

    const data = {
        name: 'Payment',
        search: false
    }
    return (
        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />



            <Card style={{ width: width * 0.925, height: height * 0.2, alignSelf: "center", borderRadius: width * 0.03, marginTop: "5%" }} >
                <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.0425, color: "black", marginTop: "5%", marginLeft: "2.5%" }} >Recommended</Text>



                <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.002, marginTop: "2%" }}></View>

                <View style={{ flexDirection: "row", width: width * 0.85, height: height * 0.06, justifyContent: "space-between", alignSelf: "center", borderRadius: width * 0.015, justifyContent: 'space-between', alignItems: "center" }}>

                    <View style={{ width: "50%", height: "70%", flexDirection: "row", alignItems: "center", }} >
                        <Image style={{ width: 80, height: 80 }} source={require("../../Assets/paypal.png")} />
                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0425, color: "black", marginLeft: "5%" }} >Paypal UPI</Text>

                    </View>

                    <Image source={require("../../Assets/rightward.png")} style={{ width: 20, height: 20, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} />

                </View>
                <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.002, }}></View>

                <View style={{ flexDirection: "row", width: width * 0.85, height: height * 0.06, justifyContent: "space-between", alignSelf: "center", borderRadius: width * 0.015, justifyContent: 'space-between', alignItems: "center" }}>

                    <View style={{ width: "50%", height: "70%", flexDirection: "row", alignItems: "center", }} >
                        <Image style={{ width: 35, height: 35 }} source={require("../../Assets/cash.png")} />
                        <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.0425, color: "black", marginLeft: "5%" }} >Cash On Delivery</Text>

                    </View>

                    <Image source={require("../../Assets/rightward.png")} style={{ width: 20, height: 20, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} />

                </View>
                <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.002, }}></View>


            </Card>

        </SafeAreaView>
    )
}