import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, Modal, Image, SafeAreaView } from "react-native";
import { WebView } from 'react-native-webview'
import { useDispatch, useSelector } from "react-redux";
import { cart_empty, fetchcart } from "../../Slices/cart";

import { authSelector } from '../../Slices/auth';
import { fetchorders } from "../../Slices/orders";
import { getnotificationlist } from "../../Slices/profile";
import { createorder } from "../Checkout/api";


export default function PaypalWebview(props, { route }) {
    const dispatch = useDispatch()
    const { token } = useSelector(authSelector)

    const [locationid, setLocationid] = useState("")
    const [create, setCreate] = useState("success")


    useEffect(() => {

        console.log("gettdataa", props.route.params.getdata.pickup_location)



        var loc1 = "Kalpana Bazaar 45 Waverley Dr STE N Frederick MD 21702"
        var location_id
        if (props.route.params.getdata.pickup_location == loc1) {
            location_id = 1
        }
        else {
            location_id = 2
        }
        console.log(location_id, "location_id")
        setLocationid(location_id)

    }, [])


    const CashOnDelivery = async () => {

        // var data = {
        //     "location_mode": "Pickup",
        //     "pickup_location": props.route.params.getdata.pickup_location,
        //     "pickup_date": props.route.params.getdata.pickup_date,
        //     "pickup_time": props.route.params.getdata.pickup_time,
        //     "coupon": props.route.params.getdata.coupon,
        //     "note": props.route.params.getdata.note

        // }
        // console.log(data, "data")


        // const output = await createorder(data, token)

        // console.log("output", output)
        // if (output.message == "Order created successfully") {


        //     props.navigation.navigate("Confirmorder", {
        //         order_id: output.order_id,
        //         token: token
        //     })
        //     dispatch(fetchcart(token))
        //     dispatch(cart_empty())
        //     dispatch(getnotificationlist(token))
        //     dispatch(fetchorders(token))
        // }


    }


    const handleResponse = data => {

        console.log("responseeeee", data)
        if (data.url == "https://balloon.groceryonmobile.com/paypalsuccess") {

            dispatch(fetchcart(token))
            dispatch(cart_empty())
            dispatch(getnotificationlist(token))
            dispatch(fetchorders(token))
            setTimeout(() => {
                props.navigation.navigate('Home')

            }, 3000);

        }
        if (data.url == "https://balloon.groceryonmobile.com/continue_shopping") {

            props.navigation.navigate('Home')
        }
        if (data.url == "https://balloon.groceryonmobile.com/cash-on-delivery") {


            var data = {
                "location_mode": "Pickup",
                "pickup_location": props.route.params.getdata.pickup_location,
                "pickup_date": props.route.params.getdata.pickup_date,
                "pickup_time": props.route.params.getdata.pickup_time,
                "coupon": props.route.params.getdata.coupon,
                "note": props.route.params.getdata.note

            }
           
            props.navigation.navigate("Confirmorder", {
                body: data,

            })


        }
        // if (data.url == "https://balloon.groceryonmobile.com/cash-on-delivery" && create == "success") {
        //     CashOnDelivery()
        //     setCreate("failure")
        // }

    };


    const handleWebViewMessage = (event) => {
        alert(event)
        const messageData = event.nativeEvent.data;
        console.log('Received message:', messageData);

        // Do something with the message data
        // ...
    };


    return (
        <SafeAreaView style={{ width: "100%", height: "100%" }}>
            <View style={{ width: "100%", height: "100%", justifyContent: "center", alignItems: "center" }}>


                <View style={{ width: "100%", height: "100%" }}>

                    <WebView
                        source={{ uri: "http://www.visityourgift.com/mobilePaypal?token=" + props.route.params.getdata.token + "&location_mode=" + props.route.params.getdata.location_mode + "&coupon=" + props.route.params.getdata.coupon + "&pickup_location=" + 1 + "&pickup_date=" + props.route.params.getdata.pickup_date + "&pickup_time=" + props.route.params.getdata.pickup_time + "&note=" + props.route.params.getdata.note }}
                        onNavigationStateChange={data =>

                            handleResponse(data)
                        }

                        onMessage={handleWebViewMessage}
                        startInLoadingState={true}
                        scalesPageToFit={"isAndroid" ? false : true}
                        injectedJavaScript={`document.f1.submit()`}
                    />


                </View>


            </View>
        </SafeAreaView>

    );
}
