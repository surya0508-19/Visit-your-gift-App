import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, StyleSheet, Linking, BackHandler, FlatList, Modal, ScrollView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import Search from '../../Components/search';
import { AnimatedScrollView } from '@kanelloc/react-native-animated-header-scroll-view';

import StarRating from 'react-native-star-rating-widget';
import Homeproducts from '../../Components/Homeproducts';
import { Recommendedproduct, TopsellingProducts } from '../TestData/data';
import Categories from '../../Components/Categories';
import Helperhome from '../../Components/helperhome';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import Productdetail from '../../Components/productdetail';
import Confirmorderheader from '../../Components/confirmorderheader';
import Statusbar from '../Statusbar';
import Confirmordermap from '../../Components/confirmordermap';
import Confirmordertabnav from '../../Components/confirmordertabnav';
import { useDispatch, useSelector } from 'react-redux';
import { fetchorderdetails, fetchorders, getorderdetail, ordersSelector, update_order_detailsts } from '../../Slices/orders';
import { authSelector } from '../../Slices/auth';
import { IMAGE_URL_PRODUCTS } from '../../Constants';
import { fetchingorderdetails } from './api';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ActivityIndicator } from 'react-native';
import { createorder } from '../Checkout/api';
import { cart_empty, fetchcart } from '../../Slices/cart';
import { getnotificationlist } from '../../Slices/profile';

const { width, height } = Dimensions.get("window")
export default function Confirmorder(props, navigation) {
   const dispatch = useDispatch()
   const { token } = useSelector(authSelector)
   const { orderdetails, orderdeatilsts } = useSelector(ordersSelector)
   const [orders, setOrders] = useState([])
   const [loader, setloader] = useState(true)
   const [order_id, setorder_id] = useState("")


   // console.log("hari",orderdetails.orders.order_list)
   const data = "#00a4ff"
   useEffect(() => {

      get_orderdetails()

   }, [])
   useEffect(() => {



      BackHandler.addEventListener("hardwareBackPress", backAction);
      return () =>
        BackHandler.removeEventListener("hardwareBackPress", backAction);
  
  
    }, []);
  
    const backAction = () => {
      if (props.navigation.isFocused()) {
         props.navigation.navigate("Sidemenu")
      } else {
        props.navigation.goBack()
  
      }
      return true;
    };
   const get_orderdetails = async () => {


      console.log(props.route.params.body, "bodyyyyy")


      setTimeout(async () => {

         const output123 = await createorder(props.route.params.body, token)

         console.log("output", output123.order_id)

         if (output123.message == "Order created successfully") {
            dispatch(fetchcart(token))
            dispatch(cart_empty())
            dispatch(getnotificationlist(token))
            dispatch(fetchorders(token))

            setorder_id(output123.order_id)
            var data = {
               order_id: output123.order_id,
               token: token
            }
            const output = await fetchingorderdetails(data)
            setOrders(output)
            setloader(false)
         }

      }, 2000)



      // var data = {
      //    order_id: props.route.params.body,
      //    token: props.route.params.token
      // }
      // const output = await fetchingorderdetails(data)
      // setOrders(output)


   }

   const vieworder = async () => {
      props.navigation.navigate("Orderdetails", {
         order_id: order_id,
         token: token
      })
   }

   useEffect(() => {
      dispatch(fetchorders(token))
   }, [])
   return (
      <SafeAreaView style={{ flex: 1 }}>
         <Statusbar dataParentToChild={data} />
         {loader == false ?
            <View style={{ width: width, height: "100%", backgroundColor: "#f4f7fe", justifyContent: "center" }} >
               <Confirmorderheader Back={() => props.navigation.navigate("Sidemenu")} />

               <ScrollView>
                  {/* <Card style={{ width: width * 0.95, height: height * 0.45, alignSelf: "center", marginTop: "5%", borderRadius: width * 0.04 }} >
                  <View style={{ width: "100%", height: "27.5%", flexDirection: "row", alignItems: "center" }} >
                     <View style={{ width: "25%", height: "100%", justifyContent: "center" }}>
                        <View style={{ width: "65%", height: "60%", backgroundColor: "#f1f4e1", alignSelf: "center", borderRadius: width * 0.1, justifyContent: "center" }} >
                           <Image source={require('../../Assets/delivery-man.png')} style={{ resizeMode: "contain", width: "70%", height: "80%", alignSelf: "center" }} />
                        </View>
                     </View>
                     <View style={{ width: "75%", height: "100%", justifyContent: "center" }}>
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, color: "black" }} >Well assign a delivery partner as soon as your order is packed</Text>
                     </View>
                  </View>

                  <View style={{ width: "90%", height: "67.5%", backgroundColor: "#f8fff8", alignSelf: "center", borderWidth: width * 0.001, borderColor: "#00a4ff", borderRadius: width * 0.025 }} >
                     <View style={{ width: "100%", height: "25%", borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", flexDirection: "row", alignItems: "center" }} >
                        <View style={{ width: "17.5%", height: "100%", justifyContent: "center" }} >
                           <Image style={{ width: 30, height: 30, resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/shield.png')} />
                        </View>
                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.038, color: "black" }} >Helping delivery partners stay safe</Text>
                     </View>

                     <View style={{ width: "100%", height: "25%", borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", flexDirection: "row", alignItems: "center" }} >
                        <View style={{ width: "17.5%", height: "100%", justifyContent: "center" }} >
                           <Image style={{ width: 30, height: 30, resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/#00a4ffhouse.png')} />
                        </View>
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black" }} >We usually deliver from stores within 2km</Text>
                     </View>

                     <View style={{ width: "100%", height: "25%", borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", flexDirection: "row", alignItems: "center" }} >
                        <View style={{ width: "17.5%", height: "100%", justifyContent: "center" }} >
                           <Image style={{ width: 25, height: 25, resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/#00a4ffpay.png')} />
                        </View>
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", width: "80%" }} >We never penalise delivery partners for late orders</Text>
                     </View>

                     <View style={{ width: "100%", height: "25%", justifyContent: "center", }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.036, color: "#00a4ff", textAlign: "center" }} >Know more about delivery partner safetly</Text>
                     </View>
                  </View>

               </Card> */}


                  {/* <Card style={{ width: width * 0.95, height: height * 0.175, alignSelf: "center", marginTop: "5%", borderRadius: width * 0.04 }} >
                  <View style={{ width: "100%", height: "40%", borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", justifyContent: "center" }} >
                     <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "black", marginLeft: "5%" }} >Need help with your order?</Text>
                  </View>
                  <View style={{ width: "100%", height: "60%", alignSelf: "center", flexDirection: "row" }} >
                     <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <View style={{ width: "65%", height: "60%", backgroundColor: "#f1f4e1", alignSelf: "center", borderRadius: width * 0.1, justifyContent: "center" }} >
                           <Image source={require('../../Assets/chatgirl.png')} style={{ resizeMode: "contain", width: "70%", height: "80%", alignSelf: "center" }} />
                        </View>
                     </View>

                     <View style={{ width: "60%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.0425, color: "black", }} >Chat with us </Text>
                        <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.0325, color: "gray", fontWeight: "700" }} >About any issues related to your order </Text>
                     </View>

                     <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <View style={{ width: "65%", height: "60%", alignSelf: "center", borderRadius: width * 0.1, justifyContent: "center", borderWidth: width * 0.001, borderColor: "#9e9e9e73" }} >
                           <Image source={require('../../Assets/#00a4ffchat.png')} style={{ resizeMode: "contain", width: "60%", height: "70%", alignSelf: "center" }} />
                        </View>
                     </View>

                  </View>
               </Card> */}


                  <Card style={{ width: width * 0.95, height: 'auto', alignSelf: "center", marginTop: "5%", borderRadius: width * 0.04, }} >
                     <View style={{ width: "100%", height: height * 0.1, flexDirection: "row", alignItems: "center" }} >
                        <View style={{ width: "25%", height: "100%", justifyContent: "center" }}>
                           <View style={{ width: "62.5%", height: "70%", backgroundColor: "#f1f4e1", alignSelf: "center", borderRadius: width * 0.1, justifyContent: "center" }} >
                              <Image source={require('../../Assets/grocery.jpg')} style={{ resizeMode: "contain", width: "80%", height: "80%", alignSelf: "center" }} />
                           </View>
                        </View>
                        <View style={{ width: "75%", height: "100%", justifyContent: "center" }}>
                           <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, color: "black" }} >Order summary</Text>
                           <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.038, color: "black" }} >Order id - #{order_id}</Text>
                        </View>
                     </View>
                     <View style={{ width: "100%", height: "auto", borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", }} >
                        <FlatList
                           data={orders}
                           numColumns={2}
                           renderItem={({ item, index }) => (
                              <View style={{ width: "45%", height: height * 0.125, borderWidth: width * 0.001, borderColor: "gray", marginLeft: "3%", borderRadius: width * 0.025, marginBottom: "5%", flexDirection: "row", alignItems: "center" }} >
                                 <View style={{ width: "45%", height: "100%", justifyContent: "center" }} >
                                    <Image source={{ uri: `${IMAGE_URL_PRODUCTS}` + item.item.image }} style={{ resizeMode: "contain", width: "80%", height: "80%", alignSelf: "center" }} />
                                 </View>

                                 <View style={{ width: "55%", height: "70%", justifyContent: "center", }} >
                                    <Text numberOfLines={2} style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.036, color: "black", width: "90%" }} >{item.item.name}</Text>
                                    <Text numberOfLines={2} style={{ fontFamily: "Roboto-Light", fontSize: width * 0.036, color: "black", width: "90%" }} > {item.quantity} Qty</Text>
                                 </View>
                              </View>
                           )}
                        />
                     </View>

                     <Pressable onPress={() => vieworder()} style={{ width: "100%", height: height * 0.075, justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, color: "#00a4ff", textAlign: "center" }} >View order summary</Text>
                     </Pressable>

                  </Card>

                  {/* <Card style={{ width: width * 0.95, height: height * 0.125, alignSelf: "center", marginTop: "5%", borderRadius: width * 0.04, }} >
                  <View style={{ width: "100%", height: "100%", flexDirection: "row", alignItems: "center" }} >
                     <View style={{ width: "25%", height: "100%", justifyContent: "center" }}>
                        <View style={{ width: "65%", height: "60%", backgroundColor: "#f1f4e1", alignSelf: "center", borderRadius: width * 0.1, justifyContent: "center" }} >
                           <Image source={require('../../Assets/house1.png')} style={{ resizeMode: "contain", width: "70%", height: "80%", alignSelf: "center" }} />
                        </View>
                     </View>
                     <View style={{ width: "75%", height: "100%", justifyContent: "center" }}>
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, color: "black" }} >Delivery address</Text>
                        <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.035, color: "black" }} >KK nagar arch ,madurai,Tamilnadu</Text>
                     </View>
                  </View>
               </Card> */}

                  <Card style={{ width: width * 0.95, height: height * 0.2, alignSelf: "center", marginTop: "5%", borderRadius: width * 0.04, marginBottom: "10%" }} >

                     <View style={{ width: "100%", height: "67.5%", borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", flexDirection: "row" }} >
                        <View style={{ width: "25%", height: "100%", }}>
                           <View style={{ width: "65%", height: "55%", backgroundColor: "#f1f4e1", alignSelf: "center", borderRadius: width * 0.1, justifyContent: "center", marginTop: "10%" }} >
                              <Image source={require('../../Assets/end-hands.png')} style={{ resizeMode: "contain", width: "70%", height: "80%", alignSelf: "center" }} />
                           </View>
                        </View>
                        <View style={{ width: "75%", height: "100%", }}>
                           <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, color: "black", marginTop: "5%", }} >Do you like our services?</Text>
                           <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.035, color: "black", width: "85%" }} >Do rate us on the Play Store if you are enjoying our service.you can rate again if you have already rate us.</Text>
                        </View>

                     </View>

                     <TouchableOpacity onPress={() => Linking.openURL('https://play.google.com/store/apps/details?id=com.snacks_ballons')} style={{ width: "100%", height: "32.5%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, color: "#00a4ff", textAlign: "center" }} >Rate Visit Your Gift</Text>
                     </TouchableOpacity>
                  </Card>

               </ScrollView>
            </View>
            :
            <View style={{ height: "100%", width: "100%", justifyContent: "center", alignItems: "center" }}>
               <ActivityIndicator size={30} color={'gray'} />
            </View>
         }
      </SafeAreaView>
   )
}
