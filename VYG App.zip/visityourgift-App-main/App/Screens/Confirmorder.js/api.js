import axios from "axios"
import { URL_ORDERDETAIL } from "../../Constants"



export const fetchingorderdetails = async(payload) => {
    try {
        const response =  await axios({
          method:"get",
          url:`${URL_ORDERDETAIL}`+payload.order_id,
          headers:{
            Authorization:payload.token
          }
         })
         if(response.data)
         {
            return response.data.orders.order_list
         }
        }
        catch(err)
      {
          console.log("error",err)
      } 
}