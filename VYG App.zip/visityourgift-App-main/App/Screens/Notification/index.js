import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Image, Pressable, Dimensions, TextInput, FlatList, ActivityIndicator, Alert, SafeAreaView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import { connect, useDispatch, useSelector } from 'react-redux';
import { ScrollView } from 'react-native-gesture-handler';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios'
import moment from 'moment';

import { getnotificationlist, profileSelector } from '../../Slices/profile';
import { URL_NOTIFICATION_LIST } from '../../Constants';




export default function Notification(props, navigation) {


    const [loader, setloader] = useState(false)
    const data = {
        name: 'Notifications',
        search: loader
    }
    const dispatch = useDispatch()
    const { NotificationList } = useSelector(profileSelector)

    console.log(NotificationList, "NotificationList")
    // useEffect(() => {
    //     getlist()
    // }, [])
    // const getlist = async () => {

    //     var tokenss = await AsyncStorage.getItem('Token')
    //     dispatch(getnotificationlist(tokenss))

    // }
    // const [list, setList] = useState([])

    const ClearNotification = async () => {
        var tokenss = await AsyncStorage.getItem('Token')
        console.log(tokenss, "tokenss")
        setloader(true)

        try {

            const response = await axios({
                method: "delete",
                url: `${URL_NOTIFICATION_LIST}`,
                headers: {
                    Authorization: tokenss
                },

            })
            console.log("deleteee", response.data)
            dispatch(getnotificationlist(tokenss))
            setloader(false)

        }
        catch (errr) {
            console.log("err", errr)


        }
    }





    const DATA = [
        {
            title: 'Your Product delivery is on the way', date: "23.03.23", orderid: "7052"
        },
        {
            title: 'Your Product is delivered', date: "01.03.23", orderid: "7055"
        },
        {
            title: 'Your Product delivery is on the way', orderid: "7033",
            date: "08.03.23"
        },
        {
            title: 'Your Product delivery is tommorrow',
            date: "08.03.23", orderid: "7066"
        },
        {
            title: 'Your Product delivery is on the way',
            date: "08.03.23", orderid: "7022"
        },
        {
            title: 'Your delivery cancelled for you',
            date: "08.03.23",
            orderid: "7033"
        },
    ];

    return (

        <SafeAreaView style={{ flex: 1 }} >


            <Header dataParentToChild={data} Back={() => props.navigation.goBack()}
                clear={() => ClearNotification()}

            />


            {NotificationList.length ?
                <ScrollView>
                    <View style={{ width: "100%", marginTop: 10 }}>
                        <FlatList
                            data={NotificationList}

                            renderItem={({ item }) => (

                                //   <Card style={{ marginTop: 5, width: "95%", alignSelf: "center", marginBottom: 5 }}>
                                //         <Text style={{ marginTop: 15, marginBottom: 5, fontSize: 17, marginLeft: 10, marginRight: 10, color: "black" }}>{item.data.title}</Text>
                                //         <Text style={{ marginTop: 5, marginBottom: 5, fontSize: 17, marginLeft: 10, marginRight: 10, color: "black" }}>Order Info : {item.data.body}</Text>
                                //         <Text style={{ marginTop: 5, marginBottom: 15, fontSize: 17, marginLeft: 10, marginRight: 10, color: "grey" }}>{moment(item.created_at).format("LLL") }</Text>

                                //     </Card>


                                // <View style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between", borderRadius: 10, marginTop: 5, height: 120, width: "92.5%", alignSelf: "center", marginBottom: 5, borderWidth: 1, borderColor: "#5DADE2" }}>
                                //     <View style={{ width: "65%", marginLeft: 10 }}>
                                //         <Text style={{ fontFamily: "Roboto-Bold", fontSize: 17, color: "black" }}>{item.data.title}</Text>
                                //         <Text style={{ fontFamily: "Roboto-Medium", fontSize: 16, color: "black" }} >{item.data.body}</Text>
                                //     </View>
                                //     <View style={{ width: "30%" }}>
                                //         <Text style={{ fontFamily: "Roboto-Medium", fontSize: 15, color: "black" }}>{moment(item.created_at).format("LL")}</Text>
                                //         <Text style={{ fontFamily: "Roboto-Medium", fontSize: 15, color: "black", textAlign: "center" }}>{moment(item.created_at).format("hh:mm A")}</Text>

                                //     </View>
                                // </View>


                                <View style={{ borderRadius: 10, marginTop: 5, height: 100, width: "92.5%", alignSelf: "center", marginBottom: 5, borderWidth: 1, borderColor: "#5DADE2" }}>
                                    <View style={{ marginTop: 10, width: "92%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center" }}>
                                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: 18, color: "black" }}>{item.data.title}</Text>
                                        <View style={{ flexDirection: "row" }}>
                                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: 14, color: "black" }}>{item.created_at}</Text>
                                            {/* <Text style={{ fontFamily: "Roboto-Medium", fontSize: 14, color: "black",marginLeft:10 }}>{moment(item.created_at).format("hh:mm A")}</Text> */}
                                        </View>
                                    </View>

                                    <Text style={{ fontFamily: "Roboto-Medium", fontSize: 16, color: "black", marginLeft: 13, marginTop: 10, }} >{item.data.body}</Text>


                                </View>



                            )}
                        />




                    </View>


                </ScrollView>
                :

                <View style={{ width: "100%", height: "100%", alignItems: "center", marginTop: "50%" }}>
                    <Image source={require("../../Assets/nonotifi.png")} style={{ width: "50%", height: 150, resizeMode: "contain" }} />
                    <Text style={{ marginTop: 10, marginBottom: 10, fontSize: 17, color: "black", fontWeight: "bold", textAlign: "center" }}>No Notifications</Text>

                </View>

            }
        </SafeAreaView>

    )

}

