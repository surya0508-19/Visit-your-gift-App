import axios from "axios"
import { URL_CANCEL_ORDER, URL_ORDERDETAIL ,URL_ORDERAGAIN,URL_INVOICE} from "../../Constants"

export const fetchingmyorders = async(payload) => {
    try {
        const response =  await axios({
          method:"get",
          url:`${URL_ORDERDETAIL}`+payload.order_id,
          headers:{
            Authorization:payload.token
          }
         })
         if(response.data)
         {
            return response.data
         }
        }
        catch(err)
      {
          console.log("error",err)
      } 
}


export const ordercancel = async(payload) => {
  try {
      const response =  await axios({
        method:"post",
        url:`${URL_CANCEL_ORDER}`+payload.order_id,
        headers:{
          Authorization:payload.token
        }
       })
       if(response.data)
       {
          return response.data
       }
      }
      catch(err)
    {
        console.log("error",err)
    } 
}


export const orderagain = async(payload) => {
  try {
      const response =  await axios({
        method:"get",
        url:`${URL_ORDERAGAIN}`+payload.order_id,
        headers:{
          Authorization:payload.token
        }
       })



       if(response.data)
       {
          return response.data
       }
      }
      catch(err)
    {
        console.log("error",err)
    } 
}



export const downloadInvoice = async(payload) => {
  try {
      const response =  await axios({
        method:"get",
        url:`${URL_INVOICE}`+payload.order_id,
       
        headers:{
          Authorization:payload.token
        }
       })

       console.log("response.data",response.data)


       if(response.data)
       {
          return response.data
       }
      }
      catch(err)
    {
        console.log("error",err)
    } 
}