
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Alert, Image, Dimensions, PermissionsAndroid, TextInput, Modal, ScrollView, SafeAreaView, Platform, ToastAndroid } from 'react-native';
import { Card } from 'react-native-shadow-cards';

import OrderItems from '../../Components/OrderItems';
import Helperhome from '../../Components/helperhome';
import Header from '../../Navigator/Header';
import { cartproducts } from '../TestData/data';
import styless from './style';
import LinearGradient from 'react-native-linear-gradient';
import { fetchingorderdetails } from '../Confirmorder.js/api';
import { downloadInvoice, fetchingmyorders, orderagain, ordercancel } from './api';
import { useDispatch, useSelector } from 'react-redux';
import { authSelector } from '../../Slices/auth';
import { fetchorders } from '../../Slices/orders';
// import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-simple-toast';
import { fetchcart } from '../../Slices/cart';
import RNFetchBlob from 'rn-fetch-blob';
import { IMAGE_URL_PRODUCTS } from '../../Constants';
import { ActivityIndicator } from 'react-native';
import Statusbar from '../Statusbar';



export default function Orderdetails(props) {
    const dispatch = useDispatch()
    const { width, height } = Dimensions.get("window")

    const data = {
        name: 'Order Details',
        search: false
    }
    const [returnorder, setReturnorder] = useState(false)
    const [active, setActive] = useState("")
    const [products, setProducts] = useState([])
    const [PDFpath, setPDFpath] = useState("")
    const [PDFpathname, setPDFpathname] = useState("")



    const { token } = useSelector(authSelector)
    const [details, setDetails] = useState({})
    const [loader, setloader] = useState(false)

    const modelclose = () => {
        setReturnorder(false)
        setActive("")
    }
    const confirm = () => {
        setReturnorder(false)
        setActive("")
    }

    useEffect(() => {
        get_orderdetails()

    }, [])

    const get_orderdetails = async () => {
        var data = {
            order_id: props.route.params.order_id,
            token: props.route.params.token
        }

        setloader(true)
        const output = await fetchingmyorders(data)
        console.log("output", output.orders.user_reward_histroies)
        setProducts(output.orders.order_list)
        setDetails(output.orders)
        setloader(false)
        // console.log("output.orders", output.orders.id)

        getPDF(output.orders.id)
    }






    const getPDF = async (id) => {

        var data = {
            order_id: id,
            token: token
        }
        const output = await downloadInvoice(data)
        console.log("invoice_path", output.success)

        if (output.success == true) {
            console.log("invoice_path", output.invoice_path)


            setPDFpathname(output.invoive_name)
            setPDFpath(output.invoice_path)
        }




    }
    const requestStoragePermission = async () => {
        try {
            const granted = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
                {
                    title: 'Storage Permission',
                    message: 'App needs access to your storage to download files.',
                    buttonPositive: 'OK',
                    buttonNegative: 'Cancel',
                },
            );
            return granted === PermissionsAndroid.RESULTS.GRANTED;
        } catch (err) {
            console.error('Failed to request permission:', err);
            return false;
        }
    }

    const downloadPDF = async () => {



        // Function to check the platform
        // If Platform is Android then check for permissions.

        if (Platform.OS === 'ios') {
            downloadFile();
        } else {
            const storagePermissionGranted = await requestStoragePermission();


            console.log("storagePermissionGranted", storagePermissionGranted)

            if (storagePermissionGranted == true) {

                RNFetchBlob.config({
                    fileCache: true,
                    addAndroidDownloads: {
                        useDownloadManager: true,
                        notification: true,
                        path: RNFetchBlob.fs.dirs.DownloadDir + '/' + PDFpathname,
                        mime: 'application/pdf',
                        description: 'Downloading PDF file...',
                    },
                })
                    .fetch('GET', PDFpath) // Replace with your PDF file URL
                    .then((res) => {
                        console.log('PDF downloaded to:', res.path());

                        // const toastStyle = {
                        //     backgroundColor: "yellow",
                        //     textColor: 'red',
                        // };

                        // ToastAndroid.showWithGravityAndOffset(
                        //     "File Downloaded Successfully",
                        //     ToastAndroid.LONG,
                        //     ToastAndroid.CENTER,
                        //     toastStyle, // Pass the custom style here
                        // );
                        var foregroundColor = "0xffffff";
                        var backgroundColor = "0x50A54A";
                        // Toast.showWithGravity('message', Toast.SHORT, Toast.TOP, foregroundColor, backgroundColor);


                        Toast.show("File Downloaded Successfully.", Toast.SHORT, "text");
                    })
                    .catch((error) => {
                        console.error('Failed to download PDF:', error);
                    });
            }



            // try {
            //     const granted = await PermissionsAndroid.request(
            //         PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            //         {
            //             title: 'Storage Permission Required',
            //             message:
            //                 'Application needs access to your storage to download File',
            //         }
            //     );
            //     if (granted === PermissionsAndroid.RESULTS.GRANTED) {

            //         // Start downloading
            //         downloadFile();
            //         console.log('Storage Permission Granted.');
            //     } else {
            //         // If permission denied then show alert
            //         Alert.alert('Error', 'Storage Permission Not Granted');
            //     }
            // } catch (err) {
            //     // To handle permission related exception
            //     console.log("++++" + err);
            // }
        }


    }


    const downloadFile = () => {

        // Get today's date to add the time suffix in filename
        let date = new Date();
        // File URL which we want to download
        let FILE_URL = PDFpath;
        // Function to get extention of the file url
        let file_ext = getFileExtention(FILE_URL);

        file_ext = '.' + file_ext[0];

        // config: To get response by passing the downloading related options
        // fs: Root directory path to download
        const { config, fs } = RNFetchBlob;
        let RootDir = fs.dirs.PictureDir;
        let options = {
            fileCache: true,
            addAndroidDownloads: {
                path:
                    RootDir +
                    '/file_' +
                    Math.floor(date.getTime() + date.getSeconds() / 2) +
                    file_ext,
                description: 'downloading file...',
                notification: true,
                // useDownloadManager works with Android only
                useDownloadManager: true,
            },
        };
        config(options)
            .fetch('GET', FILE_URL)
            .then(res => {
                // Alert after successful downloading
                console.log('res -> ', JSON.stringify(res));
                Toast.show("File Downloaded Successfully.", Toast.SHORT);


            });
    };

    const getFileExtention = fileUrl => {
        // To get the file extension
        return /[.]/.exec(fileUrl) ?
            /[^.]+$/.exec(fileUrl) : undefined;
    };



    const cancelorder = () => {

        Alert.alert('Cancel Order !', 'Are you sure want to cancel this order', [
            {
                text: 'Cancel',
                onPress: () => console.log('Cancel Pressed'),
                style: 'cancel',
            },
            {
                text: 'OK', onPress: async () => {

                    var data = {
                        order_id: details.id,
                        token: token
                    }
                    const output = await ordercancel(data)
                    if (output.message == "Order cancelled !") {
                        dispatch(fetchorders(token))
                        Toast.show("Order Canceled", Toast.SHORT);
                        props.navigation.navigate("Myorders")
                    }
                }

            },
        ]);

    }

    // console.log("tokkk",token)
    const order_again = async () => {



        var data = {
            order_id: details.id,
            token: token
        }
        const output = await orderagain(data)

        // console.log("output",output)
        if (output.message) {
            dispatch(fetchcart(token))
            Toast.show(output.message, Toast.SHORT);
            props.navigation.push("Cart")
        }



    }


    return (
        <SafeAreaView style={styless.container}>

            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />
            <Statusbar dataParentToChild={"white"} />
            {!loader ?
                <View style={{ width: width, height: height * 0.93, backgroundColor: "white", }} >
                    <ScrollView>
                        <View style={{ width: width, marginLeft: "4%" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "bold", fontSize: width * 0.058, color: "black" }} >Order Summary</Text>
                            {/* <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.035, color: "#cb576a" }} >order cancelled - Sorry, we were facing operational issues</Text> */}
                            <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "bold", fontSize: width * 0.05, color: "black", marginTop: "2%" }} >{products.length} items in this order</Text>

                        </View>
                        {/* <Allorders dataParentToChild={cartproducts} /> */}
                        <View style={{ width: "95%", height: 'auto', alignSelf: "center", marginBottom: "2.5%", marginTop: "2.5%" }} >
                            <OrderItems orderproducts={products} />
                        </View>

                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.018 }}></View>


                        <View style={{ width: width, }} >
                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%" }} >Bill Details </Text>

                            {details?.user_reward_histroies?.amount_debited && details?.user_reward_histroies?.amount_debited != "0.00" ?
                                <Card style={{ flexDirection: "row", backgroundColor: "lightgrey", justifyContent: "space-evenly", width: width * 0.925, height: "auto", marginTop: "2.5%", paddingTop: 10, paddingBottom: 10, alignSelf: "center", }} >

                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >{Number(details?.user_reward_histroies?.point_debited).toFixed(0)} points </Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >=</Text>

                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >$ {details?.user_reward_histroies?.amount_debited}</Text>

                                </Card>

                                : null}
                            <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "4%" }} >
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >Cart total</Text>


                                <View style={{ flexDirection: "row", alignItems: "center", }}>

                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >$ {details.sub_total}</Text>
                                    {details?.user_reward_histroies?.point_debited && details?.user_reward_histroies?.point_debited != "0.00" ?
                                        <>
                                            <Text style={{ fontSize: 17, fontWeight: "bold", color: "black", marginLeft: 2 }}> - </Text>

                                            <Image style={{ height: 20, width: 20, resizeMode: "contain" }} source={require("../../Assets/star.png")}></Image>
                                            <Text style={{ fontSize: width * 0.040, fontWeight: "500", color: "black", marginLeft: 2 }}>{Number(details?.user_reward_histroies?.point_debited).toFixed(0)} </Text>
                                        </>
                                        :
                                        null}
                                </View>



                            </View>
                            <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "4%" }} >
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >Shipping Charge</Text>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >$ {details.shipping_charge}</Text>
                            </View>
                            <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "4%" }} >
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >Packing Charge</Text>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >$ {details.packing_charge}</Text>
                            </View>

                            {/* <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "2%" }} >
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >Tax</Text>
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >+$2</Text>
                        </View> */}

                            {details.coupon_price != "0.00" ?
                                <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "2%" }} >
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >Coupon Amount</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} > - $ {details.coupon_price}</Text>
                                </View> : null}


                            {/* <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "2%" }} >
                                <Text style={{ fontSize: width * 0.045, }} >Sub Total</Text>

                                <View style={{ flexDirection: "row", alignItems: "center", }}>

                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, }} >$ {details.grand_total}</Text>
                                    {details?.user_reward_histroies?.point_debited ?
                                        <>
                                            <Text style={{ fontSize: 17, fontWeight: "400", color: "black", marginLeft: 2 }}> -  </Text>


                                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "black", marginLeft: 2 }}>{Number(details?.user_reward_histroies?.amount_debited).toFixed(2)} </Text>
                                        </>
                                        :
                                        null}

                                </View>
                            </View> */}

                            <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "2%" }} >
                                <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, }} >Grand Total</Text>
                                <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "bold" }} >$ {(Number(details.grand_total)).toFixed(2)}</Text>


                            </View>

                            {details?.user_reward_histroies?.point_credited && details?.user_reward_histroies?.point_credited != "0.00" ?
                                <View style={{ width: "100%", flexDirection: "row", height: height * 0.05, alignItems: "center", justifyContent: "center" }} >

                                    <Text style={{ fontWeight: "500", fontStyle: "italic", fontSize: width * 0.035, color: "red", }} >You received {Number(details?.user_reward_histroies?.point_credited).toFixed(0)} points from this order</Text>

                                </View>
                                :
                                null}

                        </View>




                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "2%" }}></View>

                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.048, marginTop: "4%", marginLeft: "4%" }} >Customer Details</Text>
                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "4%" }}></View>
                        {/* <View style={{ width: "100%", flexDirection: "row" }}> */}
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "4%", marginLeft: "4%", color: "#737373" }} >Name</Text>
                        <View style={{ flexDirection: "row", }}>
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "black" }} >{details.fname} {details.lname}</Text>
                        </View>
                        {/* </View> */}
                        {details.location_mode != "Pickup" ?
                            <>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Address</Text>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "black" }} >{details.address1}, {details.address2}, {details.city}, {details.zipcode}</Text>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "black" }} >{details.state}.</Text>
                            </> :

                            <View>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Address</Text>

                                <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "4%" }} >
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "35%" }} >Pickup Loacation</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "5%", textAlign: "center" }} >:</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "60%" }} >{details.pickup_location}</Text>
                                </View>
                                <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "4%" }} >
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "35%" }} >Pickup Time</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "5%", textAlign: "center" }} >:</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "60%" }} >{details.pickup_time}</Text>
                                </View>
                                <View style={{ width: "91%", flexDirection: "row", justifyContent: "space-between", alignSelf: "center", marginTop: "4%" }} >
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "35%" }} >Pickup Date</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "5%", textAlign: "center" }} >:</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, width: "60%" }} >{details.pickup_date}</Text>
                                </View>

                            </View>


                        }


                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.018, marginTop: "2%" }}></View>

                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%" }} >Order Details </Text>
                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "5%" }}></View>

                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Order id</Text>
                        <View style={{ flexDirection: "row", }}>
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "black" }} >#{details.id}</Text>
                            {/* <Image source={require("../../Assets/copyy.png")} style={{ width: 15, height: 15, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} /> */}
                        </View>

                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Payment Method</Text>
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "black" }} >{details.payment_type}</Text>


                        {/* <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Payment Status</Text>
                  
                    <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, marginTop: "1%", marginLeft: "4%", color: "red" }} >Not Paid</Text> */}

                        {/* <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Delivery to</Text>
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "black" }} >hhh, bbb</Text> */}
                        <View style={{ marginTop: "4%", alignSelf: "center", flexDirection: "row", width: "92%", height: 50, justifyContent: "space-between", alignItems: "center" }}>
                            <View>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, color: "#737373" }} >Order created</Text>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black" }} >{details.created_at}</Text>
                            </View>
                            <TouchableOpacity onPress={() => downloadPDF()} style={{ borderRadius: 10, borderWidth: 1, borderColor: "white", flexDirection: "row", backgroundColor: "#00a4ff", height: 30, justifyContent: "center", alignItems: "center" }}>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "white" }} >Download PDF</Text>
                                <Image source={require("../../Assets/pdf.png")} style={{ width: 20, height: 20, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} />
                            </TouchableOpacity>

                        </View>


                        {/* <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, color: "#737373", marginTop: "5%", marginLeft: "4%", }} >Order created</Text>
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", marginTop: "1%", marginLeft: "4%", }} >{details.created_at}</Text> */}
                        {details.note ?
                            <>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Notes</Text>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, marginTop: "1%", marginLeft: "4%", color: "black" }} >{details.note}</Text>
                            </> : null}
                        {details.refund_status ?
                            <>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Refund Status</Text>
                                <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, marginTop: "1%", marginLeft: "4%", color: "#00a4ff" }} >Success</Text>
                            </> : null}




                        {details.status == "Confirmed" ?


                            <View style={{ alignSelf: "center", flexDirection: "row", width: "92%", height: 50, justifyContent: "space-between", alignItems: "center", marginTop: "5%", }}>
                                <View>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, color: "#737373" }} >Order Status</Text>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black" }} >{details.status}</Text>
                                </View>
                                <TouchableOpacity onPress={() => downloadPDF()} style={{ borderRadius: 10, borderWidth: 1, borderColor: "white", flexDirection: "row", backgroundColor: "#00a4ff", height: 30, justifyContent: "center", alignItems: "center" }}>
                                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, marginTop: "1%", marginLeft: "4%", color: "white" }} >Download PDF</Text>
                                    <Image source={require("../../Assets/pdf.png")} style={{ width: 20, height: 20, resizeMode: "contain", marginLeft: "2%", marginTop: "1.5%" }} />
                                </TouchableOpacity>

                            </View>
                            :
                            <View>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginTop: "5%", marginLeft: "4%", color: "#737373" }} >Order Status</Text>
                                <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, marginTop: "1%", marginLeft: "4%", }} >{details.status}</Text>
                            </View>

                        }






                        <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.018, marginTop: "2%" }}></View>

                        {/* <View style={{ width: "100%", height: height * 0.09, flexDirection: "row", alignItems: "center", }} >
                        <Image source={require("../../Assets/boss.png")} style={{ width: 40, height: 40, resizeMode: "contain", marginLeft: "4%", }} />
                        <View style={{}}>
                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Need help with your order ?</Text>
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.042, marginLeft: "4%", color: "#737373" }} >Support is always available </Text>
                        </View>

                    </View> */}
                        {details.status != "Cancelled" ?
                            <View style={{ width: "100%", height: height * 0.1, backgroundColor: "f5f5f5", flexDirection: "row", alignItems: "center", justifyContent: "space-evenly" }} >



                                <Card style={{ width: "40%", height: "60%", backgroundColor: "red", justifyContent: "center" }} >
                                    <TouchableOpacity onPress={() => cancelorder()} >
                                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.042, marginLeft: "4%", color: "white", textAlign: "center" }} >Cancel order</Text>
                                    </TouchableOpacity>
                                </Card>

                            </View>
                            : null}



                        <Modal
                            animationType="slide"
                            transparent={true}
                            visible={returnorder}

                        >

                            <View style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)" }} >
                                <View style={{ position: "absolute", bottom: 0, }} >
                                    <TouchableOpacity onPress={() => modelclose()} style={{ width: width * 0.11, height: height * 0.055, backgroundColor: "black", borderRadius: width * 0.07, alignSelf: "center", justifyContent: "center", bottom: 15 }} >
                                        <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/reject.png')} />
                                    </TouchableOpacity>
                                    <Card style={styless.container1} >
                                        <Text style={styless.text1} >Reason for return order</Text>
                                        <View style={{ width: width * 0.9, borderWidth: 1, height: height * 0.2, alignSelf: "center", marginTop: "3%" }}>
                                            <TextInput
                                                onChangeText={(text) => setActive(text)}
                                                value={active}
                                                multiline={true}
                                                style={{ fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", width: "99%" }}
                                                placeholder={'Enter the reason'}
                                            />
                                        </View>

                                        <TouchableOpacity onPress={() => confirm()}>
                                            <View style={{ marginTop: "8.35%", alignItems: "center", borderRadius: width * 0.025, width: "60%", height: height * 0.060, alignSelf: "center", backgroundColor: "red", justifyContent: "center" }} >
                                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.050, color: "white" }} >Confirm</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </Card>
                                </View >
                            </View>

                        </Modal>
                    </ScrollView>
                </View >
                :
                <View style={{ height: "92%", width: "100%", justifyContent: "center", alignItems: "center" }}>
                    <ActivityIndicator size={30} color={'gray'} />
                </View>
            }
        </SafeAreaView >
    )
}