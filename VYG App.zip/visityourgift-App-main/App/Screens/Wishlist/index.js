import { width } from 'deprecated-react-native-prop-types/DeprecatedImagePropType';
import React, { useState, useEffect, Component } from 'react';
import { View, Text, SafeAreaView, Image, Dimensions, ImageBackground, StatusBar, ActivityIndicator } from 'react-native';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import { useDispatch, useSelector } from 'react-redux';
import Carthelp from '../../Components/carthelp';
import Helperhome from '../../Components/helperhome';
import Homeproducts from '../../Components/Homeproducts';
import Productdetail from '../../Components/productdetail';
import Header from '../../Navigator/Header';
import { authSelector } from '../../Slices/auth';
import { cartSelector, fetchcart } from '../../Slices/cart';
import { wishlistSelector } from '../../Slices/whishlist';
import { Recommendedproduct } from '../TestData/data';
import styles from './style';


export default function Wishlist(props) {
    const { cart_length, cart_total, cart_products } = useSelector(cartSelector);
    const dispatch = useDispatch()
    const { token } = useSelector(authSelector)
    useEffect(() => {
        dispatch(fetchcart(token))
        setTimeout(() => {
            setLoader(false)
        }, 1500)

    }, [wishlist_products])
    const { wishlist_products } = useSelector(wishlistSelector)
    const { width, height } = Dimensions.get("window")
    const [loader, setLoader] = useState(true)
    const data = {
        name: 'My Wishlist',
        search: false
    }
    const back = () => {
        dispatch(fetchcart(token))
        props.navigation.goBack()
    }
    const cartfn = () => {
        dispatch(fetchcart(token))
        props.navigation.navigate("Cart")
    }
    return (
        <SafeAreaView style={styles.container}>
            {/* <Helperhome /> */}
            <Header dataParentToChild={data} Back={() => back()} />

            {wishlist_products.length > 0 ?
                <>
                    {loader ?
                        <ActivityIndicator color={'black'} /> :
                        <View style={(cart_length > 0)?   { width: width, height: height * 0.80, marginTop: "2%", }:{ width: width, height: height * 0.91, marginTop: "2%" }} >
                            <Homeproducts dataParentToChild={{ data: wishlist_products, key: "wishlist" }} />
                        </View>}
                </> 
                :
                <View style={{ width: "100%", height: "90%", alignItems: "center", justifyContent: "center" }} >
                    <Image source={require('../../Assets/cloud.png')} style={{ width: 100, height: 100, alignSelf: "center" }} />
                    <Text style={{ fontSize: 20, textAlign: 'center', color: '#366ebe', marginTop: 30, marginLeft: 10 }}>No Products found</Text>
                </View>}
            <Productdetail />


            {(cart_length > 0) ?

                <Carthelp cartcall={() => cartfn()} />
                : null}

        </SafeAreaView>
    )
}