import { Dimensions,StyleSheet} from "react-native"

const {width,height}=Dimensions.get("window")
export default styles = StyleSheet.create({
    container:{
        flex:1,
      
    },
    header:{
        width:"100%",
        height:height*0.075,
        backgroundColor:"white",
        flexDirection:"row",
        alignItems:"center"
    },
    back:{
        width:width*0.05,
        height:height*0.03,
        alignSelf:"center", 
    },
    text1:{
        fontSize:width*0.0475,
        // fontWeight:"600",
        textAlign:"center",
        marginLeft:"28.5%",
        fontFamily:"Roboto-Bold"
    },
    text2:{
        fontSize:width*0.0425,
        textAlign:"center",
        marginTop:"5%",
        fontFamily:"Roboto-Light",
        fontWeight:"600"
    },
    text3:{
        fontSize:width*0.0425,
        textAlign:"center",
        fontFamily:"Roboto-Bold"
    },
    otp_container:{
        width:"60%",
        height:height*0.1,
        alignSelf:"center",
        alignItems:"center",
        justifyContent:"space-around",
        marginTop:"10%",
        flexDirection:"row"
    },
    box_container:{
        width:"20%",
        height:"67.5%",
        borderRadius:width*0.02,
        borderWidth:width*0.003,
        borderColor:'black'
    },
    box_container1:{
        width:"20%",
        height:"67.5%",
        borderRadius:width*0.02,
        borderWidth:width*0.003,
        borderColor:'gray'
    },
    text4:{
        fontSize:width*0.0425,
        textAlign:"center",
        fontWeight:"700",
        color:"#D3D3D3",
        marginTop:"5%"   ,
        fontFamily:"Roboto-Light",
    }
})