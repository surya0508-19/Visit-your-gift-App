
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, TextInput, KeyboardAvoidingView, ActivityIndicator, ScrollView } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';
import { Card } from 'react-native-shadow-cards';
import { fetchingenquiry } from './api';
import { authSelector } from '../../Slices/auth';
import { useSelector } from 'react-redux';

import Toast from 'react-native-simple-toast';

export default function InviteFriends(props, { navigation }) {



    const { token } = useSelector(authSelector)


    const [loder, setLoader] = useState(false)

    const [auth, setAuth] = useState(false)
    const [value, setValue] = useState('')
    const { width, height } = Dimensions.get("window")

    const data = {
        name: 'Invite Friends',
        search: false
    }

    const Confirm = async () => {




        if (value == "") {

            Toast.show("Please Enter Your Comments", Toast.SHORT);

        } else {

            var data = {
                "message": value
            }
            setLoader(true)
            const output = await fetchingenquiry(data, token)

            console.log("vvvv", output)


            setLoader(false)


            if (output.success == true) {

                Toast.show(output.message, Toast.SHORT);

                props.navigation.navigate("Sidemenu")

            }

        }

    }

    return (



        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />

            <Image style={{ height: 200, width: "100%", marginTop: 5, resizeMode: 'contain' }} source={require("../../Assets/reff.png")}></Image>

            <Text style={{ fontSize: 30, color: 'black', fontWeight: "bold", marginLeft: "6%", }}>Invite friends.</Text>
            <Text style={{ fontSize: 30, color: 'black', fontWeight: "bold", marginLeft: "6%", lineHeight: 32 }}>Get $15 git cards.</Text>





            <View style={{ flexDirection: "row", height: 50, marginTop: 20, }}>

                <Image style={{ height: 22, width: 22, marginLeft: "6%", marginTop: 5 }} source={require("../../Assets/tag.png")}></Image>

                <View style={{ marginLeft: "4%" }}>
                    <Text style={{ fontSize: 18, color: 'black', fontWeight: "bold", }}>Your friends get 60% off</Text>
                    <Text style={{ fontSize: 12, color: 'grey', fontWeight: "500", }}>On their first 1st Visit Your Gift order, upto $20 off.</Text>
                </View>

            </View>



            <View style={{ flexDirection: "row", height: 50, marginTop: 20, }}>

                <Image style={{ height: 22, width: 22, marginLeft: "6%", marginTop: 5 }} source={require("../../Assets/dollar-bill.png")}></Image>

                <View style={{ marginLeft: "4%" }}>
                    <Text style={{ fontSize: 18, color: 'black', fontWeight: "bold", width: "60%" }}>You get $15 Visit Your Gift gift cart for each friend that makes an order.</Text>
                    <Text style={{ fontSize: 12, color: 'grey', fontWeight: "500", }}>No order minimum</Text>
                </View>

            </View>

            <View style={{ height: 47, marginTop: "15%", backgroundColor: "#00a4ff", width: "90%", borderRadius: 20, alignSelf: "center", justifyContent: "center", alignItems: "center" }}>

                <Text style={{ fontSize: 17, color: 'white', fontWeight: "bold", }}>Invite friends</Text>

            </View>


            <View style={{ height: 47, flexDirection: "row", justifyContent: "space-between", marginTop: "5%", borderWidth: 1, borderStyle: "dashed", width: "90%", borderRadius: 20, alignSelf: "center", alignItems: "center" }}>

                <Text style={{ fontSize: 17, color: 'black', fontWeight: "400", marginLeft: 10 }}>GOGKVYL84X</Text>

                <Text style={{ fontSize: 13, color: 'black', fontWeight: "600", marginRight: 10 }}>Copy code</Text>


            </View>



        </SafeAreaView >


    )
}