import axios from "axios"
import { URL_FORGET_PASSWORD, URL_FORGET_PASSWORD1 } from "../../../Constants"
import { URL_ENQUIRY } from "../../Constants"

export const fetchingenquiry = async (data, token) => {

  console.log("data",data,token)
  try {
    const response = await axios({
      method: "post",
      url: `${URL_ENQUIRY}`,
      headers: {
        Authorization:token
      },
      data: data
    })
    if (response.data) {
      return response.data
    }
  }
  catch (err) {
    console.log("error", err)
  }
}