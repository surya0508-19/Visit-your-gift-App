import { Dimensions, StyleSheet } from "react-native"

const { width, height } = Dimensions.get("window")
export default styles = StyleSheet.create({
    container: {
        height: "100%",
        width: "100%",
        backgroundColor: "white"

    },
    header: {
        width: "100%",
        height: height * 0.075,
        backgroundColor: "white",
        flexDirection: "row",
        alignItems: "center"
    },
    back: {
        width: width * 0.05,
        height: height * 0.03,
        alignSelf: "center",
    },
    text1: {
        fontSize: width * 0.0475,
        // fontWeight:"600",
        textAlign: "center",
        marginLeft: "5%",
        fontFamily: "Roboto-Bold"
    },
    text2: {
        fontSize: width * 0.045,
        marginLeft: "5%",
        marginTop: "5%",
        fontFamily: "Roboto-Regular",
        fontWeight: "600",

        height: 25
    },
    text3: {
        fontSize: width * 0.0425,
        textAlign: "center",
        fontFamily: "Roboto-Bold"
    },
    otp_container: {
        width: "60%",
        height: height * 0.1,
        alignSelf: "center",
        alignItems: "center",
        justifyContent: "space-around",
        marginTop: "10%",
        flexDirection: "row"
    },
    box_container: {
        width: "20%",
        height: "67.5%",
        borderRadius: width * 0.02,
        borderWidth: width * 0.003,
        borderColor: 'black'
    },
    box_container1: {
        width: "20%",
        height: "67.5%",
        borderRadius: width * 0.02,
        borderWidth: width * 0.003,
        borderColor: 'gray'
    },
    text4: {
        fontSize: width * 0.0425,
        textAlign: "center",
        fontWeight: "700",
        color: "#D3D3D3",
        marginTop: "5%",
        fontFamily: "Roboto-Light",
    },
    login: {
        width: width * 0.9,
        height: height * 0.3,
        backgroundColor: "white",
        alignSelf: "center",
        marginTop: "7.5%",
        borderColor: "gray",
        borderWidth: 0.4,
        elevation: 5,

    },
    button_container: {
        width: width * 0.9,
        height: height * 0.075,
        backgroundColor: "#00a4ff",
        alignSelf: "center",
        justifyContent: "center",
        marginTop: "10%",
        marginBottom: "15%",
        borderRadius: 10,
    },
    continue_text: {
        textAlign: "center",
        fontSize: width * 0.045,
        color: "white",
        fontFamily: "Roboto-Medium"
    },
})