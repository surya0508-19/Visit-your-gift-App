import { Dimensions,StyleSheet} from "react-native"

const {width,height}=Dimensions.get("window")
export default styles = StyleSheet.create({
   container:{
     flex:1,
     backgroundColor:"#fffff"
   },
   recomended:{ width: "100%", height: "auto", backgroundColor: "#d3d3d33d", marginTop: "2.5%", marginBottom: "25%", },
   recomended1:{ width: "100%", height: "auto", backgroundColor: "#d3d3d33d", marginTop: "2.5%", marginBottom: "2.5%", }

})