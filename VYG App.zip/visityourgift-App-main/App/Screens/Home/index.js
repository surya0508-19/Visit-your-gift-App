import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, Image, Dimensions, BackHandler, Animated, FlatList, Modal, ScrollView, SafeAreaView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Homeheader';
import Search from '../../Components/search';
import { AnimatedScrollView } from '@kanelloc/react-native-animated-header-scroll-view';
import Banner from '../../Components/Banner';
import Helperhome from '../../Components/helperhome';
import Bestoffers from '../../Components/Bestoffers';
import Categories from '../../Components/Categories';
import Grocerystores from '../../Components/Grocerystores';
import Recommandedproducts from '../../Components/Recommandedproduct';
import Carthelp from '../../Components/carthelp';
import { TopsellingProducts, Recommendedproduct } from '../TestData/data';
import Homeproducts from '../../Components/Homeproducts';
import { countSelector } from '../../Slices/count';
import { useDispatch, useSelector } from 'react-redux';
import SearchLocation from '../../Components/searchlocation';
import Productdetail from '../../Components/productdetail';
import LinearGradient from 'react-native-linear-gradient';
import { get_categoriescount, homedataSelector } from '../../Slices/homedata';
import { cartSelector, fetchcart } from '../../Slices/cart';
import Toast from 'react-native-simple-toast';
import VersionCheck from 'react-native-version-check';

import { authSelector } from '../../Slices/auth';
import { fetchtopbrands } from '../../Slices/searchproducts';
import style from './style';
import { deliverychargeSelector } from '../../Slices/deliverycharge';
import { onPress } from 'deprecated-react-native-prop-types/DeprecatedTextPropTypes';
import Statusbar from '../Statusbar';
import { StatusBar } from 'react-native';
import { Linking } from 'react-native';
import { fetchprofile } from '../../Slices/profile';
export default function Home(props, navigation) {
  const dispatch = useDispatch()
  const { token } = useSelector(authSelector)
  const { topselling, recommended, loadersts } = useSelector(homedataSelector)
  const { categories, categorycount } = useSelector(homedataSelector)

  const [modelshow, setModalshow] = useState(false)


  const [update, setUpdate] = useState(false)
  const [playstoreurl, setPlaystoreurl] = useState("")

  const [loader, setLoader] = useState(false)
  const { cart_length, cart_total, cart_products } = useSelector(cartSelector);
  const { width, height } = Dimensions.get("window")
  const [show, setShow] = useState(false)
  const [count, setCount] = useState(0)
  const { minimum_charge } = useSelector(deliverychargeSelector)
  const opendrawer123 = () => {
    props.navigation.openDrawer();
  }
  const cartfn = () => {
    dispatch(fetchcart(token))
    props.navigation.navigate("Cart")
  }


  useEffect(() => {
    checkVersion();
 
  }, []);
  console.log("categorycountcategorycountcategorycount", categorycount)
  const checkVersion = async () => {

    // const currentVersion = await VersionCheck.getCurrentVersion();
    // console.log("currentVersion",currentVersion);

    // const latestVersion = await VersionCheck.getLatestVersion();
    // console.log("latestVersion",latestVersion);

    try {
      let updateNeeded = await VersionCheck.needUpdate();
      console.log("updateneeded", updateNeeded)

      if (Number(updateNeeded.latestVersion) < Number(updateNeeded.currentVersion)) {
        // Alert.alert(
        //   'Please Update',
        //   'You will have to update your app to the latest version to continue using.',
        //   [
        //     {
        //       text: 'Update',
        //       onPress: () => {
        //         BackHandler.exitApp();
        //         Linking.openURL(updateNeeded.storeUrl);
        //       },
        //     },
        //   ],
        //   { cancelable: false },
        // );


        setPlaystoreurl(updateNeeded.storeUrl)



        setUpdate(true)
      }


    } catch (error) { }




  };











  // useEffect(() => {
  //   console.log("COUNT",count)
  //   if(count < 1)
  //   {
  //     if(cart_total > minimum_charge)
  //     {
  //       console.log("MINIMUMCHARGE",minimum_charge)
  //       console.log("CARTTOTAL",cart_total)
  //       console.log("BEFORE",show)
  //       setShow(true)
  //       setTimeout(() => {
  //         setShow(false)
  //         console.log("AFTER",show)
  //       },2000)
  //       setCount(count+1)
  //     }
  //   }
  // },[cart_total])

  // useEffect(() => {
  //   getgif()
  // },[cart_total])
  // const getgif = () => {
  //    console.log("count",count)
  //  if(count == 0)
  //   {
  //     if(cart_total > minimum_charge)
  //     {
  //       setShow(true)
  //       setTimeout(() => {
  //         setShow(false)
  //        },2000)
  //       setCount(count+1)
  //     }
  //   }

  // }

  useEffect(() => {



    BackHandler.addEventListener("hardwareBackPress", backAction);
    return () =>
      BackHandler.removeEventListener("hardwareBackPress", backAction);


  }, []);

  const backAction = () => {
    if (props.navigation.isFocused()) {
      BackHandler.exitApp()
    } else {
      props.navigation.goBack()

    }
    return true;
  };


  const SearchPage = () => {


    dispatch(fetchtopbrands(cart_products, token))

    props.navigation.navigate("SearchPage")


  }


  const login = () => {


    Toast.show("Please Login to Purchase", Toast.SHORT);

    props.navigation.navigate("login")


  }
  const CategorySeemore = (type) => {
    if (type == "more") {
      dispatch(get_categoriescount(categories.length))
    }
    else {
      dispatch(get_categoriescount(9))

    }
  }



  return (

    <SafeAreaView style={{ flex: 1, backgroundColor: "white" }} >


      <Header
        DrawerCall={opendrawer123}
        search={() => SearchPage()}
        cartcall={() => cartfn()}
        locationcall={() => setModalshow(true)}
        notificationcall={() => props.navigation.navigate("Notification")} />


      <ScrollView>
        {/* <View style={{ width: width, height: height * 0.3, justifyContent: "center", }} >
          <Banner />
        </View> */}
        <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "2.5%", }} >All Categories</Text>
        <View style={{ width: "100%", height: "auto", backgroundColor: "white", marginTop: "2.5%", alignItems: "center", marginBottom: "2.5%", }} >
          <Categories Searchcall={() => props.navigation.navigate("Productscategory")} />
          {/* {categories.length ?
            <>
              {categorycount == 9 ?
                <TouchableOpacity onPress={() => CategorySeemore("more")} style={{ borderRadius: 8, width: "25%", height: 25, backgroundColor: "#00a4ff", marginTop: 5, marginBottom: 10, justifyContent: "center", alignItems: "center" }}>
                  <Text style={{ color: "white", fontSize: 14 }}>Show More</Text>
                </TouchableOpacity>
                :
                <TouchableOpacity onPress={() => CategorySeemore("less")} style={{ borderRadius: 8, width: "25%", height: 25, backgroundColor: "#00a4ff", marginTop: 5, marginBottom: 10, justifyContent: "center", alignItems: "center" }}>
                  <Text style={{ color: "white", fontSize: 14 }}>Show Less</Text>
                </TouchableOpacity>
              }
            </>
            : null} */}

        </View>
        <Helperhome />

        <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "2.5%" }} >Top Selling Products</Text>
        <Text style={{ fontFamily: "Roboto-Light", marginLeft: "2.5%", fontSize: width * 0.035 }} >{topselling.length} Products</Text>
        <View style={{ width: "100%", height: "auto", backgroundColor: "#d3d3d33d", marginTop: "2.5%", marginBottom: "20%", }} >
          {!loadersts ?
            <Homeproducts logincall={() => login()} dataParentToChild={{ data: topselling, key: "topselling" }} /> :
            <ActivityIndicator color={"black"} />}
        </View>
        <Helperhome />
        {/* <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.045, marginTop: "2.5%", }} >Recommanded Products</Text>
        <View style={cart_length > 0 ? style.recomended : style.recomended1} >
          {!loadersts ?
            <Homeproducts logincall={() => login()} dataParentToChild={{ data: recommended, key: "recommended" }} /> :
            <ActivityIndicator color={"black"} />}
        </View> */}
      </ScrollView>


      {/**************************************** ANIMATED GIF *******************************************/}
      {/* {show ?
        <View style={{ width: width * 0.9, height: height * 0.2, position: "absolute", bottom: "11%", alignSelf: "center", justifyContent: "center" }} >
          <Image style={{ width: "80%", height: "80%", alignSelf: "center" }} source={require("../../Assets/party2.gif")} />
        </View> : null} */}
      {cart_length > 0 ?

        <Carthelp cartcall={() => cartfn()} />
        : null}

      <Productdetail />




      <Modal
        animationType="slide"
        transparent={true}
        visible={update}

      >

        <View style={{ height: "100%", width: "100%", justifyContent: "center", alignItems: "center", backgroundColor: "rgba(52, 52, 52, 0.8)" }} >

          <StatusBar
            backgroundColor={"black"}
            barStyle="dark-content"
          />

          <Card style={{ height: 220, width: "90%", justifyContent: "space-evenly", alignItems: "center" }}>


            <Text style={{ fontSize: 20, color: "black", fontWeight: "600" }}>Warning !</Text>


            <Text style={{ fontSize: 18, color: "black", fontWeight: "600" }}>You will have to update your app to the latest version to continue using.</Text>

            <TouchableOpacity onPress={() => Linking.openURL(playstoreurl)} style={{ borderRadius: 8, width: "35%", height: 35, backgroundColor: "#00a4ff", marginTop: 5, marginBottom: 10, justifyContent: "center", alignItems: "center" }}>
              <Text style={{ color: "white", fontSize: 17 }}>Update</Text>
            </TouchableOpacity>
          </Card>

        </View>
      </Modal>



    </SafeAreaView>



  )
}