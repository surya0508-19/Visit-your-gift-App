import { Dimensions, StyleSheet } from "react-native"

const { width, height } = Dimensions.get("window")
export default styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fffff"
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22
  },

  container1: {
    width: width * 0.94,
    height: height * 0.4,
    backgroundColor: "white",
    borderRadius: width * 0.015,
    alignItems: "center"


  },

  searchdata:{ backgroundColor: "white", width: "100%", height:height*0.5, marginTop: "2.5%", justifyContent:"center",},

  searchdata1:{ backgroundColor: "#d3d3d33d", width: "100%", height: "auto", marginTop: "2.5%", marginBottom: "30%", },

  searchdata2:{ backgroundColor: "#d3d3d33d", width: "100%", height: "auto", marginTop: "2.5%", marginBottom: "30%", },

  searchdata3:{ backgroundColor: "white", width: "100%", height: height*0.5, marginTop: "2.5%", marginBottom: "35%", alignItems: "center" ,},
  
  searchdataempty:{backgroundColor: "#d3d3d33d", width: "100%", height: "auto", marginTop: "2.5%",  marginBottom: "10%",}
})