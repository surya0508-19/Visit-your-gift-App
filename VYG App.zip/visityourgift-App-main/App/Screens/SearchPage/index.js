import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ActivityIndicator, Animated, FlatList, Modal, SafeAreaView, TextInput, ScrollView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import SearchProducts from '../../Components/SearchProducts';
import SearchProducts1 from '../../Components/SearchProducts1';

import Carthelp from '../../Components/carthelp';
import { countSelector } from '../../Slices/count';
import { useDispatch, useSelector } from 'react-redux';
import SearchLocation from '../../Components/searchlocation';
import Productdetail from '../../Components/productdetail';
import Statusbar from '../../Screens/Statusbar';
import Voice from '@react-native-voice/voice';
import { authSelector } from '../../Slices/auth';

import Toast from 'react-native-simple-toast';

// import Voice from '@react-native-community/voice';
import style from './style';

import { searchdataSlector, fetchsearchproducts, get_searchdata, get_branddata, update_nodata, fetchtopbrands, fetchbrandproducts } from '../../Slices/searchproducts';

import { cartSelector, fetchcart } from '../../Slices/cart';


export default function SearchPage(props, navigation) {


  const dispatch = useDispatch()

  const { cart_products } = useSelector(cartSelector)

  const { token } = useSelector(authSelector)


  const { cart_length, cart_total } = useSelector(cartSelector);


  const { seaching, loadersts, brandlist, nodata } = useSelector(searchdataSlector)


  console.log(nodata, "update_nodata")

  const slicedArray = brandlist.slice(0, 9);


  const [modalVisible, setModalVisible] = useState(false);

  const [mikeactive, setMikeactive] = useState(false);
  const [speakout, setSpeakout] = useState("Speak out Keywords!");

  const [Google, setGoogle] = useState(false);
  const [hidebrand, setHidebrand] = useState(false);
  const [error, setError] = useState('');
  const [end, setEnd] = useState('');
  const [started, setStarted] = useState('');
  const [results, setResults] = useState([]);
  const [typetext, settypetext] = useState("");
  const [countrysearch, setcountrysearch] = useState("");

  const [partialResults, setPartialResults] = useState([]);
  const [countrynamelist, setcountrynamelist] = useState([]);
  const [countrynamelistshow, setcountrynamelistshow] = useState(false);

  useEffect(() => {







    Voice.onSpeechStart = onSpeechStart;
    Voice.onSpeechEnd = onSpeechEnd;
    Voice.onSpeechResults = onSpeechResults;
    Voice.onSpeechError = onSpeechError;
    // Voice.stop=onSpeechStop;



  }, []);

  const onSpeechStart = (e) => {
    //Invoked when .start() is called without error
    console.log('onSpeechStart: ', e);
    setStarted('√');
  };
  const onSpeechStop = (e) => {
    //Invoked when .start() is called without error
    console.log('onSpeechStop: ', e);
    // setStarted('√');
  };
  const onspeechStop = (e) => {
    Voice.destroy()
    setModalVisible(false)

  };

  const onSpeechEnd = (e) => {
    //Invoked when SpeechRecognizer stops recognition
    console.log('onSpeechEnd: ', e);
    setEnd('√');
  };

  const onSpeechError = (e) => {
    //Invoked when an error occurs.
    console.log('onSpeechError: ', e);
    setError(JSON.stringify(e.error));
  };

  const onSpeechResults = (e) => {


    console.log('onSpeechRe', e.value);

    detail(e.value[0])


    setResults(e.value[0]);
    settypetext(e.value[0])
    setGoogle(true)
    setTimeout(() => {
      setModalVisible(false)
    }, 1300)
    Voice.onSpeechEnd = onSpeechEnd;


  };


  const startRecognizing = async () => {

    setResults('')
    settypetext('')
    setError('')
    Voice.start('en-US')

  };



  const ClickMike = () => {
    setModalVisible(true)
    setMikeactive(true)
    startRecognizing()
    setGoogle(false)
  }
  const Close = () => {

    // Voice.stop()
    settypetext('')
    // setMikeactive(true)
    // // startRecognizing()
    // setGoogle(false)
    setHidebrand(false)

    var data = []
    dispatch(get_searchdata(data))

    dispatch(fetchtopbrands(cart_products))
    dispatch(update_nodata(true))
    Voice.stop()



  }

  const data = "white"

  const { width, height } = Dimensions.get("window")

  const detail = (text) => {

    settypetext(text)

    setcountrysearch('')
    // console.log("vvvvv",text)
    if (text.length) {
      dispatch(fetchsearchproducts(cart_products, text, token))

      setHidebrand(true)
    } else if (text.length == 0) {

      setHidebrand(false)
      dispatch(get_searchdata([]))
      dispatch(update_nodata(true))



    }
  }
  const CountrySearchFuc = (text, get) => {
    if (get == false) {
      setcountrynamelistshow(false)

    }
    else {
      setcountrynamelistshow(true)

    }
    setcountrysearch(text)
    settypetext('')
    // console.log("vvvvv",text)
    if (text.length) {

      dispatch(fetchbrandproducts(text, cart_products, token))
      setHidebrand(true)
      var filter = brandlist.filter(item => item.name.startsWith(text));

      console.log("filter", filter)

      setcountrynamelist(filter)
    } else if (text.length == 0) {

      setHidebrand(false)
      dispatch(get_searchdata([]))
      dispatch(update_nodata(true))
      setcountrynamelist([])

    }



  }


  const goback = () => {


    dispatch(get_searchdata([]))
    dispatch(update_nodata(true))

    props.navigation.goBack()


  }
  const cartfn = () => {
    dispatch(fetchcart(token))
    props.navigation.navigate("Cart")
  }


  const logincall = () => {


    Toast.show("Please Login to Purchase", Toast.SHORT);

    props.navigation.navigate("login")


  }

  return (

    <SafeAreaView style={{ width: "100%", height: "100%", backgroundColor: "white" }} >
      <Statusbar dataParentToChild={data} />
      <Card style={{ alignSelf: "center", width: "95%", height: height * 0.05, backgroundColor: "white", marginTop: "4%" }} >
        <View style={{ flexDirection: "row", alignItems: "center", width: "100%", height: "100%" }}  >
          <TouchableOpacity onPress={() => goback()} style={{ width: "12%", height: "100%", justifyContent: "center", alignItems: "center" }} >
            <Image source={require("../../Assets/back.png")} style={{ width: width * 0.055, height: height * 0.0275, alignSelf: "center" }} />
          </TouchableOpacity>
          <View style={{ width: "78%", height: "100%", justifyContent: "center" }} >
            <TextInput onChangeText={(text) => detail(text)} value={typetext} placeholder='Search' style={{ height: 50, fontSize: width * 0.0425, fontFamily: "Roboto-Light", marginLeft: "2%" }} ></TextInput>
          </View>

          <View style={{ width: width * 0.001, height: height * 0.03, backgroundColor: "grey" }}></View>
          {typetext ?

            <TouchableOpacity onPress={() => Close()} style={{ width: "10%", height: "100%", justifyContent: "center", }} >
              <Image source={require("../../Assets/exit.png")} style={{ width: width * 0.055, height: height * 0.0275, alignSelf: "center" }} />
            </TouchableOpacity>
            :
            <TouchableOpacity onPress={() => ClickMike()} style={{ width: "10%", height: "100%", justifyContent: "center", }} >
              <Image source={require("../../Assets/mic.png")} style={{ width: width * 0.055, height: height * 0.0275, alignSelf: "center" }} />
            </TouchableOpacity>
          }
        </View>
      </Card>
      {/* <Card style={{ alignSelf: "center", width: "95%", height: "auto", backgroundColor: "white", marginTop: "4%" }} >
        <TextInput onChangeText={(text) => CountrySearchFuc(text)} value={countrysearch} placeholder='Country Name' style={{ height: 50, fontSize: width * 0.0425, fontFamily: "Roboto-Light", marginLeft: "2%" }} ></TextInput>

        {countrynamelistshow && countrynamelist.map((e, i) => (
          <TouchableOpacity onPress={() => CountrySearchFuc(e.name, false)}>
            <Text style={{ color: "black", fontSize: 17, paddingLeft: "4%", paddingTop: 12, paddingBottom: 12, borderTopWidth: 0.5, borderColor: "grey" }}>{e.name}</Text>
          </TouchableOpacity>
        ))}
      </Card> */}




      {/* <View style={{ alignSelf: "center", width: "100%", backgroundColor: "white", marginTop: "5%" }} > */}
      <ScrollView>
        {/* {hidebrand == false ?
          <View style={{ flexDirection: "row", width: "100%", height: height * 0.055, backgroundColor: "white", marginTop: "2.5%" }} >
            <View style={{ width: "12%", height: "100%", justifyContent: "center", alignItems: "center" }} >
              <Image source={require("../../Assets/trending.png")} style={{ width: width * 0.055, height: height * 0.0275, alignSelf: "center" }} />
            </View>

            <View style={{ width: "88%", height: "100%", justifyContent: "center" }} >
              <Text style={{ fontSize: width * 0.044, fontFamily: "Roboto-Bold", color: "black", fontWeight: "bold" }} >Brands</Text>
            </View>

          </View>
          : null}
        {hidebrand == false ?
          <View style={{ width: "100%", height: "auto", backgroundColor: "white", marginTop: "2.5%", alignItems: "center", marginBottom: "2.5%", }} >
            <SearchProducts dataParentToChild={slicedArray} />
          </View>
          : null} */}

        {!loadersts ?
          <View style={nodata == true && hidebrand == true ? style.searchdata : hidebrand == true && nodata == false ? (cart_length > 0 ? style.searchdata1 : style.searchdataempty) : hidebrand == false && nodata == false ? (cart_length > 0 ? style.searchdata2 : style.searchdataempty) : style.searchdata3} >
            {seaching ?
              <SearchProducts1 logincall={() => logincall()} dataParentToChild={{ data: seaching, key: "seaching" }} />
              : null}
            {nodata == true ?
              <>
                {/* < View style={{ backgroundColor: "red", width: "100%", alignItems: "center", }} > */}
                <Image source={require('../../Assets/cloud.png')} style={{ width: 100, height: 100, alignSelf: "center" }} />
                <Text style={{ fontSize: 20, textAlign: 'center', color: '#366ebe', marginTop: 30, marginLeft: 10 }}>No Products found</Text>
              </>
              //  </View>
              : null}

          </View>
          : <ActivityIndicator color={"black"} />}



        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}

        >

          <View onStartShouldSetResponder={() => onspeechStop()} style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)", justifyContent: "center", alignItems: "center" }} >

            <Card style={style.container1} >
              <Text style={{ fontSize: width * 0.070, fontFamily: "Roboto-Medium", color: "#646464", marginTop: "4%" }} >Google</Text>
              {error == false ?
                <View style={{ marginTop: "10%", justifyContent: "center", alignItems: "center", width: "19%", height: 75, backgroundColor: "#1a73e9", borderRadius: width * 0.10 }}>
                  <Image source={require("../../Assets/wmic.png")} style={{ width: width * 0.060, height: height * 0.035, alignSelf: "center" }} />

                </View>
                :
                <View style={{ borderWidth: 8, borderColor: "red", marginTop: "10%", justifyContent: "center", alignItems: "center", width: "19%", height: 75, backgroundColor: "white", borderRadius: width * 0.20 }}>
                  <Image source={require("../../Assets/bmic.png")} style={{ width: width * 0.060, height: height * 0.035, alignSelf: "center" }} />

                </View>
              }
              {error == "" ?
                <View>
                  {results ?
                    <Text style={{ fontSize: width * 0.055, fontFamily: "Roboto-Medium", color: "#646464", marginTop: "4%", textAlign: "center" }} >{results}</Text>
                    : null
                  }
                  {Google == false ?
                    <Text style={{ fontSize: width * 0.055, fontFamily: "Roboto-Medium", color: "#646464", marginTop: 5 }} >Speak now</Text>
                    : null}
                </View>

                :
                <Text style={{ fontSize: width * 0.048, fontFamily: "Roboto-Medium", color: "#646464", marginTop: "4%" }} >Didn't catch that, Try speaking again.</Text>

              }
              {error ?
                <TouchableOpacity onPress={() => ClickMike()} style={{ position: "absolute", bottom: "20%", width: width * 0.3, height: height * 0.040, justifyContent: "center", alignItems: "center", borderWidth: 1, borderColor: "grey", borderRadius: width * 0.010, }}>
                  <Text style={{ fontFamily: "Roboto-Medium", fontWeight: "600", fontSize: width * 0.04, color: "#277fed" }} >Try Again</Text>
                </TouchableOpacity>
                : null}
              <Text style={{ position: "absolute", bottom: "5%", fontSize: width * 0.035, fontFamily: "Roboto-Medium", color: "#646464", marginTop: "4%" }} >English(india)</Text>



            </Card>

          </View>

        </Modal>

        <Productdetail />
      </ScrollView>
      {/* </View> */}
      {cart_length > 0 ?

        <Carthelp cartcall={() => cartfn()} />
        : null}

    </SafeAreaView >



  )
}