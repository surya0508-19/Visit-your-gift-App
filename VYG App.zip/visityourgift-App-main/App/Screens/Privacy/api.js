import { URL_POLICY } from '../../Constants'
import axios from 'axios';



export const get_terms = async () => {

    try {
        const getterms = await axios({
            method: "get",
            url: `${URL_POLICY}`,

        })

     
        console.log("getterms.data====>", getterms.data)

        return getterms.data.privacy_policy;

    }

    catch (error) {
    console.log("error====>", error)
    console.log("400", error.response.data)

}
}

