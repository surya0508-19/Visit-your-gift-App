import * as React from 'react';
import {NavigationContainer, useRoute} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import login from './Auth/Login';
import Splash_screen from './Splashscreen';
import Otp from './Auth/Otp'
import Sidemenu from '../Navigator/Sidemenu';
import Forgotpass from './Auth/Forgot';
import Imagegallery from './Imagegallery';
import Wishlist from './Wishlist';
import test from '../Components/test';
import Productscategory from './Productscategory/inde';
import Cart from './Cart';
import Myorders from './Myorders';
import Orderdetails from './Orderdetails';
import Store from './Store';
import Allstores from './Allstores';
import Confirmorder from './Confirmorder.js';
import MyAccount from './MyAccount';
import Settings from './Settings';
import Terms from './Terms';
import Faq from './Faq';
import AboutApp from './AboutApp';
import Coupons from './Coupons';
import SearchPage from './SearchPage';
import Address from './Address';
import Payment from './Payment';
import Addaddress from './Addaddress';
import Buyagain from './Buyagain';
import Checkout from './Checkout';
import PaypalWebview from './PaypalWebview';
import PaypalWebview1 from './PaypalWebview1';
import Changepassword from './Changepassword';
import Notification from './Notification';

import Privacy from './Privacy';
import InviteFriends from './InviteFriends/index.js';
import SuperCoins from './SuperCoins/index.js';



const Stack = createStackNavigator();

function Screens(props) {
    return( 
    <NavigationContainer>
      <Stack.Navigator  initialRouteName='Splash_screen' >

      <Stack.Screen name="Privacy" component={Privacy} options={{headerShown:false}}  />

      <Stack.Screen name="Checkout" component={Checkout} options={{headerShown:false}}  />
      <Stack.Screen name="Notification" component={Notification} options={{headerShown:false}}  />

      <Stack.Screen name="Changepassword" component={Changepassword} options={{headerShown:false}}  />
      <Stack.Screen name="PaypalWebview" component={PaypalWebview} options={{headerShown:false}}  />
      <Stack.Screen name="PaypalWebview1" component={PaypalWebview1} options={{headerShown:false}}  />
      <Stack.Screen name="Payment" component={Payment} options={{headerShown:false}}  />
      <Stack.Screen name="Productscategory" component={Productscategory} options={{headerShown:false}}  />
      <Stack.Screen name="login" component={login} options={{headerShown:false}}  />
      <Stack.Screen name="Buyagain" component={Buyagain} options={{headerShown:false}}  />
      <Stack.Screen name="Forgotpass" component={Forgotpass} options={{headerShown:false}}  />
      <Stack.Screen name="Splash_screen" component={Splash_screen} options={{headerShown:false}}  />
      <Stack.Screen name="SearchPage" component={SearchPage} options={{headerShown:false}}  />
      <Stack.Screen name="Otp" component={Otp} options={{headerShown:false}}  />
      <Stack.Screen name="Sidemenu" component={Sidemenu} options={{headerShown:false}}  />
      <Stack.Screen name="Imagegallery" component={Imagegallery} options={{headerShown:false}}  />
      <Stack.Screen name="Wishlist" component={Wishlist} options={{headerShown:false}}  />
      <Stack.Screen name="Myorders" component={Myorders} options={{headerShown:false}}  />
      <Stack.Screen name="Orderdetails" component={Orderdetails} options={{headerShown:false}}  />
      <Stack.Screen name="Cart" component={Cart} options={{headerShown:false}}  />
      <Stack.Screen name="Store" component={Store} options={{headerShown:false}}  />
      <Stack.Screen name="Allstores" component={Allstores} options={{headerShown:false}}  />
      <Stack.Screen name="Confirmorder" component={Confirmorder} options={{headerShown:false}}  />
      <Stack.Screen name="MyAccount" component={MyAccount} options={{headerShown:false}}  />
      <Stack.Screen name="Settings" component={Settings} options={{headerShown:false}}  />
      <Stack.Screen name="Terms" component={Terms} options={{headerShown:false}}  />
      <Stack.Screen name="Faq" component={Faq} options={{headerShown:false}}  />
      <Stack.Screen name="AboutApp" component={AboutApp} options={{headerShown:false}}  />
      <Stack.Screen name="Coupons" component={Coupons} options={{headerShown:false}}  />
      <Stack.Screen name="Address" component={Address} options={{headerShown:false}}  />
      <Stack.Screen name="Addaddress" component={Addaddress} options={{headerShown:false}}  />


      <Stack.Screen name="InviteFriends" component={InviteFriends} options={{headerShown:false}}  />
      <Stack.Screen name="SuperCoins" component={SuperCoins} options={{headerShown:false}}  />


      </Stack.Navigator>

    </NavigationContainer>
    )
}
export default Screens;