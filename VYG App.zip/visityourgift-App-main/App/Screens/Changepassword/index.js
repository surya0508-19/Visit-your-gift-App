import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, TextInput, KeyboardAvoidingView, SafeAreaView, ScrollView, ActivityIndicator } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-async-storage/async-storage';

import styles from './style';
import { useDispatch, useSelector } from 'react-redux';
import { addaddress, addressSelector, editaddress, updateaddress, updateerr } from '../../Slices/address';
import { authSelector } from '../../Slices/auth';
import { fetchdeivery } from '../../Slices/deliverycharge';
import { changepass } from '../MyAccount/api';
// import { SafeAreaView } from 'react-native-safe-area-context';


const Changepasswords = (props, navigation) => {

    const dispatch = useDispatch()
    const { err, add_status } = useSelector(addressSelector)
    const { token } = useSelector(authSelector)
    const { width, height } = Dimensions.get("window")
    const [loader, setloader] = useState(false)

    // useEffect(() => {
    //     setTitle(props.route.params.key)
    // },[])


    const [active, setActive] = useState({

        current: "",
        new: "",
        confirm: ""

    })

    const [change, setChange] = useState({
        current: false,
        new: false,
        confirm: false

    })

    const Passwordvalidate = async (value, key) => {

        switch (key) {
            case "current":
                var data1 = { ...active }
                data1.current = value
                setActive(data1)
                break;

            case "new":
                var data1 = { ...active }
                data1.new = value
                setActive(data1)
                break;

            case "confirm":
                var data1 = { ...active }
                data1.confirm = value
                setActive(data1)
                break;
        }
    }

    const changevalidate = async (key) => {
        switch (key) {
            case "current":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = true
                data.new = false
                data.confirm = false
                setChange(data)
                break;
            case "new":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = false
                data.new = true
                data.confirm = false
                setChange(data)
                break;

            case "confirm":
                var data = { ...change }
                data.fname = false
                data.lname = false
                data.mobile = false
                data.current = false
                data.new = false
                data.confirm = true
                setChange(data)
                break;



        }
    }
    const submit = async () => {


        if (active.current == "") {
            Toast.show("Enter Current Password ", Toast.SHORT);
        }
        else if (active.new == "") {
            Toast.show("Enter New Password ", Toast.SHORT);
        }
        else if (active.confirm == "") {
            Toast.show("Enter Confirm Password ", Toast.SHORT);
        }
        else if (!(active.new == active.confirm)) {
            Toast.show("Please Check New Password and Confirm Password", Toast.SHORT);
        }
        else {
            var data = {
                "current_password": active.current,
                "new_password": active.confirm,

            }
            setloader(true)
            const gett = await changepass(token, data)


            if (!gett == "error") {
                setloader(false)
                props.navigation.navigate("MyAccount")

                var data1 = { ...active }
                data1.current = ""
                data1.new = ""
                data1.confirm = ""
                setActive(data1)
            }
            else {
                setloader(false)

            }

            console.log("geeeee", gett)
        }
    }

    const goback = () => {


        props.navigation.goBack()

    }


    return (
        <SafeAreaView style={{ flex: 1 }} >

            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}>
                <View style={{ width: "100%", height: 50, backgroundColor: "white", flexDirection: "row", alignItems: "center" }}>
                    <TouchableOpacity onPress={() => goback()} >
                        <Image style={{ width: 20, height: 25, resizeMode: "contain", marginLeft: 15 }} source={require('../../Assets/back.png')} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 18, color: "black", fontWeight: "bold", marginLeft: "5%" }}>Change Password</Text>
                </View>



                <View style={{ width: "100%", height: "94%", }}>

                    <ScrollView>

                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Current Password</Text>



                        <Card style={change.current ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => Passwordvalidate(text, "current")}
                                value={active.current}
                                editable={true}
                                onFocus={() => changevalidate("current")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter Current Password'}

                            />
                        </Card>

                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >New Password</Text>



                        <Card style={change.new ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => Passwordvalidate(text, "new")}
                                value={active.new}
                                editable={true}
                                onFocus={() => changevalidate("new")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter New Password'}


                            />
                        </Card>

                        <Text style={{ marginTop: "5%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Confirm Password</Text>

                        <Card style={change.confirm ? styles.card_container1 : styles.card_container}>

                            <TextInput
                                onChangeText={(text) => Passwordvalidate(text, "confirm")}
                                value={active.confirm}
                                editable={true}
                                onFocus={() => changevalidate("confirm")}
                                style={{ fontFamily: "Roboto-Light", fontSize: width * 0.045, fontWeight: "600", width: "99%", color: "black", marginLeft: "4%" }}
                                placeholder={'Enter Confirm Password'}
                            />
                        </Card>







                        <TouchableOpacity onPress={() => submit()} style={{ marginTop: "10%", }} >
                            <Card style={{ width: '50%', alignSelf: 'center', height: 45, borderRadius: 7, overflow: 'hidden', backgroundColor: '#00a4ff', alignItems: 'center', justifyContent: "center" }}>
                                {loader ?
                                    <ActivityIndicator color={"white"} /> :
                                    <Text style={{ fontSize: 18, color: 'white', fontWeight: 'bold', textAlign: "center", marginBottom: "5%", marginTop: "5%" }}>Submit</Text>}
                            </Card>
                        </TouchableOpacity>

                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    )

}




export default Changepasswords;