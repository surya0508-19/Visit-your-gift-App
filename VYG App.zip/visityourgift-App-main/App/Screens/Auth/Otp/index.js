import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity,Image ,Dimensions, ImageBackground,StatusBar} from 'react-native';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../../Statusbar';
import styles from './style';
export default function Otp ({navigation}) {
    
const {width,height}=Dimensions.get("window")
// const[data,setData] =useState("white")
const data="white"
// console.log("datattataatat",data)
return(
<View style={styles.container}>

   <Statusbar dataParentToChild={data} />
   {/* <View style={{width:"100%",height:height*0.03,backgroundColor:"white"}} >

</View> */}
            <View style={styles.header} >
            <TouchableOpacity style={{marginLeft:"5%"}}  onPress={() => navigation.navigate('Sidemenu')} >
            <Image style={styles.back} source={require("../../../Assets/back.png")} />
            </TouchableOpacity>
            <Text style={styles.text1} >OTP verification</Text>
            </View>
            <Text style={styles.text2} >We've sent a verification code to</Text>
            <Text style={styles.text3} >+91 9750369324</Text>

            <View style={styles.otp_container} >
              <View style={styles.box_container} >
                
              </View>
              <View style={styles.box_container1} >
                
                </View>
                <View style={styles.box_container1} >
                
                </View>
                <View style={styles.box_container1} >
                
                </View>

              
            </View>
            <Text style={styles.text4} >Resend OTP in 28</Text>
</View>
)
}