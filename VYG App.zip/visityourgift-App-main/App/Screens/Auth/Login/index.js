import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, StatusBar, TextInput, ScrollView, KeyboardAvoidingView, ActivityIndicator } from 'react-native';
import axios from 'axios'
import AsyncStorage from '@react-native-async-storage/async-storage';

import styles from './style';
import LinearGradient from 'react-native-linear-gradient';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../../Statusbar';
import CheckBox from '@react-native-community/checkbox';
const { width, height } = Dimensions.get("window")
import Toast from 'react-native-simple-toast';
// import { SafeAreaView } from 'react-native-safe-area-context';
import { useDispatch, useSelector } from 'react-redux';
import { authSelector, getloginerror, getloginresponse, getsignuperror, getsignupresponse, signup, userlogin } from '../../../Slices/auth';
import messaging from '@react-native-firebase/messaging';
import { URL_DELIVERYCHARGE, URL_FCM_TOKEN } from '../../../Constants';
import PushNotification from 'react-native-push-notification';


const login = (props, { navigation }) => {

  const dispatch = useDispatch()

  const { loginsuccess, signupsuccess, signuperror, loginerror, error, token } = useSelector(authSelector)

  const [loder, setLoader] = useState(false)
  const [check, setcheck] = useState(false)
  const [Logins, setLogins] = useState({
    login: "",
    password: "",
    fname: "",
    lname: "",
    number: ""
  })

  const [show, setShow] = useState({
    login: true,
    signup: false
  })
  const [pass, setPass] = useState({
    password: false,
    confirmpass: false
  })
  const [auth, setAuth] = useState({
    login: false,
    signup: false
  })

  // const [signupmobile,setSignupMobile]=useState(false)
  const { width, height } = Dimensions.get("window")
  useEffect(() => {
    if (loginsuccess) {
      setLoader(false)
      FcmTokenget()
      dispatch(getloginresponse(false))
      Toast.show("Login Successfully", Toast.SHORT);

      props.navigation.navigate("Sidemenu")
    }
  }, [loginsuccess])

  useEffect(() => {
    if (loginerror) {
      setLoader(false)
      Toast.show(error, Toast.SHORT);
      var data = {
        err: "",
        status: false
      }
      dispatch(getloginerror(data))
    }
  }, [loginerror])


  useEffect(() => {
    if (signuperror) {
      setLoader(false)

      dispatch(getsignuperror(false))
    }
  }, [signuperror])

  useEffect(() => {
    if (signupsuccess) {
      dispatch(getsignupresponse(false))
      var data = { ...show }
      data.login = true
      data.signup = false
      setShow(data)
      var data1 = { ...auth }
      data1.login = false
      data1.signup = false
      setAuth(data1)
      setLoader(false)
      Toast.show("Signup Successfully", Toast.SHORT);


    }
  }, [signupsuccess])


  const Onchanges = (type, value) => {

    if (type == "email") {

      var datass = { ...Logins }
      datass.login = value
      setLogins(datass)

    }
    else if (type == "pass") {

      var datass = { ...Logins }
      datass.password = value
      setLogins(datass)
    }
    else if (type == "fname") {

      var datasss = { ...Logins }
      datasss.fname = value
      setLogins(datasss)
    }
    else if (type == "lname") {

      var datasss = { ...Logins }
      datasss.lname = value
      setLogins(datasss)
    }
    else if (type == "num") {
      var datasss = { ...Logins }
      datasss.number = value
      setLogins(datasss)
    }
  }


  const FcmTokenget = async () => {


    const tok = AsyncStorage.getItem("Token")





    PushNotification.configure({
      onRegister: async (token) => {
        console.log('uuuuuuuuuuuuuuuu', token.token,tok)

        var data1 ={
          "firebase_token": token.token
        }




        try {
          const response = await axios({
            method: "post",
            url: `${URL_FCM_TOKEN}`,
            headers: {
              Authorization: tok._z
            },
            data: data1
          })


          console.log("ress", response.data)



        }
        catch (err) {
          console.log("errorrrrr", err)

        }

      }
    })



  }
  const Login = async () => {

    if (show.login == true) {
      const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      if (Logins.login == "") {
        Toast.show("Please Enter Email", Toast.SHORT);
      }
      else if (!(reg.test(Logins.login) === true)) {
        Toast.show("Please Enter valid email", Toast.SHORT);
      }
      else if (Logins.password == "") {
        Toast.show("Please Enter Password", Toast.SHORT);
      }
      else if (Logins.password.length < 8) {
        Toast.show("The password must be at least 8 characters", Toast.SHORT);
      }
      else {
        setLoader(true)
        var data = {
          "email": Logins.login,
          "password": Logins.password
        }

        dispatch(userlogin(data))
        // FcmTokenget()
      }
    }
    else {
      const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      if (Logins.login == "") {
        Toast.show("Please Enter Email", Toast.SHORT);
      }
      else if (!(reg.test(Logins.login) === true)) {
        Toast.show("Please Enter valid email", Toast.SHORT);
      }
      else if (Logins.password == "") {
        Toast.show("Please Enter Password", Toast.SHORT);
      }
      else if (Logins.password.length < 8) {
        Toast.show("The password must be at least 8 characters", Toast.SHORT);
      }

      else if (Logins.fname == "") {
        Toast.show("Please Enter First Name", Toast.SHORT);
      }
      else if (Logins.number == "") {
        Toast.show("Please Enter Number", Toast.SHORT);
      }
      else if (Logins.number.length < 10) {
        Toast.show("Please Enter 10 digit Number", Toast.SHORT);
      }
      else if (check == "") {
        Toast.show("Please Agree Terms & Conditions", Toast.SHORT);
      }
      else {
        setLoader(true)
        var data = {
          "user_type": "retail",
          "email": Logins.login,
          "fname": Logins.fname,
          "lname": Logins.lname,
          "mobile": Logins.number,
          "password": Logins.password,
          "terms_and_conditions":check,
          "captcha":true
        }


        dispatch(signup(data))

      }


    }

  }





  const data = "white"

  const Changeshow = (value) => {


    var datass = { ...Logins }
    datass.login = ''
    datass.password = ''
    datass.fname = ''
    datass.lname = ''
    datass.number = ''
    setLogins(datass)

    if (value == "signup") {
      var data = { ...show }
      data.signup = true
      data.login = false
      setShow(data)

      var data1 = { ...auth }
      data1.login = false
      data1.signup = false
      setAuth(data1)

    }
    else {
      var data = { ...show }
      data.login = true
      data.signup = false
      setShow(data)

      var data1 = { ...auth }
      data1.login = false
      data1.signup = false
      setAuth(data1)
    }

  }

  const validatepass = (value) => {

    if (value == "confirmpass") {
      var data = { ...pass }
      if (data.confirmpass) {
        data.confirmpass = false
        setPass(data)
      }
      else {
        data.confirmpass = true
        setPass(data)

      }
    }
    else {

      var data = { ...pass }
      if (data.password) {
        data.password = false
        setPass(data)

      }
      else {
        data.password = true
        setPass(data)

      }

    }

  }

  const validateauth = (value) => {
    setActive('')
    switch (value) {
      case 'signup':
        if (auth.signup) {
          var data = { ...auth }
          data.signup = false
          setAuth(data)
        }
        else {
          var data = { ...auth }
          data.signup = true
          setAuth(data)
        }
        break
      case 'login':
        if (auth.login) {
          var data = { ...auth }
          data.login = false
          setAuth(data)
        }
        else {
          var data = { ...auth }
          data.login = true
          setAuth(data)
        }
    }

  }





  return (

    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <SafeAreaView style={styles.container} >

        <ScrollView>
          <Statusbar dataParentToChild={data} />
          <View style={styles.grocery_container} >
            <View style={styles.grocery_items_container1} >
              {/* <Image style={styles.grocery_images} source={require("../../../Assets/brocoli.jpeg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/nuts.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/eggs.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/chips.jpg")} /> */}



              {/* <Text style={{ color: "white", textAlign: "center", fontSize: width * 0.08, fontFamily: "Roboto-Medium" }} >Grocery On Mobile</Text> */}

              <Image style={{ width: "80%", height: "85%", alignSelf: "center", resizeMode: "contain",  }} source={require("../../../Assets/visit-your-gift.png")} />

            </View>

            <View style={styles.grocery_items_container} >
              <Image style={styles.grocery_images} source={require("../../../Assets/img1.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/img8.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/img2.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/img3.jpg")} />
            </View>

            <View style={styles.grocery_items_container} >
              <Image style={styles.grocery_images} source={require("../../../Assets/img4.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/img5.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/img6.jpg")} />
              <Image style={styles.grocery_images} source={require("../../../Assets/img7.jpg")} />
            </View>

            {/* <TouchableOpacity style={styles.back_container} >
            <Image style={styles.back_icon} source={require("../../../Assets/back.png")} />
          </TouchableOpacity> */}
          </View>


          <LinearGradient style={styles.linear_gradiant_conatiner} colors={['#00a4ff', '#4dbfff', '#c4eaff']} />
          <LinearGradient style={styles.linear_gradiant_conatiner1} colors={['#c4eaff', '#ffffff']} />
          {/* <LinearGradient style={styles.linear_gradiant_conatiner} colors={['#f7cb48', '#fef290', '#fff5b0']} />
            <LinearGradient style={styles.linear_gradiant_conatiner1} colors={['#fff5b0', '#fdfef9', '#ffffff']} /> */}


          <View style={show.signup ? styles.bottom_container : styles.bottom_container1} >

            <Card style={{ width: width * 0.95, height: height * 0.075, alignSelf: "center", alignItems: "center", flexDirection: "row", justifyContent: "space-around", backgroundColor: "#00a4ff" }} >
              {show.login ?
                <Card style={{ width: "45%", height: '85%', borderRadius: width * 0.035, justifyContent: "center", backgroundColor: "white", borderRadius: width * 0.025 }} >
                  <Text style={{ color: "black", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >Login</Text>
                </Card> :

                <TouchableOpacity onPress={() => Changeshow("login")} style={{ width: "45%" }} >
                  <Text style={{ color: "white", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >Login</Text>
                </TouchableOpacity>}

              {show.signup ?
                <Card style={{ width: "45%", height: '85%', borderRadius: width * 0.035, justifyContent: "center", backgroundColor: "white", borderRadius: width * 0.025 }} >
                  <Text style={{ color: "black", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >Signup</Text>
                </Card> :
                <TouchableOpacity onPress={() => Changeshow("signup")} style={{ width: "45%" }} >
                  <Text style={{ color: "white", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >Signup</Text>
                </TouchableOpacity>}
            </Card>
            {(auth.signup || auth.login) ?
              <Text style={styles.text1} >Mobile number </Text> :
              <Text style={styles.text1} >Email </Text>
            }
            <Card style={styles.login} >

              <TextInput
                onChangeText={(text) => Onchanges("email", text)}
                value={Logins.login}
                style={{ fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%", width: '100%' }}
                placeholder={(auth.signup || auth.login) ? 'Enter the mobile number' : 'Enter the email'}
              />

            </Card>

            <Text style={styles.text1} >Password</Text>
            <Card style={styles.login} >
              <View style={{ width: "85%", height: "100%", justifyContent: "center" }} >
                <TextInput
                  secureTextEntry={!pass.password}
                  value={Logins.password}
                  // keyboardType="numeric"
                  onChangeText={(text) => Onchanges("pass", text)}
                  style={{ fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%" }}
                  placeholder='Enter password' />
              </View>
              <TouchableOpacity onPress={() => validatepass()} style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                <Image source={pass.password ? require("../../../Assets/eye.png") : require("../../../Assets/eye1.png")} style={{ width: width * 0.06, height: height * 0.03, alignSelf: "center" }} />
              </TouchableOpacity>

            </Card>
            {show.signup ?
              <>
                <Text style={styles.text1} >First Name</Text>
                <Card style={styles.login} >
                  <View style={{ width: "85%", height: "100%", justifyContent: "center" }} >
                    <TextInput
                      value={Logins.fname}
                      onChangeText={(text) => Onchanges("fname", text)}
                      style={{ fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%" }}
                      placeholder='Enter First Name' />
                  </View>
                  {/* <TouchableOpacity onPress={() => validatepass("confirmpass")} style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                  <Image source={pass.confirmpass ? require("../../../Assets/eye.png") : require("../../../Assets/eye1.png")} style={{ width: width * 0.06, height: height * 0.03, alignSelf: "center" }} />
                </TouchableOpacity> */}


                </Card>

                <Text style={styles.text1} >Last Name</Text>
                <Card style={styles.login} >
                  <View style={{ width: "85%", height: "100%", justifyContent: "center" }} >
                    <TextInput
                      value={Logins.lname}
                      onChangeText={(text) => Onchanges("lname", text)}
                      style={{ fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%" }}
                      placeholder='Enter Last Name' />
                  </View>
                  {/* <TouchableOpacity onPress={() => validatepass("confirmpass")} style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                  <Image source={pass.confirmpass ? require("../../../Assets/eye.png") : require("../../../Assets/eye1.png")} style={{ width: width * 0.06, height: height * 0.03, alignSelf: "center" }} />
                </TouchableOpacity> */}


                </Card>

                <Text style={styles.text1} >Contact Number</Text>
                <Card style={styles.login} >
                  <View style={{ width: "85%", height: "100%", justifyContent: "center" }} >
                    <TextInput
                      value={Logins.number}
                      keyboardType="numeric"
                      maxLength={10}
                      onChangeText={(text) => Onchanges("num", text)}
                      style={{ fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%" }}
                      placeholder='Enter Contact Number' />
                  </View>
                  {/* <TouchableOpacity onPress={() => validatepass("confirmpass")} style={{ width: "15%", height: "100%", justifyContent: "center" }} >
                  <Image source={pass.confirmpass ? require("../../../Assets/eye.png") : require("../../../Assets/eye1.png")} style={{ width: width * 0.06, height: height * 0.03, alignSelf: "center" }} />
                </TouchableOpacity> */}


                </Card>

              </> : null}

            {show.login ?
              <View style={{ backgroundColor: "white", height: "8%", flexDirection: "row", marginTop: "2.5%", width: "37%", alignSelf: "flex-end" }} >
                {/* <TouchableOpacity onPress={() => validateauth('login')} >
                {auth.login ?
                  <Text style={{ alignSelf: "flex-end", fontSize: width * 0.04, textDecorationLine: "underline" }} >Login with email</Text> :
                  <Text style={{ alignSelf: "flex-end", fontSize: width * 0.04, textDecorationLine: "underline" }} >Login with Mobile no</Text>}
              </TouchableOpacity> */}

                <TouchableOpacity onPress={() => props.navigation.navigate("Forgotpass")} >
                  <Text style={{ fontWeight: 'bold', fontSize: width * 0.04, textDecorationLine: "underline", color: "#00a4ff" }} >Forgot password</Text>
                </TouchableOpacity>
              </View> : null}
            {!show.login ?
              <View style={{ flexDirection: 'row', alignSelf: 'center', marginTop: 16, width: "90%",  }}>
                <CheckBox style={{ width: 20, height: 20, marginRight: 10 }}
                  disabled={false} boxType='square'
                  value={check}
                  onValueChange={(newValue) => setcheck(newValue)}
                />
                <Text style={{ fontSize: 16.5, color: 'black', marginBottom: 'auto', textAlign: 'center', }}>I agree to the </Text>
                <TouchableOpacity onPress={() => props.navigation.navigate('Terms')} style={{ marginLeft: 5 }}>
                  <Text style={{ fontSize: 16, color: '#00a4ff', fontWeight: 'bold', marginTop: 'auto', marginBottom: 'auto', borderBottomWidth: 2, borderBottomColor: '#00a4ff', width: "100%" }}>Terms and conditions</Text>
                </TouchableOpacity>

              </View>
              : null}

            <TouchableOpacity onPress={() => Login()} style={show.login ? styles.button_container : styles.button_container1} >
              {!loder ?
                <Text style={styles.continue_text} >Continue</Text> :
                <ActivityIndicator color={'white'} />}
            </TouchableOpacity>





          </View>
        </ScrollView>


      </SafeAreaView>
    </KeyboardAvoidingView>


  )
}

export default login;