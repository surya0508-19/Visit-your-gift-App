import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, ActivityIndicator } from 'react-native';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';
import { Card } from 'react-native-shadow-cards';
import Helper from '../../../Components/helper';
import styles from './style';
import Statusbar from '../../Statusbar';
import { fetchingforgetpass } from './api';
import Toast from 'react-native-simple-toast';
import AsyncStorage from '@react-native-async-storage/async-storage';
const { width, height } = Dimensions.get("window")
import { useDispatch, useSelector } from 'react-redux';
import { cartSelector, fetchcart } from '../../Slices/cart';
import { authSelector } from '../../../Slices/auth';

export default function Forgotpass({ navigation },) {


    const [loder, setLoader] = useState(false)

    const [auth, setAuth] = useState(false)
    const [value, setValue] = useState('')
    const validate = (value) => {
        if (!value) {
            setAuth(true)
            setValue('')
        }
        else {
            setAuth(false)
            setValue('')
        }
    }
    const data = "white"

    const Confirm = async () => {




        if (value == "") {

            Toast.show("Please Enter Email", Toast.SHORT);

        } else {
            setLoader(true)
            const output = await fetchingforgetpass(value,)

            // console.log("vvvv", output.success)
            setLoader(false)
            if (output.success == true) {



                navigation.navigate("login")
            }
        }


    }


    return (
        <SafeAreaView style={{ width: "100%", height: "100%" }} >
            {/* <Helper/> */}
            <Statusbar dataParentToChild={data} />
            <View style={styles.header} >
                <TouchableOpacity style={{ marginLeft: "5%" }} onPress={() => navigation.goBack()} >
                    <Image style={styles.back} source={require("../../../Assets/back.png")} />
                </TouchableOpacity>
                <Text style={styles.text1} >Forgot password</Text>
            </View>

            <Text style={styles.text2} >Email</Text>

            <Card style={styles.login} >

                <TextInput
                    style={{ width: "90%", fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%" }}

                    onChangeText={(text) => setValue(text)}

                    value={value}
                    placeholder={'Enter the email'}
                />
            </Card>




            <TouchableOpacity onPress={() => Confirm()} style={styles.button_container} >
                {!loder ?
                    <Text style={styles.continue_text} >Continue</Text>
                    :
                    <ActivityIndicator color={'white'} />}

            </TouchableOpacity>
        </SafeAreaView>
    )

}