import axios from "axios"
import { URL_FORGET_PASSWORD,URL_FORGET_PASSWORD1 } from "../../../Constants"
import Toast from 'react-native-simple-toast';

export const fetchingforgetpass = async (mail, token) => {

  console.log("mail",mail,token)
  try {
    const response = await axios({
      method: "get",
      url: `${URL_FORGET_PASSWORD}` + mail,

    })
    console.log("response.data",response.data)

    if (response.data.success==true) {

      Toast.show(response.data.message, Toast.SHORT);

      return response.data
    }
  }
  catch (err) {
    console.log("error", err.response.data.message)
    Toast.show(err.response.data.message, Toast.SHORT);

  }
}