
import React, { useState, useEffect, Component } from 'react';
import { View, Text, SafeAreaView, TouchableOpacity,Image,Dimensions, ImageBackground, StatusBar } from 'react-native';
import { useSelector } from 'react-redux';

import { Card } from 'react-native-shadow-cards';
import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { authSelector } from '../../Slices/auth';
import { ordersSelector } from '../../Slices/orders';
import { orderlists } from '../TestData/data';
import styles from './style';


export default function Myorders(props) {
    const { width, height } = Dimensions.get("window")
    const {token} = useSelector(authSelector)
    const data = {
        name:'Your orders',
        search:false
    }
    // useEffect(() => {

    // },[type])
   const[type,setType]=useState("all")
    const orderdetails = async(value) => {
        // console.log("value",value)
        props.navigation.navigate("Orderdetails",{
            order_id:value,
            token:token
        })
    }
    const [show, setShow] = useState({
        login: true,
        signup: false
      })

      const Changeshow = (value) => {
        if (value == "signup") {
          var data = { ...show }
          data.signup = true
          data.login = false
          setShow(data)
          setType("cancel")
        }
        else {
         
          var data = { ...show }
          data.login = true
          data.signup = false
          setShow(data)
          setType("all")
        }
      }
    return (
        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />
           
            <View style={{ width: width, height:"7.5%", alignSelf: "center", alignItems: "center", flexDirection: "row", justifyContent: "space-around",backgroundColor:"#00a4ff"}} >
              {show.login ?
                <Card style={{ width: "45%", height: '85%', borderRadius: width * 0.035, justifyContent: "center", backgroundColor: "white", borderRadius: width * 0.025 }} >
                  <Text style={{ color: "black", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >All orders</Text>
                </Card> :

                <TouchableOpacity onPress={() => Changeshow("login")} style={{ width: "45%" }} >
                  <Text style={{ color: "white", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >All orders</Text>
                </TouchableOpacity>}

              {show.signup ?
                <Card style={{ width: "45%", height: '85%', borderRadius: width * 0.035, justifyContent: "center", backgroundColor: "white", borderRadius: width * 0.025 }} >
                  <Text style={{ color: "black", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >Cancel Orders</Text>
                </Card> :
                <TouchableOpacity onPress={() => Changeshow("signup")} style={{ width: "45%" }} >
                  <Text style={{ color: "white", textAlign: "center", fontSize: width * 0.045, fontFamily: "Roboto-Medium" }} >Cancel Orders</Text>
                </TouchableOpacity>}
            </View>
          
            <View style={{ width: width, height:"83%", marginTop: "2%",marginBottom:"5%" }} >
                <Allorders orderdetailscall={(id) => orderdetails(id)} dataParentToChild={type} />
            </View>
            <View style={{ width: width, height: height * 0.1, marginTop: "2%" }} >
                
            </View>
        </SafeAreaView>
    )
}