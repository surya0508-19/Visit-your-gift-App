import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, Alert, BackHandler, Linking, Modal } from 'react-native';
import Statusbar from '../Statusbar';
import { useDispatch, useSelector } from 'react-redux';
import { retriveaccesstoken } from '../../Slices/auth';
import { fetchprofile, getnotificationlist } from '../../Slices/profile';
import { fetchctopseling, fetchhomedata, fetchrecommended } from '../../Slices/homedata';
import { fetchcart } from '../../Slices/cart';
import { fetchaddress } from '../../Slices/address';
import { fetchtopbrands } from '../../Slices/searchproducts';
import { fetchorders } from '../../Slices/orders';
import { fetchdeivery } from '../../Slices/deliverycharge';
import messaging from '@react-native-firebase/messaging';
import PushNotification from 'react-native-push-notification';

import { Platform } from 'react-native';
import PushNotificationIOS from '@react-native-community/push-notification-ios';

// PushNotification.createChannel({
// channelId: "channel-id", // (required)
// channelName: "My channel", // (required)
// playSound: false, // (optional) default: true
// soundName: "default", // (optional) See `soundName` parameter of `localNotification` function
// importance: 4,// (optional) default: 4. Int value of the Android notification importance vibrate: true, // (optional) default: true. Creates the default vibration patten if true.
// },



// (created) => console.log('createChannel returned ',created) 
// );





export default function Splash_screen(props, { navigation }) {
  const dispatch = useDispatch()



  PushNotification.configure({
    // (optional) Called when Token is generated (iOS and Android)
    onRegister: function (token) {
      console.log("TOKEN:", token);
    },
    // (required) Called when a remote or local notification is opened or received
    onNotification: function (notification) {
      console.log("NOTIFICATION:", notification);
      // process the notification here
      // required on iOS only
      notification.finish(PushNotificationIOS.FetchResult.NoData);
    },
    // Android only
    senderID: "1060263600142",
    // iOS only
    permissions: {
      alert: true,
      badge: true,
      sound: true
    },
    popInitialNotification: true,
    requestPermissions: true
  });







  //   useEffect(() => {
  //   // PushNotification.getChannels (function (channel_ids) {
  //   //console.log(channel_ids); // ['channel_id_1']
  //   const unsubscribe = messaging().onMessage(async (remoteMessage) => {
  //   PushNotification.localNotification({
  //   message: remoteMessage.notification.body,
  //   title: remoteMessage.notification.title,
  //   bigPictureUrl: remoteMessage.notification.android.imageUrl,
  //   smallIcon: remoteMessage.notification.android.imageUrl,
  //   // channelId: remoteMessage.notification.android.channelId,
  //   channelId: true,
  //   vibrate: true,


  // });
  // });
  // return unsubscribe;
  // },[])



  PushNotification.createChannel(
    {
      channelId: "ballons", // (required)
      channelName: "ballons_channel", // (required)
    },
    (created) => console.log(`createChannel returned '${created}'`) // (optional) callback returns whether the channel was created, false means it already existed.
  );


  PushNotification.configure({

    onNotification: function (notification) {
      console.log("foregroundddd", notification)

      if (notification.userInteraction == false) {

        PushNotification.localNotification({
          channelId: "ballons",
          title: notification.title,
          message: notification.message,
          date: new Date(Date.now() + (10 * 1000))
        });

        getlist()



      }
      else {
        props.navigation.navigate("Notification")
      }


      // PushNotification.localNotification({
      //   channelId:"ballons",
      //   title: "jjjjjjj",
      //   message: "gggggggggggg",
      //   date: new Date(Date.now() + (10 * 1000))
      // });





    },



    requestPermissions: true,
  });


  const getlist = async () => {

    var tokenss = await AsyncStorage.getItem('Token')
    dispatch(getnotificationlist(tokenss))

  }






  // messaging().onMessage(async (remoteMessage) => {
  //    console.log('Received a message in the foreground', remoteMessage);

  //   // if (Platform.OS === 'ios') {
  //   //   // Trigger local notification for iOS
  //   //   PushNotificationIOS.presentLocalNotification({
  //   //     alertTitle: remoteMessage.notification.title,
  //   //     alertBody: remoteMessage.notification.body,
  //   //     userInfo: remoteMessage.data,
  //   //   });
  //   // }
  // });
  // messaging().onMessage(remoteMessage => {
  //   console.log(' foreground', remoteMessage);

  //   if (Platform.OS === 'ios') {
  //         // Trigger local notification for iOS
  //         PushNotificationIOS.presentLocalNotification({
  //           alertTitle: remoteMessage.title,
  //           alertBody: remoteMessage.body,
  //           // soundName:true
  //           // userInfo: remoteMessage.data,
  //         });
  //       }

  // });

  // const checkToken = async () => {
  //   const fcmToken = await messaging().getToken();
  //   if (fcmToken) {
  //   console.log("fcmToken",fcmToken);
  //   // Alert.alert(fcmToken);
  //   }


  // }




  useEffect(() => {
    checkuser()
  }, [])

  const checkuser = async () => {
    const token = await AsyncStorage.getItem("Token")
    if (token) {
      dispatch(retriveaccesstoken(token))
      dispatch(fetchprofile(token))
      dispatch(fetchcart(token))
      dispatch(fetchaddress(token))
      dispatch(fetchhomedata())
      dispatch(fetchctopseling())
      dispatch(fetchrecommended())
      dispatch(getnotificationlist(token))
      dispatch(fetchtopbrands())
      dispatch(fetchorders(token))
      dispatch(fetchdeivery(token))


      setTimeout(() => {
        props.navigation.navigate("Sidemenu")
      }, 1800)

    }
    else {
      dispatch(fetchhomedata())
      dispatch(fetchctopseling())
      dispatch(fetchrecommended())
      dispatch(fetchtopbrands())
      dispatch(retriveaccesstoken(''))
      setTimeout(() => {
        props.navigation.navigate("Sidemenu")
      }, 500)
    }

  }

  const data = "white"




  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "white", justifyContent: "center" }} >
      <Statusbar dataParentToChild={data} />
      {/* <Image source={require("../../Assets/launch_screen.png")} style={{ width: "100%", height: "100%", alignSelf: "center" }} /> */}




    
    </SafeAreaView>
  )
}