
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, Linking } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';


export default function AboutApp(props) {
    const { width, height } = Dimensions.get("window")
   
    const data = {
        name:'About App',
        search:false
    }
    return (
        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />

            <View style={{ width: width, height: height * 0.935, backgroundColor: "white", }}>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "black", width: "95%", marginLeft: "3%", marginTop: "2%" }} >About Us v14.36.1.0</Text>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", width: "95%", marginLeft: "3%", marginTop: "2%" }} >       Blinkit is India's most beloved online grocery shopping platform. Our app is changing the way customers approach their daily essentials. You can now shop online for groceries, fresh fruits and vegetables procured daily, dairy & bakery, beauty & wellness, personal care, household care, diapers & baby care, pet care, meats and seafood as well as the latest products from leading brands like Cadbury, ITC, Colgate-Palmolive, PepsiCo, Aashirvaad, Saffola, Fortune, Nestle, Amul, Dabur, and many more. Imagine if you could get anything delivered to you in minutes. Milk for your morning chai. The perfect shade of lipstick for tonight's party. Even an iPhone.

                </Text>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", width: "95%", marginLeft: "3%", marginTop: "2%" }} >   Our superfast delivery service aims to help consumers in India save time and fulfill their needs in a way that is frictionless. We will make healthy, high-quality and life-improving products available to everyone instantly so that people can have time for the things that matter to them.</Text>

                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", width: "95%", marginLeft: "3%", marginTop: "2%" }} >    'Blinkit' is owned & managed by 'Blink Commerce Private Limited' (formerly known as Grofers India Private Limited) and is not related, linked or interconnected in whatsoever manner or nature, to 'GROFFR.COM' which is a real estate services business operated by 'Redstone Consultancy Services Private Limited'.</Text>

            </View>

        </SafeAreaView>
    )
}