import { width } from 'deprecated-react-native-prop-types/DeprecatedImagePropType';
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ActivityIndicator, StatusBar, SafeAreaView } from 'react-native';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import Helperhome from '../../Components/helperhome';
import Buyagainlist from '../../Components/Buyagainlist';
import Header from '../../Navigator/Header';
import { fetchbuyagain } from './api';
import { authSelector } from '../../Slices/auth';
import { useSelector, useDispatch } from 'react-redux';
import { cartSelector, fetchcart } from '../../Slices/cart';
import { buyagainSlector, fetchbuyproducts } from '../../Slices/buyagainlist';
import Productdetail from '../../Components/productdetail';
import Carthelp from '../../Components/carthelp';


export default function Buyagain(props) {
    const { width, height } = Dimensions.get("window")

    const data = {
        name: 'Buy Again',
        search: false
    }
    const [buyagainlist, setBuyagainlist] = useState(false)

    const { token } = useSelector(authSelector);
    const { cart_length, cart_products } = useSelector(cartSelector);

    const { buyagain, loadersts } = useSelector(buyagainSlector)


    const cartfn = () => {
        dispatch(fetchcart(token))
        props.navigation.navigate("Cart")
    }

    const dispatch = useDispatch()

    // console.log("ddddd", buyagain)
    useEffect(() => {

        GetBuyagainlist()
    }, [])


    const GetBuyagainlist = async () => {

        // const getlist = await fetchbuyagain(token,cart_products)
        dispatch(fetchbuyproducts(token, cart_products,))
        // console.log("wwwwwwwww", getlist)

    }
    const detail = async (id) => {

        const token = await AsyncStorage.getItem("TOKEN");
        const details = await get_details(token, id)
        console.log("wwwwwwwww", details.data123)
        props.change_product_data(details.detail.product_details)
        props.change_product_datails(details.data123)
        props.change_modal(true)

        console.log("modalssmodalss", props.modalss)
    }

    // const { cart_length, cart_total, cart_products } = useSelector(cartSelector);



    return (
        <SafeAreaView style={styles.container}>
            {/* <Helperhome /> */}
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />
            <View style={cart_length ? { width: width, height: height * 0.82, marginTop: "2%", marginBottom: "2%" } : { width: width, height: height * 0.92, marginTop: "2%" }} >
                {buyagain.length > 0 ?
                    <>
                        {loadersts ?

                            <ActivityIndicator color={"black"} />

                            :
                            <Buyagainlist dataParentToChild={{ data: buyagain }} />




                        }
                    </>
                    :
                    <View style={{ width: "100%", height: "90%", alignItems: "center", justifyContent: "center" }} >
                        <Image source={require('../../Assets/cloud.png')} style={{ width: 100, height: 100, alignSelf: "center" }} />
                        <Text style={{ fontSize: 20, textAlign: 'center', color: '#366ebe', marginTop: 30, marginLeft: 10 }}>No Products found</Text>
                    </View>
                }
            </View>


            {cart_length > 0 ?

                <Carthelp cartcall={() => cartfn()} />
                : null}

            <Productdetail />
        </SafeAreaView>
    )
}
