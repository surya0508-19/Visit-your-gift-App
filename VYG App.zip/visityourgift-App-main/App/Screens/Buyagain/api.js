import axios from 'axios'
import { URL_BUYAGAIN, } from '../../Constants'

export const fetchbuyagain = async (token, cartdata) => {



    try {
        const response = await axios({
            method: "get",
            url: `${URL_BUYAGAIN}`,
            headers: {
                Authorization: token
            },
        })



        if (response.data) {
            var data = response.data.products.data.map(e => {
                if (e.item_variant[0].offer_price) {
                    return ({
                        productname: e.name,
                        product_id: e.id,
                        variant_id: e.variant_id,
                        image: e.image,
                        variant_value: e.item_variant[0].variant_value,
                        actual_qty: Number(e.variant_quantity),
                        wishlist: e.is_already_in_wish_list,
                        price: Number(e.item_variant[0].price),
                        offer_price: Number(e.item_variant[0].offer_price),
                        discount: Number(e.item_variant[0].discount),
                        qty: Number(0),
                        check: false,

                    })
                }
                else {
                    return ({
                        productname: e.name,
                        product_id: e.id,
                        variant_id: e.variant_id,
                        image: e.image,
                        variant_value: e.item_variant[0].variant_value,
                        actual_qty: Number(e.variant_quantity),
                        wishlist: e.is_already_in_wish_list,
                        price: Number(e.item_variant[0].price),
                        offer_price: Number(0),
                        qty: Number(0),
                        discount: Number(0),
                        check: false
                    })
                }
            })

            if (cartdata.length > 0) {
                var final = data.map(e => {
                    var sathish = cartdata.find(f => f.product_id == e.product_id)
                    if (sathish != undefined) {
                        return sathish
                    }
                    else {
                        return e
                    }
                })
                return final

            }
            else {
                return data

            }


        }



    }
    catch (err) {
        console.log("error", err)
    }

}