import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, TextInput, ActivityIndicator, KeyboardAvoidingView, Modal, SafeAreaView, ScrollView, StyleSheet } from 'react-native';
import { productpics } from '../TestData/data';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import Helperhome from '../../Components/helperhome';
import Cartproducts from '../../Components/Cartproducts';
import { AnimatedScrollView } from '@kanelloc/react-native-animated-header-scroll-view';
import Subcategoriesnav from '../../Components/subcategoriesnav';
import Cartnavnar from '../../Components/Carttabbar';
import Similarproducts from '../../Components/similarproducts';
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable';
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';
import DatePicker from 'react-native-date-picker'
// import Modal from 'react-native-modal';
import moment from 'moment';

import { useDispatch, useSelector } from 'react-redux';
import { cartSelector, fetchcart } from '../../Slices/cart';
import { authSelector } from '../../Slices/auth';
import { addressSelector, editaddress, updateerr } from '../../Slices/address';
import Toast from 'react-native-simple-toast';
import { deliverychargeSelector, fetchdeivery, update_del_sts, update_loader } from '../../Slices/deliverycharge';
import Statusbar from '../Statusbar';
export default function Cart(props, navigation) {
  const dispatch = useDispatch()
  const { cart_length, cart_total, discount } = useSelector(cartSelector);
  const { deliverystatus, } = useSelector(deliverychargeSelector);
  const { address_list, err } = useSelector(addressSelector);
  const { token } = useSelector(authSelector)
  // const minDate = (new Date());
  const [visibleAddress, setvisibleAddress] = useState(false)
  const [visible, setvisible] = useState(false)
  const [visible1, setvisible1] = useState(false)

  const [datemodal, setDatemodal] = useState(false)
  const [confirmdate, setconfirmdate] = useState(false)

  const [date, setDate] = useState("")


  // const [discount, setdiscount] = useState("")
  const [coupon, setcoupon] = useState("")
  const [Applied, setApplied] = useState("")

  const [indexs, setindex] = useState("")
  const [addAdress, setaddAdress] = useState("")

  const [type, settype] = useState('Pickup');
  const [fname, setfname] = useState("")
  const [lname, setlname] = useState("")
  const [mobile, setmobile] = useState("")
  const [Door, setDoor] = useState("")
  const [Add2, setAdd2] = useState("")
  const [City, setCity] = useState("")
  const [Stat, setStat] = useState("")
  const [Zipcodes, setZipcodes] = useState("")
  const [add, setadd] = useState(-1)

  const [time, settime] = useState("")
  const [timeindex, settimeindex] = useState(-1)
  const [Deliverytype, setDeliverytype] = useState("")

  const [selectip, setselectip] = useState(0)
  const [selectip1, setselectip1] = useState('')
  const [Custom, setCustom] = useState(false)
  const [address, setaddress] = useState("")
  const [Selecttime, setSelecttime] = useState("")



  const { delivery, loadersts, success,delivery_settings } = useSelector(deliverychargeSelector)





  const today = new Date()
  // to return the date number(1-31) for the specified date
  // console.log("today => ", today)
  const tomorrow = new Date()
  tomorrow.setDate(today.getDate() + 1)
  //returns the tomorrow date
  // console.log("tomorrow => ", tomorrow)



  const [activeaddress, setActiveaddress] = useState({
    address1: "",
    address2: "",
    city: "",
    state: "",
    zipcode: "",
    type: ""
  })
  const { width, height } = Dimensions.get("window")

  const data = {
    name: 'Cart',
    search: false
  }


  // useEffect(() => {
  //   if(deliverystatus)
  //   {
  //       if(type == "Delivery")
  //       {
  //         dispatch(update_del_sts(false))
  //             props.navigation.navigate("Checkout",{
  //               type:type,
  //               data:''
  //            })

  //       }
  //       else
  //       {
  //          var pickupdata = {
  //              location:address,
  //              date:date,
  //              time:Selecttime
  //          }
  //          dispatch(update_del_sts(false))
  //       props.navigation.navigate("Checkout",{
  //          type:type,
  //          data:pickupdata
  //       })
  //       }
  //   }
  //  },[deliverystatus]) 

  useEffect(() => {

  }, [])

  const onSelect = (index, value) => {

    settype(value)
  }

  useEffect(() => {

    const filter = address_list.find(e => {
      if (e.status)
        return e
    })
    if (filter) {

      console.log("filter", filter)
      setActiveaddress(filter)
    }

  }, [address_list])


  const back = async () => {
    dispatch(fetchcart(token))
    props.navigation.navigate('Sidemenu')
  }




  const onSelectAddress = (index, value) => {


    setadd(index)

    if (value == "Add1") {

      setaddress("Kalpana Bazaar 45 Waverley Dr STE N Frederick MD 21702")
      setvisible(false)

    }
    else {
      setaddress('Kalpana Bazaar 337 Hospital Dr STE T Glen Burnie, MD 21061')
      setvisible(false)

    }

  }

  const onSelectTime = (value) => {

    // settimeindex(index)
    if (value == "First") {
      setSelecttime("9 AM - 12 PM")
      settime(value)
    }
    else if (value == "Second") {
      settime(value)
      setSelecttime("12 PM - 3 PM")
    }
    else {
      settime(value)
      setSelecttime("3 PM - 6 PM")
    }





  }



  const [paymentmodal, setPaymentmodal] = useState(false)


  useEffect(() => {

    if (err) {
      Toast.show("Please enter valid zipcode", Toast.SHORT);
      dispatch(updateerr(false))
    }
  }, [err])

  const checkout = () => {

    const filter = address_list.find(e => {
      if (e.status)
        return e
    })
    if (!activeaddress.type) {
      Toast.show("Please enter the address type", Toast.SHORT);
    }
    else if (!activeaddress.address1) {
      Toast.show("Please enter the address1", Toast.SHORT);
    }
    else if (!activeaddress.city) {
      Toast.show("Please enter the city", Toast.SHORT);
    }
    else if (!activeaddress.state) {
      Toast.show("Please enter the state", Toast.SHORT);
    }
    else if (!activeaddress.zipcode) {
      Toast.show("Please enter the zipcode", Toast.SHORT);
    }
    else {
      if ((activeaddress.type != filter.type) || (activeaddress.address1 != filter.address1) || (activeaddress.address2 != filter.address2) || (activeaddress.city != filter.city) || (activeaddress.state != filter.state) || (activeaddress.zipcode != filter.zipcode)) {
        console.log("id", filter)
        var add_data = {
          "address1": activeaddress.address1,
          "address2": activeaddress.address2,
          "state": activeaddress.state,
          "city": activeaddress.city,
          "zipcode": activeaddress.zipcode,
          "type": activeaddress.type
        }
        var postdata = {
          data: add_data,
          token: token,
          id: filter.id
        }
        dispatch(editaddress(postdata))


      }
      else {

        dispatch(fetchdeivery(token))







        if (success == true) {

       
          if (Number(cart_total) >= Number(delivery_settings.minimum_order_amount)) {

            props.navigation.navigate("Checkout", {
              type: type,
              data: activeaddress
            })

          }
          else {

            Toast.show(`Shop for $ ${parseFloat(delivery_settings.minimum_order_amount - cart_total).toFixed(2)} more to get this order`, Toast.SHORT);

          }
          // props.navigation.navigate("Checkout", {
          //   type: type,
          //   data: activeaddress
          // })
        }
        
      }
    }



  }

  const add_address = () => {
    props.navigation.navigate("Addaddress", {
      key: "Add",
      from: "cart"
    })
  }
  const addressvalidate = (value, key) => {
    var data = { ...activeaddress }
    switch (key) {
      case "type":
        data.type = value
        break;
      case "address1":
        data.address1 = value
        break;
      case "address2":
        data.address2 = value
        break;
      case "city":
        data.city = value
        break;
      case "state":
        data.state = value
        break;
      case "zipcode":
        data.zipcode = value
        break;
    }
    setActiveaddress(data)


  }


  return (


    <SafeAreaView style={{ flex: 1 }} >
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <Header dataParentToChild={data} Back={() => back()} />
        <Statusbar dataParentToChild={"white"} />
        {cart_length > 0 ?
          <>
            <View style={{ width: "100%", height: "93%", backgroundColor: "#f4f7fe" }} >

              <ScrollView>
                <AnimatedScrollView
                  HeaderNavbarComponent={false}
                  TopNavBarComponent={<Cartnavnar />}
                  headerMaxHeight={height * 0.02}
                  topBarHeight={height * 0.02}
                  showsVerticalScrollIndicator={false}
                  keyboardDismissMode='on-drag'
                >

                  {/* <View style={{ width: "92.5%", height: height * 0.07, borderRadius: width * 0.025, backgroundColor: "#d9e8ff", alignSelf: "center", flexDirection: "row", bottom: "5%" }} >
                    <View style={{ width: "70%", height: "100%", justifyContent: "center" }} >
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "4%", color: "#3077dd" }} >Your total savings</Text>
                    </View>
                    <View style={{ width: "30%", height: "100%", justifyContent: "center" }} >
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, color: "#3077dd", alignSelf: "flex-end", marginRight: "10%" }} >${parseFloat(discount).toFixed(2)}</Text>
                    </View>

                  </View> */}

                  <Card style={{ width: width * 0.925, height: "auto", alignSelf: "center", borderRadius: width * 0.03 }} >
                    <View style={{ width: "95%", height: 'auto', alignSelf: "center", marginBottom: "2.5%", marginTop: "2.5%" }} >
                      <Cartproducts />
                    </View>
                  </Card>



                  <Card style={{ width: width * 0.925, height: height * 0.08, alignSelf: "center", borderRadius: width * 0.03, marginTop: "5%", flexDirection: "row" }} >
                    <View style={{ width: "55%", height: "100%", marginLeft: "5%", justifyContent: "space-evenly" }} >

                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, color: "black", }} >SubTotal</Text>

                    </View>


                    <View style={{ width: "40%", height: "100%", justifyContent: "space-evenly" }} >

                      <View style={{ flexDirection: "row", width: "auto", alignItems: "center", alignSelf: "flex-end", right: "20%", justifyContent: "space-between" }} >
                        {discount > 0 ?
                          <Text style={{ fontFamily: "Roboto-Light", fontSize: width * 0.035, color: "black", textDecorationLine: "line-through" }} >$ {parseFloat(cart_total + discount).toFixed(2)}</Text> : null}
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", marginLeft: "5%" }} >${parseFloat(cart_total).toFixed(2)}</Text>
                      </View>

                    </View>



                  </Card>
                  {/* <View style={{ width: "92.5%", height: height * 0.07, borderRadius: width * 0.025, backgroundColor: "#d9e8ff", alignSelf: "center", flexDirection: "row",marginTop:15 }} >
                    <View style={{ width: "70%", height: "100%", justifyContent: "center" }} >
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "4%", color: "#3077dd" }} >Your total savings</Text>
                    </View>
                    <View style={{ width: "30%", height: "100%", justifyContent: "center" }} >
                      <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, color: "#3077dd", alignSelf: "flex-end", marginRight: "10%" }} >${parseFloat(discount).toFixed(2)}</Text>
                    </View>

                  </View> */}







                  {/* <Card style={{ width: width * 0.925, height: height * 0.075, alignSelf: "center", borderRadius: width * 0.03, marginTop: "5%", justifyContent: "center" }} >


                    <RadioGroup
                      style={{ width: "80%", flexDirection: "row", alignSelf: "center", justifyContent: "space-between" }}
                      formHorizontal={true}
                      labelHorizontal={true}
                      color="#00a4ff"
                      size={width * 0.05}
                      thickness={width * 0.004}
                      selectedIndex={indexs}
                      onSelect={(index, value) => onSelect(index, value)}
                    >
                      <RadioButton value={'Pickup'} style={{ alignItems: 'center' }} >
                        <View>
                          <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "#00a4ff", marginLeft: "5%" }} >Pickup</Text>
                        </View>
                      </RadioButton>
                      <RadioButton value={'Delivery'} style={{ alignItems: 'center' }} >
                        <View>
                          <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "#00a4ff", marginLeft: "5%" }} >Delivery</Text>
                        </View>
                      </RadioButton>
                    </RadioGroup>



                  </Card> */}




                  {(address_list.length > 0) ?

                    <Card style={{ width: width * 0.925, alignSelf: "center", borderRadius: width * 0.03, marginTop: "5%" }} >




                      <View style={{ width: "100%", height: height * 0.065, alignItems: "center", flexDirection: "row", }} >
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Address Type *</Text>
                        <TouchableOpacity onPress={() => props.navigation.navigate("Address")} style={{ width: "45%", height: "60%", backgroundColor: "#00a4ff", borderRadius: width * 0.01, justifyContent: 'center', marginLeft: "11%" }} >
                          <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "white", textAlign: "center" }} >Change Address</Text>
                        </TouchableOpacity>
                      </View>


                      <View style={{ justifyContent: "center", width: width * 0.85, borderWidth: 1, height: height * 0.06, alignSelf: "center", borderRadius: width * 0.015 }}>
                        <TextInput
                          onChangeText={(text) => addressvalidate(text, "type")}
                          value={activeaddress.type}
                          editable={true}
                          style={{ marginLeft: "2%", fontFamily: "Roboto-Regular", fontSize: 17, fontWeight: "600", width: "99%", color: "black" }}
                          placeholder={'Enter the First Name'}
                        />

                      </View>

                      <Text style={{ marginTop: "2%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Address Line 1*</Text>

                      <View style={{ justifyContent: "center", width: width * 0.85, borderWidth: 1, height: height * 0.06, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015 }}>
                        <TextInput
                          onChangeText={(text) => addressvalidate(text, "address1")}
                          value={activeaddress.address1}
                          editable={true}
                          style={{ marginLeft: "2%", fontFamily: "Roboto-Regular", fontSize: 17, fontWeight: "600", width: "99%", color: "black" }}
                          placeholder={'Enter the Address Line 1'}
                        />

                      </View>

                      <Text style={{ marginTop: "2%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Address Line 2</Text>

                      <View style={{ justifyContent: "center", width: width * 0.85, borderWidth: 1, height: height * 0.06, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015 }}>
                        <TextInput
                          onChangeText={(text) => addressvalidate(text, "address2")}
                          value={activeaddress.address2}
                          editable={true}
                          style={{ marginLeft: "2%", fontFamily: "Roboto-Regular", fontSize: 17, fontWeight: "600", width: "99%", color: "black" }}
                          placeholder={'Enter the Address Line 1'}
                        />

                      </View>
                      <Text style={{ marginTop: "2%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >City*</Text>

                      <View style={{ justifyContent: "center", width: width * 0.85, borderWidth: 1, height: height * 0.06, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015 }}>
                        <TextInput
                          onChangeText={(text) => addressvalidate(text, "city")}
                          value={activeaddress.city}
                          editable={true}
                          style={{ marginLeft: "2%", fontFamily: "Roboto-Regular", fontSize: 17, fontWeight: "600", width: "99%", color: "black" }}
                          placeholder={'Enter the Address Line 2'}
                        />

                      </View>
                      <Text style={{ marginTop: "2%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >State/Province*</Text>

                      <View style={{ justifyContent: "center", width: width * 0.85, borderWidth: 1, height: height * 0.06, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015 }}>
                        <TextInput
                          onChangeText={(text) => addressvalidate(text, "state")}
                          value={activeaddress.state}
                          editable={true}
                          style={{ marginLeft: "2%", fontFamily: "Roboto-Regular", fontSize: 17, fontWeight: "600", width: "99%", color: "black" }}
                          placeholder={'Enter the State/Province'}
                        />

                      </View>
                      <Text style={{ marginTop: "2%", fontFamily: "Roboto-Regular", fontSize: width * 0.048, marginLeft: "4%", color: "black" }} >Zip Code*</Text>

                      <View style={{ justifyContent: "center", width: width * 0.85, borderWidth: 1, height: height * 0.06, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015, marginBottom: 15 }}>
                        <TextInput
                          onChangeText={(text) => addressvalidate(text, "zipcode")}
                          value={activeaddress.zipcode}
                          editable={true}
                          keyboardType="numeric"
                          style={{ marginLeft: "2%", fontFamily: "Roboto-Regular", fontSize: 17, fontWeight: "600", width: "99%", color: "black" }}
                          placeholder={'Enter the Zipcode'}
                        />
                      </View>

                    </Card>

                    : null}

                  {(address_list.length == 0) ?
                    <TouchableOpacity onPress={() => add_address()} style={{ width: "55%", height: height * 0.07, backgroundColor: "#00a4ff", justifyContent: "center", alignSelf: "center", borderRadius: width * 0.025, marginTop: "5%", marginBottom: "5%" }} >
                      <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "white", textAlign: "center" }} >+Add address</Text>
                    </TouchableOpacity>
                    :
                    <TouchableOpacity onPress={() => checkout()} style={{ width: "55%", height: height * 0.07, backgroundColor: "#00a4ff", justifyContent: "center", alignSelf: "center", borderRadius: width * 0.025, marginTop: "5%", marginBottom: "10%" }} >
                      {!loadersts ?
                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "white", textAlign: "center" }} >Check out</Text>
                        :
                        <ActivityIndicator color={"black"} />
                      }
                    </TouchableOpacity>}


                </AnimatedScrollView>
              </ScrollView>
            </View>

            <Modal
              animationType="slide"
              transparent={true}
              visible={paymentmodal}

            >

              <View style={{ flex: 1, backgroundColor: "rgba(52, 52, 52, 0.8)" }} >
                <TouchableOpacity onPress={() => setPaymentmodal(false)} style={{ width: width * 0.11, height: height * 0.055, backgroundColor: "black", borderRadius: width * 0.07, alignSelf: "center", justifyContent: "center", bottom: "35%", position: "absolute" }} >
                  <Image style={{ width: '55%', height: "55%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/reject.png')} />
                </TouchableOpacity>
                <Card style={{ justifyContent: "space-evenly", width: width, height: height * 0.3, position: "absolute", bottom: 0 }} >
                  <Card style={{ alignItems: "center", alignSelf: "center", flexDirection: "row", width: "90%", height: height * 0.06, }} >
                    <Image style={{ width: 80, height: 80, resizeMode: "contain", alignSelf: "center", marginLeft: "5%" }} source={require('../../Assets/paypal.png')} />
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "#00a4ff", marginLeft: "5%" }} >Paypal</Text>
                  </Card>
                  <TouchableOpacity >
                    <Card style={{ alignItems: "center", alignSelf: "center", flexDirection: "row", width: "90%", height: height * 0.06, }} >
                      <Image style={{ width: 50, height: 30, resizeMode: "contain", alignSelf: "center", marginLeft: "5%" }} source={require('../../Assets/cash.png')} />
                      <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "#00a4ff", marginLeft: "5%" }} >Cash on Delivery</Text>
                    </Card>
                  </TouchableOpacity>
                </Card>
              </View>
            </Modal>
          </> :
          <View style={{ width: width, height: height * 0.9, justifyContent: "center", alignItems: "center" }}>
            <Image source={require('../../Assets/cartempty.png')} style={{ width: 100, height: 100, }} />
            <Text style={{ fontSize: 20, textAlign: 'center', color: '#366ebe', marginTop: 30, marginLeft: 10 }}>Cart Empty</Text>
          </View>
        }
      </KeyboardAvoidingView>
    </SafeAreaView >
  )

}

const styles = StyleSheet.create({

  unslected: { borderColor: "#C2BEBD", borderWidth: 1, width: 110, height: 45, justifyContent: "center", alignItems: "center" },
  slected: { borderColor: "#C2BEBD", borderWidth: 1, width: 110, height: 45, justifyContent: "center", alignItems: "center", backgroundColor: "#00a4ff" },
  unslecttime: { fontFamily: "Roboto-Regular", fontSize: 15, fontWeight: 'bold', color: 'black', },
  slecttime: { fontFamily: "Roboto-Regular", fontSize: 15, fontWeight: 'bold', color: 'white', }
})