import { Dimensions,StyleSheet} from "react-native"

const {width,height}=Dimensions.get("window")
export default styles = StyleSheet.create({
      container:{
        // flex:1,
        backgroundColor:"white",
        width:"100%",
        height:"100%"
      },
      back:{
        width:width*0.055,
        height:height*0.035,
        alignSelf:"center",
    },
    text1:{
        fontSize:width*0.0425,
        fontFamily:"Roboto-Bold"
    },
    text2:{
        fontSize:width*0.035,
        fontFamily:"Roboto-Light"
    },
    search:{
        width:width*0.05,
        height:height*0.025,
        alignSelf:"center",
    },
    subcategory_container:{
        width:"100%",
        height:"20%",
        backgroundColor:"#00a4ff",
        
    },
    subcategory_container1:{
        width:"100%",
        height:"20%",
        backgroundColor:"#00a4ff",
        
    },
    products_container:{
        width:"100%",
        height:"71%",
        backgroundColor:"#d3d3d33d", 
        alignItems:"center"  ,
    },
    products_container1:{
        width:"100%",
        height:"59%",
        backgroundColor:"#d3d3d33d",
        // marginBottom:"10%",
        alignItems:"center"  
        
    }
})