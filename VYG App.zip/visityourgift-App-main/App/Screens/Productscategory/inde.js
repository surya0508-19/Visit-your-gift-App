import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, Animated, FlatList, Modal, ActivityIndicator } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Helperhome from '../../Components/helperhome';
import Productcategoryheader from '../../Components/productsgategoryheader';
import Subcategories from '../../Components/subcategories';
import Subcategoriesnav from '../../Components/subcategoriesnav';
import Subcategoriesheader from '../../Components/subgategoriesheaer';
import { AnimatedScrollView } from '@kanelloc/react-native-animated-header-scroll-view';
import style from './style';
import Subcategoriesbanner from '../../Components/subcategoriesbanner';
import Categoryproducts from '../../Components/categoryproducts';
import Subcategoriesfilter from '../../Components/subcategoriesfilter';
import Statusbar from '../Statusbar';
import Carthelp from '../../Components/carthelp';
import { countSelector } from '../../Slices/count';
import { useDispatch, useSelector } from 'react-redux';
import Productdetail from '../../Components/productdetail';
import { cartSelector, fetchcart } from '../../Slices/cart';
import { categoriesproductSliceSelector, fetchcatproducts, updatemainloader, updatepagination } from '../../Slices/categoriesproduct';
import { authSelector } from '../../Slices/auth';
import { homedataSelector } from '../../Slices/homedata';
import { modelSelector, updatemodel } from '../../Slices/model';
import { fetchtopbrands } from '../../Slices/searchproducts';
import Toast from 'react-native-simple-toast';
import { Pressable } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';

export default function Productscategory(props, navigation) {
  const dispatch = useDispatch()
  const { token } = useSelector(authSelector);
  const { active_category } = useSelector(homedataSelector);
  const { cart_length, cart_total, discount, cart_products } = useSelector(cartSelector);
  const { catproductsuccess, switchcatstatus, categoriesproduct } = useSelector(categoriesproductSliceSelector)

  const { modelshow } = useSelector(modelSelector)
  const { width, height } = Dimensions.get("window")



  const [Pricefliter, setPricefilter] = useState(false)
  const data = '#00a4ff'
  const cartfn = () => {
    dispatch(fetchcart(token))

    dispatch(updatepagination())
    props.navigation.navigate("Cart")
  }
  useEffect(() => {
    var data = {
      cat_id: active_category.id,
      page: 1,
      cartdata: cart_products,
      type: '',
      token: token,
      state: "",
      brand: "",
      sort: ""

    }
    dispatch(updatemainloader(true))
    dispatch(fetchcatproducts(data))
  }, [])

  useEffect(() => {
    var data = {
      type: "categorydata",
      status: false
    }
    dispatch(updatemodel(data))
  }, [])

  const back = () => {
    dispatch(fetchcart(token))
    dispatch(updatepagination())
    props.navigation.goBack()
  }

  const SearchPage = () => {


    dispatch(fetchtopbrands(cart_products))

    props.navigation.navigate("SearchPage")


  }
  const logincall = () => {


    Toast.show("Please Login to Purchase", Toast.SHORT);

    props.navigation.navigate("login")


  }

  const PriceFilterOption = () => {

    if (Pricefliter) {

      setPricefilter(false)
    }
    else {
      setPricefilter(true)

    }
  }
  return (
    <SafeAreaView style={style.container} >
      <Statusbar dataParentToChild={data} />
      {/* <Helperhome /> */}
      <Productcategoryheader seachcall={() => SearchPage()} backbutton={() => back()} />
      <View style={{ width: width, height: "92%", }} >
        <Subcategoriesnav />


        <View style={cart_length < 1 ? style.subcategory_container1 : style.subcategory_container} >
          <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "white", marginLeft: 20, marginTop: 10, marginBottom: 10 }} >Category list</Text>
          <Subcategories />


        </View>

        <View style={{ width: "100%", height: "100%", marginTop: 10 }} >




          <View style={cart_length < 1 ? style.products_container : style.products_container1} >

            {!switchcatstatus ? (
              (categoriesproduct.length > 0 ?
                <Categoryproducts logincall={() => logincall()} />
                : (
                  <View style={{ width: "100%", justifyContent: "center", alignItems: "center", marginTop: "20%" }} >
                    <Image style={{ width: width * 0.2, height: height * 0.2, resizeMode: "contain" }} source={require('../../Assets/cloud.png')} />
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "black", }} >No Products found</Text>
                  </View>
                )

              )) :
              <ActivityIndicator color={'gray'} />
            }





          </View>






          {catproductsuccess ?
            <ActivityIndicator color={'gray'} /> : null}
        </View>
      </View>

      <Subcategoriesfilter />


      {cart_length >= 1 ?
        <Carthelp cartcall={() => cartfn()} /> : null}
      <Productdetail />

    </SafeAreaView>
  )

}