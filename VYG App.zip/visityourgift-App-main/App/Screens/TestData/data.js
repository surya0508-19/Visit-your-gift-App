import { Dimensions } from "react-native"

const { width, height } = Dimensions.get("window")
export const Recommendedproduct = [
    {
        name: "Dairy milk silk",
        quantity: "10 kg",
        image: require("../../Assets/product1.png"),
        salesprice: 150,
        marketprice: 170,
        offer: "",
        updatequantity: 0,
        active: false
    },
    {
        name: "Dark Fantasy",
        quantity: "250 g",
        image: require("../../Assets/product2.jpg"),
        salesprice: 35,
        marketprice: 40,
        offer: 4,
        updatequantity: 0,
        active: false
    },
    {
        name: "Parasoot oil",
        quantity: "250 L",
        image: require("../../Assets/product3.png"),
        salesprice: 120,
        marketprice: 130,
        offer: 8,
        updatequantity: 0,
        active: false
    },
    {
        name: "Garnier men face wash",
        quantity: "150 g",
        image: require("../../Assets/product4.png"),
        salesprice: 90,
        marketprice: 110,
        offer: '',
        updatequantity: 0,
        active: false
    },

    {
        name: "Oreo Biscuit",
        quantity: "20 g",
        image: require("../../Assets/product5.jpg"),
        salesprice: 25,
        marketprice: 30,
        offer: '',
        updatequantity: 0,
        active: false
    },

    {
        name: "Basmathi Rice",
        quantity: "5 kg ",
        image: require("../../Assets/Rice.jpg"),
        salesprice: 150,
        marketprice: 180,
        offer: '',
        updatequantity: 0,
        active: false
    },
]

export const TopsellingProducts = [
    {
        name: "Frooti",
        quantity: "50 ml",
        image: require("../../Assets/frooti.png"),
        salesprice: 12,
        marketprice: 15,
        offer: "",
        updatequantity: 0,
        active: false
    },
    {
        name: "Milky mist",
        quantity: "200 g",
        image: require("../../Assets/milkimist.jpg"),
        salesprice: 100,
        marketprice: 110,
        offer: 8,
        updatequantity: 0,
        active: false
    },
    {
        name: "Fortune",
        quantity: "500 L",
        image: require("../../Assets/fortune.jpg"),
        salesprice: 250,
        marketprice: 275,
        offer: '',
        updatequantity: 0,
        active: false
    },
    {
        name: "Naga Rava",
        quantity: "250 g",
        image: require("../../Assets/naga.jpg"),
        salesprice: 25,
        marketprice: 30,
        offer: 15,
        updatequantity: 0,
        active: false
    },

    {
        name: "Aashirvaad Aata",
        quantity: "500 g",
        image: require("../../Assets/Aata.jpg"),
        salesprice: 150,
        marketprice: 175,
        offer: 12,
        updatequantity: 0,
        active: false
    },

    {
        name: "Basmathi Rice",
        quantity: "5 kg ",
        image: require("../../Assets/Rice.jpg"),
        salesprice: 150,
        marketprice: 180,
        offer: '',
        updatequantity: 0,
        active: false
    },
]


export const Savedaddress = [
    {
        Type: "Home",
        address: "46/b Suguna store, Anna nagar, madurai",
        distance: 15
    },
    {
        Type: "Office",
        address: "28,RayazTech,IDBI bank,kk nagar madurai",
        distance: 138
    },
    {
        Type: "Hotel",
        address: "96,Hari hotel,periyar busstand,madurai",
        distance: 12.5
    },
    // {
    //     Type:"Part-time-office",
    //     address:"28,solarites,annanagar,madurai",
    //     distance:10.5
    // }
]

export const RecentAddress = [
    {
        address: "Rayaz Technlogy ,Thalapakatti hotel ,IDBI bank second floor ,KK nagar Arch ,madurai ,625007,Tamilnadu ,India,Asia,world,sunplanent,milkyway galexy",
        distance: 10.5
    },
    {
        address: "Riyashotel ,mattuthavaniroad ,KK nagar Arch ,madurai ,625007,Tamilnadu ,India,Asia,world,sunplanent,milkyway galexy",
        distance: 0.3
    }
]

export const productpics = [
    {
        source: require("../../Assets/product1.png"),
        dimensions: { width: width * 0.05, height: height * 0.05 },
        active: true
    },
    // {
    //     source: require("../../Assets/product2.jpg"),
    //     dimensions: { width: 800, height: 1500 },
    //     active: false
    // },
    // {
    //     source: require("../../Assets/product3.png"),
    //     dimensions: { width: 1080, height: 1920 },
    //     active: false
    // },
    // {
    //     source: require("../../Assets/product4.png"),
    //     dimensions: { width: 1080, height: 1920 },
    //     active: false
    // },
    // {
    //     source: require("../../Assets/product5.jpg"),
    //     dimensions: { width: 1080, height: 1920 },
    //     active: false
    // },

]


export const cartproducts = [
    {
        name: "Frooti",
        quantity: "50 ml",
        image: require("../../Assets/frooti.png"),
        salesprice: 12,
        marketprice: 15,
        offer: "",
        updatequantity: 0,
        active: false
    },
    {
        name: "Milky mist",
        quantity: "200 g",
        image: require("../../Assets/milkimist.jpg"),
        salesprice: 100,
        marketprice: 110,
        offer: 8,
        updatequantity: 0,
        active: false
    },

]
export const orderitemss = [
    {
        name: "Frooti",
        quantity: "50 ml",
        image: require("../../Assets/frooti.png"),
        salesprice: 12,
        marketprice: 15,
        offer: "",
        updatequantity: 0,
        active: false
    },
    {
        name: "Milky mist",
        quantity: "200 g",
        image: require("../../Assets/milkimist.jpg"),
        salesprice: 100,
        marketprice: 110,
        offer: 8,
        updatequantity: 0,
        active: false
    },

]
export const orderlists = [
    {
        orderid: "ORD954765648",
        totamt: 89,
        image: require("../../Assets/ordericon.png"),
        image1: require("../../Assets/greenarrow.png"),
        status: "Active",
        date:"Placed today"

    },
    {
        orderid: " ORD95464645",
        totamt: 100,
        image: require("../../Assets/ordericon.png"),
        image1: require("../../Assets/greenarrow.png"),
        status: "Active",
        date:"31-01-2003"
    },
    {
        orderid: "ORD75757577",
        totamt: 54,
        image: require("../../Assets/ordericon.png"),
        image1: require("../../Assets/greenarrow.png"),
        status: "Active",
        date:"30-01-2003"
    },
    {
        orderid: "ORD44675648",
        totamt: "178",
        image: require("../../Assets/ordericon.png"),
        image1: require("../../Assets/greenarrow.png"),
        status: "Active",
        date:"30-01-2003"
    },
    {
        orderid: "ORD954765648",
        totamt: 89,
        image: require("../../Assets/ordericon.png"),
        image1: require("../../Assets/greenarrow.png"),
        status: "Active",
        date:"29-01-2003"
    },



]