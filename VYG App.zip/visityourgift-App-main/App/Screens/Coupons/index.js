
import React, { useState, useEffect, Component } from 'react';
import { View, Text, SafeAreaView, Image, Dimensions, ScrollView, TextInput } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';


export default function Coupons(props) {
    const { width, height } = Dimensions.get("window")
    

    const data = {
        name:'Coupons',
        search:false
    }

    const [coupon, setcoupon] = useState('')


    return (
        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />

            <View style={{ width: width, height: height * 0.935, backgroundColor: "white", }}>
                <ScrollView>
                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, }}></View>

                    <View style={{ marginTop: "1%", borderColor: "grey", flexDirection: "row", width: width * 0.92, borderWidth: 1, height: height * 0.058, alignSelf: "center", marginTop: "3%", borderRadius: width * 0.015, justifyContent: "space-between", alignItems: "center" }}>

                        <TextInput
                            onChangeText={(text) => setcoupon(text)}
                            value={coupon}
                            style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.05, fontWeight: "600", width: "70%", marginLeft: "1%" }}
                            placeholder={'Enter Coupon Code'}

                        />
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "black", textAlign: "center", marginRight: "3%" }} >APPLY</Text>

                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.020, }}></View>


                    <View style={{ justifyContent: "space-between", width: "100%", height: width * 0.40, alignSelf: "center", borderColor: "#eaeaea" }} >

                        <Image style={{ width: "40%", height: "40%", resizeMode: "contain", marginTop: "4%", marginLeft: "1%" }} source={require("../../Assets/digimart.png")} />

                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.041, color: "black", width: "90%", marginLeft: "4%" }} >Flat 10% off on Standard Chartered Digismart Credit Card</Text>
                        <View style={{ flexDirection: "row", }}>
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "grey", marginLeft: "4%" }} >No minimum order value</Text>
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", marginLeft: "2%" }} >View Details</Text>

                        </View>

                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, marginTop: "3%" }}></View>
                    <View style={{ flexDirection: "row", width: width * 0.92, height: height * 0.058, alignSelf: "center", marginTop: "3%", justifyContent: "space-between", alignItems: "center" }}>

                        <View style={{ flexDirection: "row", height: height * 0.040, width: "30%", justifyContent: "center", alignItems: "center", borderWidth: 1, borderStyle: 'dashed', borderColor: "blue" }}>
                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, color: "black", marginLeft: "4%" }} >DIGISMART</Text>
                        </View>

                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.038, color: "#00a4ff", textAlign: "center", marginRight: "2%" }} >APPLY</Text>

                    </View>
                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.015, marginTop: "5%" }}></View>


                    <View style={{ justifyContent: "space-between", width: "100%", height: width * 0.40, alignSelf: "center", borderColor: "#eaeaea" }} >

                        <Image style={{ marginLeft: "3%", width: "15%", height: "15%", resizeMode: "contain", marginTop: "4%" }} source={require("../../Assets/simple.png")} />

                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.041, color: "black", width: "90%", marginLeft: "4%" }} >Flat 5% cashback on first Simple transaction</Text>
                        <View style={{ flexDirection: "row", marginBottom: "15%" }}>
                            <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.030, color: "grey", marginLeft: "4%" }} >Total value of items must be $ 50 or more</Text>
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", marginLeft: "2%" }} >View Details</Text>

                        </View>

                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, bottom: "5%" }}></View>
                    <View style={{ bottom: "8%", flexDirection: "row", width: width * 0.92, height: height * 0.058, alignSelf: "center", justifyContent: "space-between", alignItems: "center" }}>

                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "#aa802e", marginLeft: "2%" }} >No code required</Text>


                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.015, bottom: "2.5%" }}></View>


                    <View style={{ justifyContent: "space-between", width: "100%", height: width * 0.40, alignSelf: "center", borderColor: "#eaeaea" }} >

                        <Image style={{ marginLeft: "4%", width: "20%", height: "20%", resizeMode: "contain", }} source={require("../../Assets/edition.png")} />
                        <View style={{ bottom: "40%" }}>
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.041, color: "black", width: "90%", marginLeft: "4%" }} >Flat 5% cashback on your Edition Black Card</Text>
                            <View style={{ flexDirection: "row", marginTop: "2%" }}>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "grey", marginLeft: "4%" }} >No minimum order value</Text>
                                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", marginLeft: "2%" }} >View Details</Text>

                            </View>
                        </View>
                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, bottom: "5%" }}></View>
                    <View style={{ bottom: "8%", flexDirection: "row", width: width * 0.92, height: height * 0.058, alignSelf: "center", justifyContent: "space-between", alignItems: "center" }}>

                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "#aa802e", marginLeft: "2%" }} >No code required</Text>


                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.015, bottom: "2.5%" }}></View>


                    <View style={{ justifyContent: "space-between", width: "100%", height: width * 0.40, alignSelf: "center", borderColor: "#eaeaea" }} >

                        <Image style={{ marginLeft: "4%", width: "20%", height: "20%", resizeMode: "contain", }} source={require("../../Assets/edition1.png")} />
                        <View style={{ bottom: "40%" }}>
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.041, color: "black", width: "90%", marginLeft: "4%" }} >Flat 5% cashback on your Edition Classic card</Text>
                            <View style={{ flexDirection: "row", marginTop: "2%" }}>
                                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "grey", marginLeft: "4%" }} >No minimum order value</Text>
                                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.035, color: "black", marginLeft: "2%" }} >View Details</Text>

                            </View>
                        </View>
                    </View>

                    <View style={{ width: "100%", backgroundColor: "#f5f5f5", height: height * 0.005, bottom: "5%" }}></View>
                    <View style={{ bottom: "8%", flexDirection: "row", width: width * 0.92, height: height * 0.058, alignSelf: "center", justifyContent: "space-between", alignItems: "center" }}>

                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, color: "#aa802e", marginLeft: "2%" }} >No code required</Text>


                    </View>

                </ScrollView>
            </View>




        </SafeAreaView>
    )
}