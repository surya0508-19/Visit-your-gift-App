
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, TextInput, KeyboardAvoidingView, ActivityIndicator, ScrollView, FlatList } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';
import { Card } from 'react-native-shadow-cards';
import { fetchingenquiry } from './api';
import { authSelector } from '../../Slices/auth';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import Toast from 'react-native-simple-toast';
import axios from 'axios';
import { URL_POINTS } from '../../Constants';
import { fetchprofile, profileSelector } from '../../Slices/profile';

export default function SuperCoins(props, { navigation }) {



    const { token } = useSelector(authSelector)
    const { profile } = useSelector(profileSelector)

    const [loder, setLoader] = useState(true)

    const [auth, setAuth] = useState(false)


    const [value, setValue] = useState('')
    const { width, height } = Dimensions.get("window")

    const data = {
        name: 'Super Coins',
        search: false
    }

    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(fetchprofile(token))
        getUsers()
    }, [])

    const [ArrayData, setArrayData] = useState([])

    const getUsers = async () => {
        console.log(token, "tokentokentoken")
        try {
            const response = await axios({
                method: "get",
                url: `${URL_POINTS}`,
                headers: {
                    Authorization: token
                },
            })



            console.log("ress", response.data.data[0])

            setArrayData(response.data.data)
            setLoader(false)
        }
        catch (err) {
            console.log("error", err)

            setLoader(false)


        }


    }


    return (



        <SafeAreaView style={styles.container}>
            <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />

            <View style={{ flexDirection: "row", alignItems: "center", marginLeft: 5, justifyContent: "center" }}>
                <Image style={{ height: 40, width: 40, resizeMode: "contain" }} source={require("../../Assets/star.png")}></Image>
                <Text style={{ fontSize: 30, fontWeight: "bold", color: "black", marginLeft: 2 }}> {profile.reward_points} </Text>
            </View>
            <Text style={{ fontSize: 17, fontWeight: "400", color: "black", textAlign: "center" }}>Available Balance </Text>

            <View style={{ height: 5, width: "100%", backgroundColor: "#E5E4E2", marginTop: "5%" }}></View>
            <Text style={{ fontSize: 19, fontWeight: "700", color: "black", marginLeft: "5%", marginTop: 10, marginBottom: 5, textDecorationLine: "underline" }}>Transaction History </Text>
            {!loder ?
                <FlatList
                    data={ArrayData}
                    renderItem={({ item, index }) => (

                        <View style={{ height: 65, alignItems: "center", flexDirection: "row", justifyContent: "center", borderBottomWidth: 1, borderColor: "#E5E4E2" }}>
                            <View style={{ alignItems: "center", width: "90%", alignSelf: "center", flexDirection: "row", justifyContent: "space-between", }}>
                                <View style={{ width: "80%", justifyContent: "space-between" }} >
                                    <Text style={{ fontSize: 16, fontWeight: "400", color: "black", }}>{item.order.order_list[0].item.name}</Text>

                                    <View style={{ width: "90%", flexDirection: "row", marginTop: 5 }} >
                                        <Text style={{ fontSize: 13, fontWeight: "600", color: "grey", }}>Order Id #{item.order_id}  |</Text>

                                        <Text style={{ fontSize: 13, fontWeight: "600", color: "grey", }}>  Creadited On  {moment(item.created_at).format("MM-DD-YYYY")} </Text>
                                    </View>
                                </View>
                                <View style={{ width: "20%", alignItems: "flex-end" }} >

                                    {item.point_debited && item.point_debited != "0.00" ?
                                        <Text style={{ fontSize: 16, fontWeight: "400", color: "red", }}>- {Number(item.point_debited).toFixed(0)}</Text>
                                        : null}

                                    {item.point_credited && item.point_credited != "0.00" ?
                                        <Text style={{ fontSize: 16, fontWeight: "400", color: "green", }}>+ {Number(item.point_credited).toFixed(0)}</Text>
                                        : null}


                                </View>
                            </View>
                        </View>


                    )}

                />
                :
                <View style={{ height: "60%", justifyContent: "center", alignItems: "center" }}>

                    <ActivityIndicator color={"grey"}></ActivityIndicator>
                </View>
            }
        </SafeAreaView >


    )
}