
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, StyleSheet, TextInput, SafeAreaView, Animated, FlatList, Modal, ScrollView } from 'react-native';
import { Card } from 'react-native-shadow-cards';
import Header from '../../Navigator/Header';
import { Savedaddress } from '../TestData/data';
import CheckBox from '@react-native-community/checkbox';
import { addressSelector, deleteaddress, fetchaddress, setactiveaddress, } from '../../Slices/address';
import { useDispatch, useSelector } from 'react-redux';
import { authSelector } from '../../Slices/auth';
import { fetchdeivery } from '../../Slices/deliverycharge';

const { width, height } = Dimensions.get("window")
export default function Address(props, navigation) {
  const dispatch = useDispatch()
  const data = {
    name: 'My Address',
    search: false
  }

  const { token } = useSelector(authSelector)
  const { address_list, add_status } = useSelector(addressSelector)

  const [addressupdate, setAddressupdate] = useState(false)
  const [select, setSelect] = useState(0)
  const [editindex, setEditindex] = useState(0)
  const EditAddress = (index) => {
    setAddressupdate(true)
    setEditindex(index)
  }

  const Change = (value, index) => {
    if (index != select) {
      var postdata = {
        id: address_list[index].id,
        token: token
      }
      dispatch(setactiveaddress(postdata))
      setSelect(index)

    }

  }
  const back = () => {
    dispatch(fetchaddress(token))
    props.navigation.goBack()
  }
  const add_address = () => {
    props.navigation.navigate("Addaddress", {
      key: "Add"
    })
  }
  const editaddress = () => {
    setAddressupdate(false)
    setSelect(0)
    // console.log("Type",address_list[editindex])
    props.navigation.navigate("Addaddress", {
      key: "edit",
      data: address_list[editindex]
    })
  }
  const Deleteaddress = () => {
    setAddressupdate(false)
    setSelect(0)
    var postdata = {
      id: address_list[editindex].id,
      token: token
    }

    dispatch(deleteaddress(postdata))


  }
  return (
    <SafeAreaView style={{ flex: 1 }} >
      <Header dataParentToChild={data} Back={() => back()} />
      {address_list.length == 0 ?
        <TouchableOpacity onPress={() => add_address()} style={{ width: "100%", height: height * 0.075, borderBottomWidth: width * 0.001, borderColor: "#9e9e9e73", justifyContent: "center" }} >
          <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, color: "#00a4ff", marginLeft: "2.5%", }} >+ Add New Address</Text>
        </TouchableOpacity>
        : null}
      {address_list.length > 0 ?
        <FlatList
          data={address_list}
          renderItem={({ item, index }) => (
            <View style={{ width: "100%", height: height * 0.1, alignSelf: "center", borderBottomWidth: width * 0.001, borderColor: "gray", flexDirection: "row", alignItems: "center" }} >
              <View style={{ width: "17.5%", height: "90%", alignItems: "center", justifyContent: "center", }} >
                <CheckBox
                  value={select == index}
                  onValueChange={(value) => Change(value, index)}
                />
              </View>
              <View style={{ width: "65%", height: "auto", }} >
                <Text style={{ fontFamily: "Roboto-Medium", marginLeft: "2.5%", fontSize: width * 0.0425, }} >{item.type}</Text>
                <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.035, color: "black", marginLeft: "2.5%", }} >{item.address1}, {item.city}, {item.state}, {item.zipcode}</Text>
              </View>

              <View style={{ width: "17.5%", height: "100%", justifyContent: "center" }} >
                <TouchableOpacity onPress={() => EditAddress(index)} style={{ width: "42.5%", height: "35%", backgroundColor: "white", borderRadius: width * 0.1, alignSelf: "center", borderWidth: width * 0.001, borderColor: "gray", alignItems: "center", flexDirection: "row", justifyContent: "center" }} >
                  <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
                  <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
                  <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.035, color: "#00a4ff", textAlign: "center" }} >•</Text>
                </TouchableOpacity>
              </View>

            </View>
          )
          }
        /> : <View style={{ width: "100%", height: "80%", justifyContent: "center" }} >
          <Image source={require('../../Assets/cloud.png')} style={{ width: 100, height: 100, alignSelf: "center" }} />
          <Text style={{ fontSize: 20, textAlign: 'center', color: '#366ebe', marginTop: 30, marginLeft: 10 }}>No Address found</Text>
        </View>}




      <Modal
        animationType="slide"
        transparent={true}
        visible={addressupdate}

      >

        <View onStartShouldSetResponder={() => setAddressupdate(false)} style={{ height: "100%", justifyContent: "center", alignItems: "center", backgroundColor: "rgba(52, 52, 52, 0.8)", }}>
          <Card style={{ width: "100%", height: "20%", overflow: 'hidden', bottom: "0%", position: "absolute", shadowColor: "#000", shadowOpacity: 1.30, shadowRadius: 5, borderTopRightRadius: 20, borderTopLeftRadius: 20, }}>
            <TouchableOpacity onPress={() => editaddress()} >
              <View style={{ justifyContent: 'center', marginTop: "5%", flexDirection: "row", width: "100%", alignSelf: "center" }}>

                <Image style={{ width: 20, height: 20, marginTop: "5%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/edit.png')} />

                <Text style={{ marginLeft: "2%", color: "black", fontSize: 17, marginTop: "5%", textAlign: "center" }}>Edit</Text>
              </View>
            </TouchableOpacity>

            <View style={{ width: "85%", height: "0.5%", backgroundColor: "#C5C5C5", top: "5%", marginLeft: "7%" }}></View>

            <View style={{ width: "85%", height: "0.5%", backgroundColor: "#C5C5C5", position: "relative", top: "5%", marginLeft: "7%" }}></View>

            <TouchableOpacity onPress={() => Deleteaddress()} >

              <View style={{ justifyContent: 'center', marginTop: "5%", flexDirection: "row", width: "100%", alignSelf: "center" }}>

                <Image style={{ width: 20, height: 20, marginTop: "5%", resizeMode: "contain", alignSelf: "center" }} source={require('../../Assets/remove.png')} />

                <Text style={{ marginLeft: "2%", color: "red", fontSize: 17, marginTop: "5%", textAlign: "center" }}>Delete</Text>

              </View>

            </TouchableOpacity>
          </Card>
        </View>

      </Modal>

    </SafeAreaView>
  )
}