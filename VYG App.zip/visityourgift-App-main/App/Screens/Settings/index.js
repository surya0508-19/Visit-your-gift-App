
import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, TextInput, KeyboardAvoidingView, ActivityIndicator, ScrollView } from 'react-native';


import Allorders from '../../Components/Allorders';
import Header from '../../Navigator/Header';
import { orderlists } from '../TestData/data';
import styles from './style';
import { Card } from 'react-native-shadow-cards';
import { fetchingenquiry } from './api';
import { authSelector } from '../../Slices/auth';
import { useSelector } from 'react-redux';

import Toast from 'react-native-simple-toast';

export default function Settings(props, { navigation }) {



    const { token } = useSelector(authSelector)


    const [loder, setLoader] = useState(false)

    const [auth, setAuth] = useState(false)
    const [value, setValue] = useState('')
    const { width, height } = Dimensions.get("window")

    const data = {
        name: 'Contact Us',
        search: false
    }

    const Confirm = async () => {




        if (value == "") {

            Toast.show("Please Enter Your Comments", Toast.SHORT);

        } else {

            var data = {
                "message": value
            }
            setLoader(true)
            const output = await fetchingenquiry(data, token)

            console.log("vvvv", output)


            setLoader(false)


            if (output.success == true) {

                Toast.show(output.message, Toast.SHORT);

                props.navigation.navigate("Sidemenu")

            }

        }

    }

    return (



        <SafeAreaView style={styles.container}>
            <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : "height"}>
                <Header dataParentToChild={data} Back={() => props.navigation.goBack()} />


                <ScrollView >

                    <Text style={styles.text2}  >Enquiries</Text>

                    <Card style={styles.login} >

                        <TextInput
                            style={{ width: "90%", fontFamily: "Roboto-Light", fontSize: 17, fontWeight: "600", marginLeft: "5%", }}
                            multiline={true}
                            onChangeText={(text) => setValue(text)}

                            value={value}
                            placeholder={'Enter your comments'}
                        />
                    </Card>

                    <TouchableOpacity onPress={() => Confirm()} style={styles.button_container} >
                        {!loder ?
                            <Text style={styles.continue_text} >Continue</Text>
                            :
                            <ActivityIndicator color={'white'} />}

                    </TouchableOpacity>
                </ScrollView >
            </KeyboardAvoidingView>

        </SafeAreaView >


    )
}