import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_ADD_TO_CART, URL_CART_LIST } from '../Constants'
import { updatecatpro } from './categoriesproduct'
import { fetchctopseling, fetchrecommended } from './homedata'
import { fetchprodetail } from './productdetail'
import { fetchwishlistproducts } from './whishlist'

export const initialState = {
  cart_products: [],
  cart_length: 0,
  cart_total: 0,
  discount: 0
}

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    getcart: (state, { payload }) => {
      state.cart_products = payload.cartdata,
        state.cart_total = payload.carttotal,
        state.cart_length = payload.cartlength,
        state.discount = payload.cartdiscount
    },
    update_maincart: (state, { payload }) => {
      state.cart_length = Number(state.cart_length) + Number(payload.cartlength),
        state.cart_total = Number(payload.productprice) + Number(state.cart_total)
    },
    update_cart_products: (state, { payload }) => {
      //cart updation
      var data = [...state.cart_products]
      if (payload.key == "increment") {
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)

      }
      else {
        if (data[payload.value].qty == 1) {
          if (payload.value > -1) {
            data.splice(payload.value, 1);
            state.cart_length = Number(state.cart_length) - Number(1)
          }
        }
        else {
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
        }
      }
      //Total price calculation
      var total_cal = data.map(e => {
        if (e.offer_price > 0) {
          return Number(e.offer_price) * Number(e.qty)
        }
        else {
          return Number(e.price) * Number(e.qty)
        }
      })
      var total = total_cal.reduce((a, b) => a + b, 0)
      //discount calculation  
      var discount_cal = data.map(e => {
        if (e.offer_price > 0) {
          var dis = Number(e.qty) * (Number(e.price) - Number(e.offer_price))
          return dis
        }
        else {
          return Number(0)
        }
      })
      var discount = discount_cal.reduce((a, b) => a + b, 0)
      //state updation
      state.cart_products = data
      state.cart_total = total
      state.discount = discount
    },

    getaddtional_data: (state, { payload }) => {
      state.cart_products = payload
    },
    cart_empty: (state, { payload }) => {
      state.cart_products = [],
        state.cart_total = Number(0),
        state.cart_length = Number(0)
      state.discount = Number(0)
    },
  },
})

export const { getcart, update_maincart, update_cart_products, getaddtional_data, cart_empty } = cartSlice.actions
export const cartSelector = state => state.cart
export default cartSlice.reducer

export function addtocart(payload) {

  return async dispatch => {
    try {
      const response = await axios({
        method: "post",
        url: `${URL_ADD_TO_CART}`,
        data: payload.data,
        headers: {
          Authorization: payload.token
        },
      })
      // dispatch(fetchcart(payload.token))

    }
    catch (err) {
      console.log("error", err)
    }
  }
}

export function fetchcart(payload, detail) {

  console.log("payload", payload)
  return async dispatch => {
    try {
      const response = await axios({
        method: "get",
        url: `https://phpstack-1231498-4714101.cloudwaysapps.com/api/cart`,
        headers: {
          Authorization: "Bearer 1381|fnKGR2Gp06Lc2ScVeiOgXSP3nRD0ljA7Cl2ZomDm"
        },
      })

      if (response.data.cart_items.length > 0) {
        var data = response.data.cart_items.map(e => {
          if (e.item_variant.offer_price) {
            return ({
              productname: e.items.name,
              product_id: e.product_id,
              variant_id: e.product_variant_id,
              image: e.items.image,
              variant_count: Number(e.items.item_variant_count),
              variant_value: e.item_variant.variant_value,
              actual_qty: Number(e.item_variant.quantity),
              wishlist: e.items.is_already_in_wish_list,
              price: Number(e.item_variant.price),
              offer_price: Number(e.item_variant.offer_price),
              discount: Number(e.item_variant.discount),
              qty: Number(e.quantity),
              check: true,
            })
          }
          else {
            return ({
              productname: e.items.name,
              product_id: e.product_id,
              variant_id: e.product_variant_id,
              image: e.items.image,
              variant_count: Number(e.items.item_variant_count),
              variant_value: e.item_variant.variant_value,
              actual_qty: Number(e.item_variant.quantity),
              wishlist: e.items.is_already_in_wish_list,
              price: Number(e.item_variant.price),
              offer_price: Number(0),
              discount: Number(e.item_variant.discount),
              qty: Number(e.quantity),
              check: true,
            })
          }
        })

        console.log("ccccccccc", data)

        var total_cal = response.data.cart_items.map(e => {
          return Number(e.total_amount)
        })
        var total = total_cal.reduce((a, b) => a + b, 0)

        var discount_cal = data.map(e => {
          if (e.offer_price) {
            var dis = Number(e.qty) * (Number(e.price) - Number(e.offer_price))
            return dis
          }
          else {
            return Number(0)
          }
        })
        var discount = discount_cal.reduce((a, b) => a + b, 0)

        var payload_data = {
          cartdata: data,
          carttotal: total,
          cartdiscount: discount,
          cartlength: data.length
        }
        dispatch(getcart(payload_data))
        dispatch(fetchctopseling(data, payload))
        dispatch(fetchrecommended(data, payload))

        dispatch(fetchwishlistproducts(payload, data))
        if (detail) {
          dispatch(fetchprodetail(detail))
        }

      }
      else {
        dispatch(fetchctopseling([], payload))
        dispatch(fetchrecommended([], payload))
        dispatch(fetchwishlistproducts(payload, []))
        if (detail) {
          dispatch(fetchprodetail(detail))
        }
      }
    }
    catch (err) {
      console.log("error cartttttttttttt", err)
    }
  }
}


export function fetchaddtionalcart(payload, detail) {
  return async dispatch => {
    try {
      const response = await axios({
        method: "get",
        url: `${URL_CART_LIST}`,
        headers: {
          Authorization: payload
        },
      })
      if (response.data) {
        var data = response.data.cart_items.map(e => {
          if (e.item_variant.offer_price) {
            return ({
              productname: e.items.name,
              product_id: e.product_id,
              variant_id: e.product_variant_id,
              image: e.items.image,
              variant_count: Number(e.items.item_variant_count),
              variant_value: e.item_variant.variant_value,
              actual_qty: Number(e.item_variant.quantity),
              wishlist: e.items.is_already_in_wish_list,
              price: Number(e.item_variant.price),
              offer_price: Number(e.item_variant.offer_price),
              discount: Number(e.item_variant.discount),
              qty: Number(e.quantity),
              check: true,
            })
          }
          else {
            return ({
              productname: e.items.name,
              product_id: e.product_id,
              variant_id: e.product_variant_id,
              image: e.items.image,
              variant_count: Number(e.items.item_variant_count),
              variant_value: e.item_variant.variant_value,
              actual_qty: Number(e.item_variant.quantity),
              wishlist: e.items.is_already_in_wish_list,
              price: Number(e.item_variant.price),
              offer_price: Number(0),
              discount: Number(e.item_variant.discount),
              qty: Number(e.quantity),
              check: true,
            })
          }
        })


        if (detail.type == "updatecatdata") {

          var final = detail.data.map(e => {
            var sathish = data.find(f => f.product_id == e.product_id)
            if (sathish != undefined) {
              return sathish
            }
            else {
              return e
            }
          })

          var frustration = final.map(e => {
            if (e.qty == Number(1)) {
              return ({
                productname: e.productname,
                product_id: e.product_id,
                variant_id: e.variant_id,
                image: e.image,
                variant_count: Number(e.items.item_variant_count),
                variant_value: e.variant_value,
                actual_qty: Number(e.actual_qty),
                wishlist: e.wishlist,
                price: Number(e.price),
                offer_price: Number(e.offer_price),
                discount: Number(e.discount),
                qty: Number(0),
                check: false,
              })
            }
            else {
              return e
            }
          })

          dispatch(updatecatpro(frustration))
        }
        else {
          dispatch(getaddtional_data(data))
        }
      }
    }
    catch (err) {
      console.log("error", err)
    }
  }
}
