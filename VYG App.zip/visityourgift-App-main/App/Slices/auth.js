import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_LOGIN, URL_SIGNUP } from '../Constants.js'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { fetchprofile, getnotificationlist } from './profile.js';
import { fetchctopseling, fetchhomedata, fetchrecommended } from './homedata.js';
import { fetchcart } from './cart.js';
import { fetchorders } from './orders.js';
import { fetchaddress } from './address.js';
import { fetchtopbrands } from './searchproducts';
import Toast from 'react-native-simple-toast';

import { fetchdeivery } from './deliverycharge.js';
export const initialState = {
  token: '',
  signupsuccess: false,
  loginsuccess: false,
  signuperror: false,
  loginerror: false,
  error: ''
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    getsignupresponse: (state, { payload }) => {
      state.signupsuccess = payload
    },
    getloginresponse: (state, { payload }) => {
      state.loginsuccess = payload
    },
    setaccesstoken: (state, { payload }) => {
      state.token = payload
    },
    retriveaccesstoken: (state, { payload }) => {
      state.token = payload
    },
    removeaccesstoken: (state, { payload }) => {
      state.token = payload
    },
    getsignuperror: (state, { payload }) => {
      state.signupsuccess = false
      state.loginsuccess = false
      state.loginerror = false
      state.signuperror = payload
    },
    getloginerror: (state, { payload }) => {
      state.signupsuccess = false
      state.loginsuccess = false
      state.signuperror = false
      state.loginerror = payload.status
      state.error = payload.err
    },

  },
})

export const { getsignupresponse, getloginresponse, setaccesstoken, retriveaccesstoken, removeaccesstoken, getsignuperror, getloginerror } = authSlice.actions
export const authSelector = state => state.auth
export default authSlice.reducer

export function signup(payload) {

  return async dispatch => {
    try {
      const response = await axios({
        method: "post",
        url: `${URL_SIGNUP}`,
        data: payload
      })
      if (response.data) {
        dispatch(getsignupresponse(true))
      }

    }
    catch (err) {
       dispatch(getsignuperror(true))
      console.log("error", err.response.data)

       Toast.show(err.response.data.toast_message, Toast.SHORT);
      // dispatch(getsignuperror(false))

    }
  }
}

export function userlogin(payload) {

  return async dispatch => {
    try {
      console.log("payload", payload)
      const response = await axios({
        method: "post",
        url: `${URL_LOGIN}`,
        data: payload
      })
      if (response.data) {

        var token = `${"Bearer "}` + response.data.token
        AsyncStorage.setItem("UserToken", response.data.token)
        AsyncStorage.setItem("Token", token)
        dispatch(getloginresponse(true))
        dispatch(setaccesstoken(token))
        dispatch(fetchaddress(token))
        dispatch(fetchhomedata())
        dispatch(fetchcart(token))
        dispatch(fetchorders(token))
        dispatch(fetchprofile(token))
        dispatch(fetchctopseling())
        dispatch(fetchrecommended())
        dispatch(fetchtopbrands())
        dispatch(fetchdeivery(token))
        dispatch(getnotificationlist(token))


        // dispatch(fetchctopseling())
        // dispatch(fetchrecommended())
      }

    }
    catch (err) {
      if (err.response.data.errors.email == "The selected email is invalid.") {
        var data = {
          err: "The email address is not registered please signup",
          status: true
        }
        dispatch(getloginerror(data))
      }
      else {
        var data = {
          err: "The password is incorrect",
          status: true
        }
        dispatch(getloginerror(data))
      }

      console.log("error236", err.response.data)
    }
  }
}
