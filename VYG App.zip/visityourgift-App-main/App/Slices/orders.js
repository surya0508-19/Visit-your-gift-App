import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import {URL_ABOUT_US, URL_ORDERDETAIL, URL_ORDERLIST} from '../Constants.js'

export const initialState = {
    orders:[],
    orderdetails:{},
    orderdeatilsts:false
}

const ordersSlice = createSlice({
  name: 'orders',
  initialState,
  reducers: {
    getorders: (state, { payload }) => {
      state.orders = payload
    },
     
    getorderdetail: (state, { payload }) => {
        state.orderdetails = payload
      },
      update_order_detailsts: (state, { payload }) => {
        state.orderdeatilsts = payload
      },
  },
})

export const {getorders,getorderdetail,update_order_detailsts} = ordersSlice.actions
export const ordersSelector = state => state.orders
export default ordersSlice.reducer


// export function fetchorderdetails(payload) {
  
//     return async dispatch => {
//       try {
//         console.log("Reponse",payload)
      
//         const response =  await axios({
//           method:"get",
//           url:`${URL_ORDERDETAIL}`+"2496",
//           headers:{
//             Authorization:"Bearer 729|AUFp1iFTyToABBnY0DaGxCgYG02fCFXoVchQgMnN"
//           }
//          })
//          if(response.data)
//          {
//             dispatch(getorderdetail(response.data))
//             dispatch(update_order_detailsts(true))
            
//          }
        
//       }
//       catch(err)
//       {
//           console.log("error",err)
//       } 
//     }
//   }

  export function fetchorders(payload) {
  
    return async dispatch => {
      try {
        const response =  await axios({
          method:"get",
          url:`${URL_ORDERLIST}`,
          headers:{
            Authorization:payload
          }
         })

         console.log("uuuuuuuuuuu",response.data)
         if(response.data)
         {
             console.log("ajeee",response.data)
             dispatch(getorders(response.data.orders))
         }
        
      }
      catch(err)
      {
          console.log("ordererr",err)
      } 
    }
  }