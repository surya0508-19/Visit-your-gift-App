import { createSlice } from '@reduxjs/toolkit'
import {URL_ABOUT_US} from '../Constants.js'
import { Recommendedproduct } from '../Screens/TestData/data.js'

export const initialState = {
  recommended:[{
        name:"Dairy milk silk",
        quantity:"10 kg",
        image:require("../Assets/product1.png"),
        salesprice:150,
        marketprice:170,
        offer:"",
        updatequantity:0,
        active:false
     },
     {
         name:"Dark Fantasy",
         quantity:"250 g",
         image:require("../Assets/product2.jpg"),
         salesprice:35,
         marketprice:40,
         offer:4,
         updatequantity:0,
         active:false
     },
     {
         name:"Parasoot oil",
         quantity:"250 L",
         image:require("../Assets/product3.png"),
         salesprice:120,
         marketprice:130,
         offer:8,
         updatequantity:0,
         active:false
     },
     {
         name:"Garnier men face wash",
         quantity:"150 g",
         image:require("../Assets/product4.png"),
         salesprice:90,
         marketprice:110,
         offer:'',
         updatequantity:0,
         active:false
     },
    
     {
         name:"Oreo Biscuit",
         quantity:"20 g",
         image:require("../Assets/product5.jpg"),
         salesprice:25,
         marketprice:30,
         offer:'',
         updatequantity:0,
         active:false
     },
    
     {
         name:"Basmathi Rice",
         quantity:"5 kg ",
         image:require("../Assets/Rice.jpg"),
         salesprice:150,
         marketprice:180,
         offer:'',
         updatequantity:0,
         active:false
     }]
}

const productSlice = createSlice({
  name: 'product',
  initialState,
  reducers: {
    gettopselling: (state, { payload }) => {
       state.topselling=payload
    },
    getrecommended: (state, { payload }) => {
        state.recommended=payload
     },
  },
})

export const {gettopselling,getrecommended} = productSlice.actions
export const productSelector = state => state.product
export default productSlice.reducer