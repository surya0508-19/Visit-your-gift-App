import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import {URL_ABOUT_US, URL_PRODUCTS_DETAILS} from '../Constants.js'
import { fetchsimilarproducts } from './categoriesproduct.js'
import { updatemodel } from './model.js'

export const initialState = {
   productdeail:{},
   attributes:[],
   detailsts:false,
   first_element:{}
}

const productdetailSlice = createSlice({
  name: 'productdetail',
  initialState,
  reducers: {
    getprodetail: (state, { payload }) => {
      state.productdeail = payload.product_details
      state.attributes = payload.product_details.item_variant
      state.first_element = payload.product_details.item_variant[0]

      state.detailsts = false
    },
    updateloader: (state, { payload }) => {
       state.detailsts = payload
    },
  
  },
})

export const {getprodetail,updateloader} = productdetailSlice.actions
export const productdetailSelector = state => state.productdetail
export default productdetailSlice.reducer

export function fetchprodetail(payload) {
  return async dispatch => {
    try {
      // dispatch(updatemodel(true))
      // dispatch(updateloader(true))
      const response =  await axios({
        method:"get",
        url:`${URL_PRODUCTS_DETAILS}`+payload.id,
       })
       
       if(response.data)
       {
          dispatch(getprodetail(response.data))
          var data ={
            cat_id:response.data.product_details.category.id,
            page:1,
            cartdata:payload.cartdata,
            productid:response.data.product_details.id
        }
          dispatch(fetchsimilarproducts(data))
       }
      
    }
    catch(err)
    {
        console.log("error",err)
    } 
  }
}