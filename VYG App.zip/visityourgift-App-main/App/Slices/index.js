import { combineReducers } from 'redux'
import aboutUsReducer from './test';
import countReducer from './count'
import modelReducer from './model';
import productReducer from './product'
import authReducer from './auth'
import profileReducer from './profile'
import homedataReducer from './homedata'
import cartReducer from './cart'
import categoriesproductReducer from './categoriesproduct'
import productdetailReducer from './productdetail'
import addressReducer from './address'
import deliverychargeReducer from './deliverycharge'
import ordersReducer from './orders'
import buyagainReducer from './buyagainlist'
import searchdataReducer from './searchproducts'
import wishlistReducer from './whishlist'
import brandReducer from './brand'
const rootReducer = combineReducers({
    about_us:aboutUsReducer,
    count:countReducer,
    model:modelReducer,
    product:productReducer,
    auth:authReducer,
    profile:profileReducer,
    homedata:homedataReducer,
    cart:cartReducer,
    categoriesproduct:categoriesproductReducer,
    productdetail:productdetailReducer,
    address:addressReducer,
    deliverycharge:deliverychargeReducer,
    orders:ordersReducer,
    searchdata:searchdataReducer,
    buyagain:buyagainReducer,
    wishlist:wishlistReducer,
    brand:brandReducer

})
export default rootReducer;