import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import {URL_ABOUT_US, URL_CAT_PRODUCTS, URL_SEARCH_BRAND} from '../Constants.js'

export const initialState = {
  brands:[],
  brandsts:false,
  active_brand:[]
}

const brandSlice = createSlice({
  name: 'brand',
  initialState,
  reducers: {
    getbrands: (state, { payload }) => {
      state.brands = payload
    },
    updatebrandsts: (state, { payload }) => {
      state.brandsts = payload
    },
    selectbrand: (state, {payload}) => {
       var data=[...state.brands]
       if(data[payload].active)
       {
         data[payload].active =  false
       }
       else
       {
        data[payload].active =  true
       }
       state.brands = data
    },
    activebrand: (state, { payload }) => {
      state.active_brand = payload
    },
    unclearbrand: (state, {payload}) => {
     console.log('before',state.brands)
      var data = [...state.brands]
      const final = data.map(e => {
        if(e.active)
        {
        return({
          id:e.id,
          name:e.name,
          image:e.name,
          active:false
        })
      }
        else
        {
          return({
            id:e.id,
            name:e.name,
            image:e.name,
            active:false
          })
        }
      })
     state.brands = final
     state.active_brand =[]
    },
    deletebrands: (state, {payload}) => {
        state.active_brand=[]
        state.brands=[]
        state.brandsts=false
    }
  },
})

export const {getbrands,updatebrandsts,selectbrand,activebrand,unclearbrand,deletebrands} = brandSlice.actions
export const brandSelector = state => state.brand
export default brandSlice.reducer

export function fetchcatbrand(payload) {
  
  return async dispatch => { 
    try {
      const response =  await axios({
        method:"get",
        url:`${URL_CAT_PRODUCTS}`+'category='+Number(payload)
       })
      if(response.data)
      {
        const brands = response.data.brands.map(e => ({
          id:e.id,
          name:e.name,
          image:e.image,
          active:false
        }))
        dispatch(getbrands(brands))
      }
    }
    catch(err)
    {
        console.log("error",err)
    } 
  }
}

export function searchbrand(payload) {
  
  return async dispatch => { 
    try {
      const response =  await axios({
        method:"get",
        url:`${URL_SEARCH_BRAND}`+'brand_name='+(payload.name)+'category='+Number(payload.id)
       })
      if(response.data)
      {
        // const brands = response.data.brands.map(v => ({ ...v, active:false }))
        console.log("test",response.data)
      }
    }
    catch(err)
    {
        console.log("error",err)
    } 
  }
}