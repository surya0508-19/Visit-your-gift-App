import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_CAT_PRODUCTS } from '../Constants'

export const initialState = {
  categoriesproduct: [],
  catproductsuccess: false,
  max_count: 0,
  current_count: 1,
  switchcatstatus: false,
  similarproducts: [],
  states: []
}

const categoriesproductSlice = createSlice({
  name: 'categoriesproduct',
  initialState,
  reducers: {


    getcatproducts: (state, { payload }) => {
      state.categoriesproduct = payload
      state.catproductsuccess = false
    },

    getstates: (state, { payload }) => {
      state.states = payload

    },
    updatecatproducts: (state, { payload }) => {
      state.categoriesproduct = [...state.categoriesproduct, ...payload]
      state.catproductsuccess = false
    },

    updatecatloader: (state, { payload }) => {
      state.current_count = Number(state.current_count) + Number(1)
      state.catproductsuccess = payload
    },
    updatemaxcount: (state, { payload }) => {
      state.max_count = payload
    },
    upatecatpro_byaddpro: (state, { payload }) => {

      if (payload.key == "increment") {
        var data = [...state.categoriesproduct]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.categoriesproduct = data
      }
      else {
        var data = [...state.categoriesproduct]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.categoriesproduct = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.categoriesproduct = data
        }
      }
    },
    updatepagination: (state, { }) => {
      state.max_count = 0
      state.current_count = 1
      state.categoriesproduct = []
      state.catproductsuccess = false
      state.switchcatstatus = false
      state.switchcatstatus = true
    },
    updatemainloader: (state, { payload }) => {
      state.switchcatstatus = payload
    },
    getsimilarproducts: (state, { payload }) => {
      state.similarproducts = payload
    },
    update_similarpro: (state, { payload }) => {
      if (payload.key == "increment") {
        var data = [...state.similarproducts]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.similarproducts = data
      }
      else {
        var data = [...state.similarproducts]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.similarproducts = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.similarproducts = data
        }
      }
    },
    updatecatpro: (state, { payload }) => {
      state.categoriesproduct = payload
    },
    update_cat_wishlist: (state, { payload }) => {
      if (payload.type == "cat_pro") {
        var data = [...state.categoriesproduct]
        data[payload.index].wishlist = !data[payload.index].wishlist
        state.categoriesproduct = data
      }
      else {
        var find = state.categoriesproduct.findIndex(e => e.product_id == payload.index)
        var data = [...state.categoriesproduct]
        if (find > -1) {
          data[find].wishlist = !data[find].wishlist
          state.categoriesproduct = data
        }

        // console.log("FIND",find)
      }

    }

  },
})

export const { getstates, getcatproducts, updatecatproducts, updatecatloader, updatemaxcount, upatecatpro_byaddpro, updatepagination, updatemainloader, getsimilarproducts, update_similarpro, updatecatpro, update_cat_wishlist } = categoriesproductSlice.actions
export const categoriesproductSliceSelector = state => state.categoriesproduct
export default categoriesproductSlice.reducer

export function fetchcatproducts(payload) {
  console.log("BRAND", payload)
  return async dispatch => {
    if (payload.type == "switch") {
      dispatch(updatepagination())
    }
    try {
      // dispatch(updatemainloader(true))
      const response = await axios({
        method: "get",
        url: `${URL_CAT_PRODUCTS}` + 'category=' + Number(payload.cat_id) + '&page=' + Number(payload.page) + '&country=' + payload.brand + '&state=' + payload.state + '&sort=' + payload.sort,
        headers: {
          Authorization: payload.token
        },
      })

      console.log("ressssssss", response.data.states)

      if (response.data) {
        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })
        if (payload.cartdata.length > 0) {
          var final = data.map(e => {
            var sathish = payload.cartdata.find(f => f.product_id == e.product_id)
            if (sathish != undefined) {
              return sathish
            }
            else {
              return e
            }
          })

          if (Number(payload.page) == 1) {
            dispatch(getcatproducts(final))

          } else {
            dispatch(updatecatproducts(final))
          }

          console.log("FINAL", final)
          dispatch(updatemaxcount(Number(response.data.products.total)))
          dispatch(updatemainloader(false))
          // dispatch(getstates(response.data.states))



        }
        else {

          if (Number(payload.page) == 1) {
            dispatch(getcatproducts(data))

          } else {
            dispatch(updatecatproducts(data))
          }



          dispatch(updatemaxcount(Number(response.data.products.total)))
          dispatch(updatemainloader(false))


        }
        dispatch(getstates(response.data.states))

      }

    }
    catch (err) {
      console.log("catproerror", err)
    }
  }
}

export function fetchsimilarproducts(payload) {

  return async dispatch => {
    try {
      const response = await axios({
        method: "get",
        url: `${URL_CAT_PRODUCTS}` + 'category=' + Number(payload.cat_id) + '&page=' + Number(payload.page)
      })

      if (response.data) {
        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })
        if (payload.cartdata.length > 0) {
          var final = data.map(e => {
            var sathish = payload.cartdata.find(f => f.product_id == e.product_id)
            if (sathish != undefined) {
              return sathish
            }
            else {
              return e
            }
          })

          var findactiveindex = final.findIndex(e => e.product_id == payload.productid)
          if (findactiveindex > -1) {
            final.splice(findactiveindex, 1);
            dispatch(getsimilarproducts(final))
          }
        }
        else {
          var findactiveindex = data.findIndex(e => e.product_id == payload.productid)
          if (findactiveindex > -1) {
            data.splice(findactiveindex, 1);
            dispatch(getsimilarproducts(data))
          }

        }


      }

    }
    catch (err) {
      console.log("error", err)
    }
  }
}