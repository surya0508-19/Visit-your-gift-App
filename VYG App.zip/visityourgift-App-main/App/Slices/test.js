import { createSlice } from '@reduxjs/toolkit'
import {URL_ABOUT_US} from '../Constants.js'

export const initialState = {
  loading: false,
  hasErrors: false,
  about_us: {},
}

const aboutUsSlice = createSlice({
  name: 'about_us',
  initialState,
  reducers: {
    getAboutUs: state => {
      state.loading = true
    },
    getAboutUsSuccess: (state, { payload }) => {
      state.about_us = payload
      state.loading = false
      state.hasErrors = false
    },
    getAboutUsFailure: state => {
      state.loading = false
      state.hasErrors = true
    },
  },
})

export const { getAboutUs, getAboutUsSuccess, getAboutUsFailure } = aboutUsSlice.actions
export const aboutUsSelector = state => state.about_us
export default aboutUsSlice.reducer

export function fetchAboutUs({token}) {
  return async dispatch => {
    dispatch(getAboutUs())
    try {
      
      if(token){
      const response = await fetch(`${URL_ABOUT_US}`, { 
        method: 'GET', 
        headers: new Headers({
          Accept: 'application/json',
          'access-token': `${token}`,
        })
      });
      const data = await response.json()
      
      if(data.code == "200")
        dispatch(getAboutUsSuccess(data.data))
      else
        dispatch(getAboutUsFailure())
    }else{
      const response = await fetch(`${URL_ABOUT_US}`, { 
        method: 'GET', 
        headers: new Headers({
          Accept: 'application/json',
        })
      });
      const data = await response.json()
      
      if(data.code == "200")
        dispatch(getAboutUsSuccess(data.data))
      else
        dispatch(getAboutUsFailure())
    }

    } catch (error) {
      console.error('Reviere: '+error);
      dispatch(getAboutUsFailure())
    }
  }
}
