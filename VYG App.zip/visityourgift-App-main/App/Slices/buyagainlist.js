import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_BUYAGAIN, } from '../Constants.js'

export const initialState = {
  buyagain: [],
  loadersts: false,


}

const buyagaindataSlice = createSlice({
  name: 'buyagain',
  initialState,
  reducers: {
    get_buydata: (state, { payload }) => {
      state.buyagain = payload
      state.loadersts = false
    },

    update_buydata: (state, { payload }) => {

      if (payload.key == "increment") {
        var data = [...state.buyagain]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.buyagain = data
      }
      else {
        var data = [...state.buyagain]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.buyagain = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.buyagain = data
        }
      }
    },
    update_loader: (state, { payload }) => {
      state.loadersts = payload
    },
    update_buy_wishlist: (state, { payload }) => {
      var data = [...state.buyagain]
      data[payload].wishlist = ! data[payload].wishlist
      state.buyagain = data
    },
    update_wish_buy: (state, { payload }) => {
      var data= [...state.buyagain]
      var find= data.findIndex(e => e.product_id == payload)
       if(find > -1)
       {
         data[find].wishlist = !data[find].wishlist
         state.buyagain = data
       }
    }
  },
})

export const { get_buydata, update_buydata, update_loader,update_buy_wishlist,update_wish_buy } = buyagaindataSlice.actions
export const buyagainSlector = state => state.buyagain
export default buyagaindataSlice.reducer



export function fetchbuyproducts(payload,cartdata) {



  return async dispatch => {

    dispatch(update_loader(true))

    try {
      const response = await axios({
        method: "get",
        url: `${URL_BUYAGAIN}`,
        headers: {
          Authorization: payload
        },

      })



      if (response.data) {
        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count:Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count:Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })

        if (cartdata.length > 0) {
          var final = data.map(e => {
            var sathish = cartdata.find(f => f.product_id == e.product_id)
            if (sathish != undefined) {
              return sathish
            }
            else {
              return e
            }
          })
          dispatch(get_buydata(final))


        }
        else {
          dispatch(get_buydata(data))

        }



      }

    }
    catch (err) {
      console.log("error", err)
    }
  }
}


