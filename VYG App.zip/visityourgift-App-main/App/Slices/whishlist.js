import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_ABOUT_US, URL_ADD_TO_WISHLIST, URL_GET_WISHLIST } from '../Constants.js'
import Toast from 'react-native-simple-toast';
export const initialState = {
  wishlist_products: [],
  
}

const wishlistSlice = createSlice({
  name: 'wishlist',
  initialState,
  reducers: {
    getwishlist: (state, { payload }) => {
      state.wishlist_products = payload
    },
    update_wishlist: (state, { payload }) => {

      if (payload.key == "increment") {
        var data = [...state.wishlist_products]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.wishlist_products = data
      }
      else {
        var data = [...state.wishlist_products]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.wishlist_products = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.wishlist_products = data
        }
      }
    },
    update_wishlistpro: (state, { payload }) => {
       var data = [...state.wishlist_products]
       if (payload.index > -1) {
        data.splice(payload.index, 1);
        state.wishlist_products = data
      }
    },
    
  },
})

export const { getwishlist, update_wishlist ,update_wishlistpro} = wishlistSlice.actions
export const wishlistSelector = state => state.wishlist
export default wishlistSlice.reducer

export function fetchwishlistproducts(token, cartdata) {
  return async dispatch => {
    try {
      const response = await axios({
        method: "get",
        url: `${URL_GET_WISHLIST}`,
        headers: {
          Authorization: token
        }
      })
console.log("bbbb",response.data.whishlist)
      
      var data = response.data.whishlist.map(e => {
        if (e.item.item_variant[0].offer_price) {
          return ({
            productname: e.item.name,
            product_id: e.item.id,
            variant_id: e.item.variant_id,
            image: e.item.image,
            variant_count: Number(e.item.item_variant_count),
            variant_value: e.item.item_variant[0].variant_value,
            actual_qty: Number(e.item.item_variant[0].actual_quantity),
            wishlist: e.item.is_already_in_wish_list,
            price: Number(e.item.item_variant[0].price),
            offer_price: Number(e.item.item_variant[0].offer_price),
            discount: Number(e.item.item_variant[0].discount),
            qty: Number(0),
            check: false,

          })
        }
        else {
          return ({
            productname: e.item.name,
            product_id: e.item.id,
            variant_id: e.item.variant_id,
            image: e.item.image,
            variant_count: Number(e.item.item_variant_count),
            variant_value: e.item.item_variant[0].variant_value,
            actual_qty: Number(e.item.item_variant[0].actual_quantity),
            wishlist: e.item.is_already_in_wish_list,
            price: Number(e.item.item_variant[0].price),
            offer_price: Number(0),
            discount: Number(e.item.item_variant[0].discount),
            qty: Number(0),
            check: false,
          })
        }
      })

      if (cartdata.length > 0) {
        var final = data.map(e => {
          var sathish = cartdata.find(f => f.product_id == e.product_id)
          if (sathish != undefined) {
            return sathish
          }
          else {
            return e
          }
        })

        console.log("fuck", final)
        dispatch(getwishlist(final))
      }
      else {
        dispatch(getwishlist(data))
      }

      //  console.log("Test",response.data)

    }
    catch (err) {
      console.log("wishlisterrr", err)
    }

  }
}

export function Addwishlist(payload) {
  console.log("PAYLOAD",payload)
  return async dispatch => {
    try {
      const response = await axios({
        method: "post",
        url: `${URL_ADD_TO_WISHLIST}` + payload.id,
        headers: {
          Authorization: payload.token
        }
      })
      if (response.data) {
        if (payload.type == "add") {
          Toast.show('Product added to wishlist', Toast.SHORT);
        }
        else {
          Toast.show('Product removed from wishlist', Toast.SHORT);
        }

      }


    }
    catch (err) {
      console.log("wishlisterr", err)
    }
  }

}


export function deletewishlist(payload) {
  console.log("payload", payload)
  return async dispatch => {
    try {
      const response = await axios({
        method: "delete",
        url: `${URL_ADD_TO_WISHLIST}` + payload.id,
        headers: {
          Authorization: payload.token
        }
      })
      if (response.data) {
        Toast.show('Product removed from wishlist', Toast.SHORT);
      }


    }
    catch (err) {
      console.log("error", err)
    }
  }

}