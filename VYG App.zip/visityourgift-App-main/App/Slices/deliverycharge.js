import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_ABOUT_US, URL_DELIVERYCHARGE } from '../Constants.js'
// import Toast from 'react-native-simple-toast';

export const initialState = {
  delivery: {},
  deliverystatus: false,
  minimum_charge: 0,
  loadersts:false,
  success:false,
  delivery_settings:{}
}

const deliverychargeSlice = createSlice({
  name: 'deliverycharge',
  initialState,
  reducers: {
    getdelivery: (state, { payload }) => {
      state.delivery = payload
      state.delivery_settings = payload.delivery_settings
      state.loadersts = false
    },
    update_del_sts: (state, { payload }) => {
      state.deliverystatus = payload
    },
    getminmun_amt: (state, { payload }) => {
      state.minimum_charge = payload
    },

    update_loader: (state, { payload }) => {
      state.loadersts = payload
    },
    update_sucess: (state, { payload }) => {
      state.success = payload
    }
  },
})

export const { getdelivery, update_del_sts, getminmun_amt,update_loader,update_sucess } = deliverychargeSlice.actions
export const deliverychargeSelector = state => state.deliverycharge
export default deliverychargeSlice.reducer

export function fetchdeivery(payload) {
  // console.log("token",payload)
  return async dispatch => {

    
    try {
      const response = await axios({
        method: "get",
        url: `${URL_DELIVERYCHARGE}`,
        headers: {
          Authorization: payload
        },
      })


      console.log("ress", response.data)

      if (response.data) {
        dispatch(update_sucess(true))

        dispatch(getdelivery(response.data))
        dispatch(getminmun_amt(response.data.minimum_delivery_charge))
 


      }

    }
    catch (err) {
      console.log("error", err)
      console.log("response==>error", err.response.data.toast_message)
      dispatch(getminmun_amt(0))
    // dispatch(update_loader(true))
    // Toast.show( err.response.data.toast_message, Toast.SHORT);

    dispatch(update_sucess(false))
    


    }
  }
}