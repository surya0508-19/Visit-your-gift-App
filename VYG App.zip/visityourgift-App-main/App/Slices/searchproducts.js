import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_PRODUCTSEARCHLIST, URL_TOP_BRANDS, URL_BRANDLIST } from '../Constants.js'

export const initialState = {
  seaching: [],
  brandlist: [],
  nodata: true,
  loadersts: false,


}

const searchdataSlice = createSlice({
  name: 'searchdata',
  initialState,
  reducers: {
    get_searchdata: (state, { payload }) => {
      state.seaching = payload
      state.loadersts = false
      // state.nodata = payload

    },
    get_branddata: (state, { payload }) => {
      state.brandlist = payload
      state.loadersts = false
    },

    update_seachdata: (state, { payload }) => {

      if (payload.key == "increment") {
        var data = [...state.seaching]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.seaching = data
      }
      else {
        var data = [...state.seaching]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.seaching = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.seaching = data
        }
      }
    },
    update_loader: (state, { payload }) => {
      state.loadersts = payload
    },

    update_nodata: (state, { payload }) => {

      state.nodata = payload
    },
    update_ser_wishlist: (state, { payload }) => {
      var data = [...state.seaching]
      data[payload].wishlist = !data[payload].wishlist
      state.seaching = data
    },
    update_search_wishlist: (state, { payload }) => {
      var data = [...state.seaching]
      var find = data.findIndex(e => e.product_id == payload)
      console.log("FIND0", find)
      if (find > -1) {
        data[find].wishlist = !data[find].wishlist
        state.seaching = data
      }
    }
  }
})

export const { get_searchdata, update_seachdata, update_loader, get_branddata, update_nodata, update_ser_wishlist, update_search_wishlist } = searchdataSlice.actions
export const searchdataSlector = state => state.searchdata
export default searchdataSlice.reducer



export function fetchsearchproducts(cartdata, text, token) {

  return async dispatch => {

    dispatch(update_loader(true))

    try {
      const response = await axios({
        method: "get",
        url: `${URL_PRODUCTSEARCHLIST}` + text,
        headers: {
          Authorization: token
        }
      })

      // console.log("responsedata",response.data.products.data)

      //  dispatch(get_searchdata(response.data.products.data))

      if (response.data) {
        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })

        if (cartdata.length > 0) {
          var final = data.map(e => {
            var sathish = cartdata.find(f => f.product_id == e.product_id)
            if (sathish != undefined) {
              return sathish
            }
            else {
              return e
            }
          })

          //  console.log("finallll", final)

          if (final == "") {

            dispatch(update_nodata(true))

          }
          else {

            dispatch(update_nodata(false))

          }
          dispatch(get_searchdata(final))
        }
        else {
          // console.log("data", data)


          if (data == "") {

            dispatch(update_nodata(true))

          }
          else {

            dispatch(update_nodata(false))

          }

          dispatch(get_searchdata(data))
        }


      }

    }
    catch (err) {
      console.log("search error", err)
    }
  }
}


export function fetchbrandproducts(country, cartdata, token) {



  return async dispatch => {

    dispatch(update_loader(true))

    try {
      const response = await axios({
        method: "get",
        url: `${URL_BRANDLIST}` + country,
        headers: {
          Authorization: token
        }
      })

      console.log("responsedata ccccc",response.data.products)

      //  dispatch(get_searchdata(response.data.products.data))

      if (response.data) {
        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count: Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })

        if (cartdata.length > 0) {
          var final = data.map(e => {
            var sathish = cartdata.find(f => f.product_id == e.product_id)
            if (sathish != undefined) {
              return sathish
            }
            else {
              return e
            }
          })


          if (final == "") {

            dispatch(update_nodata(true))

          }
          else {

            dispatch(update_nodata(false))

          }
          dispatch(get_searchdata(final))
        }
        else {


          if (data == "") {

            dispatch(update_nodata(true))

          }
          else {

            dispatch(update_nodata(false))

          }
          dispatch(get_searchdata(data))
        }


      }

    }
    catch (err) {
      console.log("error", err)
    }
  }
}

export function fetchtopbrands(cart_products, token) {



  return async dispatch => {



    try {
      const response = await axios({
        method: "get",
        url: `${URL_TOP_BRANDS}`
      })

      console.log("TOPBRANDS", response.data)

      dispatch(get_branddata(response.data.top_brands))
      console.log("response.data.top_brands[0].id", response.data.top_brands[0].id)

      // dispatch(fetchbrandproducts(response.data.top_brands[0].id, cart_products, token))


    }
    catch (err) {
      console.log("error", err)
    }
  }
}


