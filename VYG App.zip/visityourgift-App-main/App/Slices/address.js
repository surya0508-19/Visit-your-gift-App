import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import {URL_ABOUT_US, URL_ACTIVE_ADDRESS, URL_ADDRESS_LIST, URL_EDIT_ADDRESS} from '../Constants.js'
import Toast from 'react-native-simple-toast';
import { fetchdeivery } from './deliverycharge.js';
export const initialState = {
    address_list:[],
    add_status:false,
    err:false
}

const addressSlice = createSlice({
  name: 'address',
  initialState,
  reducers: {
    getaddress: (state, { payload }) => {
       state.address_list = payload
       state.add_status = false
    },
    updateaddress: (state, { payload }) => {
        state.add_status = payload
     },
     updateerr: (state, { payload }) => {
        state.err = payload
     },
  },
})

export const { getaddress,updateaddress,updateerr} = addressSlice.actions
export const addressSelector = state => state.address
export default addressSlice.reducer

export function fetchaddress(payload) {
    return async dispatch => {
      try {
        const response =  await axios({
          method:"get",
          url:`${URL_ADDRESS_LIST}`,
          headers: {
            Authorization:payload
        },
         })

        
       if(response.data)
       {
          var data = response.data.address.map(e =>{
            if(e.status == "Active") 
            {
                return({
                    id:e.id,
                    address1:e.address1,
                    address2:e.address2,
                    state:e.state,
                    city:e.city,
                    zipcode:e.zipcode,
                    type:e.type,
                    status:true
                })
            }
            else
            {
                return({
                    id:e.id,
                    address1:e.address1,
                    address2:e.address2,
                    state:e.state,
                    city:e.city,
                    zipcode:e.zipcode,
                    type:e.type,
                    status:false
                })
            }
               

          })
          dispatch(getaddress(data))
       }
        
      }
      catch(err)
      {
          console.log("error",err)
      } 
    }
  }

  
export function addaddress(payload) {
    return async dispatch => {
      try {
        const response =  await axios({
          method:"post",
          url:`${URL_ADDRESS_LIST}`,
          data:payload.data,
          headers: {
            Authorization:payload.token
        },
         })
       if(response.data)
       {
          dispatch(updateaddress(true))
          dispatch(fetchaddress(payload.token))
          dispatch(fetchdeivery(payload.token))

          Toast.show("Address added successfully!!", Toast.SHORT);
       }
        
      }
      catch(err)
      {
          console.log("error",err)
          dispatch(updateerr(true))
      } 
    }
  }

  export function setactiveaddress(payload) {
    return async dispatch => {
      try {
        const response =  await axios({
          method:"post",
          url:`${URL_ACTIVE_ADDRESS}`+payload.id,
          headers: {
            Authorization:payload.token
        },
         })
       if(response.data)
       {
          dispatch(updateaddress(true))
          dispatch(fetchdeivery(payload.token))
          Toast.show("Address changed successfully!!", Toast.SHORT);
        //   dispatch(fetchaddress(payload.token))
       }
        
      }
      catch(err)
      {
          console.log("error",err)
          dispatch(updateerr(true))
      } 
    }
  }

  export function editaddress(payload) {
    return async dispatch => {
      try {
        const response =  await axios({
          method:"put",
          url:`${URL_EDIT_ADDRESS}`+payload.id,
          data:payload.data,
          headers: {
            Authorization:payload.token
        },
         })
       if(response.data)
       {
          dispatch(updateaddress(true))
          dispatch(fetchaddress(payload.token))
          dispatch(fetchdeivery(payload.token))

          Toast.show("Address edited successfully!!", Toast.SHORT);
       }
        
      }
      catch(err)
      {
          console.log("error",err)
          dispatch(updateerr(true))
      } 
    }
  }

  export function deleteaddress(payload) {
    return async dispatch => {
      try {
        const response =  await axios({
          method:"delete",
          url:`${URL_EDIT_ADDRESS}`+payload.id,
          headers: {
            Authorization:payload.token
        },
         })
       if(response.data)
       {
          dispatch(updateaddress(true))
          dispatch(fetchaddress(payload.token))
          dispatch(fetchdeivery(payload.token))
          Toast.show("Address deleted Successfully!!", Toast.SHORT);
       }
        
      }
      catch(err)
      {
          console.log("error",err)
          dispatch(updateerr(true))

          
      } 
    }
  }