import { createSlice } from '@reduxjs/toolkit'
import {URL_ABOUT_US} from '../Constants.js'

export const initialState = {
   modelshow:false,
   type:'',
   active_wishlist:false
}

const modelSlice = createSlice({
  name: 'model',
  initialState,
  reducers: {
    updatemodel: (state, { payload}) => {
       state.modelshow=payload.status
       state.type=payload.type
       state.active_wishlist=payload.wishlist

    },
    
    
  },
})

export const {updatemodel} = modelSlice.actions
export const modelSelector = state => state.model
export default modelSlice.reducer