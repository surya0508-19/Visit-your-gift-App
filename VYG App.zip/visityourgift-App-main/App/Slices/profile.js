import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_GETPROFILE, URL_NOTIFICATION_LIST, URL_UPDATEPROFILE } from '../Constants'

import Toast from 'react-native-simple-toast';
export const initialState = {
  profile:{},
  proupdatestatus:false,
  NotificationList:[]
}

const profileSlice = createSlice({
  name: 'profile',
  initialState,
  reducers: {
    getprofile: (state, { payload }) => {
      state.profile = payload
    },
    update_profile: (state, { payload }) => {
        state.proupdatestatus = payload
      },
      getNotificationList: (state, { payload }) => {
        state.NotificationList = payload
  
      },
  },
})

export const {getprofile,update_profile,getNotificationList} = profileSlice.actions
export const profileSelector = state => state.profile
export default profileSlice.reducer

export function fetchprofile(payload) {
  
    return async dispatch => {
      try {
        const response =  await axios({
          method:"get",
          url:`${URL_GETPROFILE}`,
          headers: {
            Authorization: payload
        },
         })
         if(response.data)
         {
           dispatch(getprofile(response.data.user_details))
         
         }
        
      }
      catch(err)
      {
          console.log("error",err)
      } 
    }
  }


  export function getnotificationlist(payload) {
    // console.log(payload, "payloadpayload")
    return async dispatch => {
      try {
  
        const response = await axios({
            method: "get",
            url: `${URL_NOTIFICATION_LIST}`,
            headers: {
                Authorization:payload
            },
  
        })
      // console.log("rrrrrrrrrrrrrrrrrrr", response.data)
        dispatch(getNotificationList(response.data.notifications))
  
       
    }
    catch (errr) {
        console.log("err", errr)
       
  
    }
    }
  }

  export function updateuserprofile(payload) {
  
    return async dispatch => {
      try {
        const response =  await axios({
          method:"post",
          url:`${URL_UPDATEPROFILE}`,
          headers: {
            Authorization: payload.token
        },
         data:payload.data
         })


         if(response.data)
         {
         console.log("ress",response.data)

            dispatch(update_profile(true))
           dispatch(fetchprofile(payload.token))
          
         }
        
      }
      catch(err)
      {
          console.log("error",err.response.data)
          Toast.show( err.response.data.toast_message, Toast.SHORT);

      } 
    }
  }