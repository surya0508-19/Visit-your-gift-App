import { createSlice } from '@reduxjs/toolkit'
import {URL_ABOUT_US} from '../Constants.js'

export const initialState = {
  loading: false,
  hasErrors: false,
  count:{
      cartlength:0,
      price:0
  }
}

const countSlice = createSlice({
  name: 'count',
  initialState,
  reducers: {
    getcount: (state, { payload }) => {
      state.count.cartlength = payload.cartcount
      state.count.price=payload.cartprice
    },
  
  },
})

export const { getcount} = countSlice.actions
export const countSelector = state => state.count
export default countSlice.reducer