import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'
import { URL_ABOUT_US, URL_HOME_DATA, URL_RECOMMENDED_PRODUCTS, URL_TOP_SELLING } from '../Constants.js'
import Toast from 'react-native-simple-toast';
export const initialState = {
  categories: [],
  topselling: [],
  recommended: [],
  active_category: {},
  loadersts: false,
  categorycount:9,
}

const homedataSlice = createSlice({
  name: 'homedata',
  initialState,
  reducers: {
    get_categories: (state, { payload }) => {
      state.categories = payload

    },
    get_categoriescount: (state, { payload }) => {
      state.categorycount = payload

    },
    get_topselling: (state, { payload }) => {
      state.topselling = payload
      state.loadersts = false
    },
    get_recommended: (state, { payload }) => {
      state.recommended = payload
      state.loadersts = false
    },
    upate_topselling: (state, { payload }) => {

      if (payload.key == "increment") {
        var data = [...state.topselling]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.topselling = data
      }
      else {
        var data = [...state.topselling]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.topselling = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.topselling = data
        }
      }
    },
    upate_recommended: (state, { payload }) => {

      if (payload.key == "increment") {
        var data = [...state.recommended]
        data[payload.value].check = true
        data[payload.value].qty = Number(data[payload.value].qty) + Number(1)
        state.recommended = data
      }
      else {
        var data = [...state.recommended]
        if (data[payload.value].qty == 1) {
          data[payload.value].check = false
          data[payload.value].qty = Number(0)
          state.recommended = data
        }
        else {
          data[payload.value].check = true
          data[payload.value].qty = Number(data[payload.value].qty) - Number(1)
          state.recommended = data
        }
      }
    },
    select_category: (state, { payload }) => {
      state.categories = payload
    },
    switch_cat_head: (state, { payload }) => {
      state.active_category = payload
    }
    ,
    update_loader: (state, { payload }) => {
      state.loadersts = payload
    },

    update_top_wishlist: (state, { payload }) => {
       if(payload.key == "topselling")
       {
           var data = [...state.topselling]
           data[payload.index].wishlist = ! data[payload.index].wishlist
           state.topselling = data
       }
       else
       {
           var data = [...state.recommended]
           data[payload.index].wishlist = ! data[payload.index].wishlist
           state.recommended = data
       }
    },
  },
})

export const {get_categoriescount, get_categories, get_topselling, get_recommended, upate_topselling, upate_recommended, select_category, switch_cat_head, update_loader,update_top_wishlist} = homedataSlice.actions
export const homedataSelector = state => state.homedata
export default homedataSlice.reducer

export function fetchhomedata() {

  return async dispatch => {

    try {
      const response = await axios({
        method: "get",
        url: `${URL_HOME_DATA}`
      })
      if (response.data) {
        dispatch(get_categories(response.data.categories))
      }

    }
    catch (err) {
      console.log("error", err)
    }
  }
}

export function fetchctopseling(cartdata,token) {
  console.log("token",token)
  return async dispatch => {
    dispatch(update_loader(true))
    try {
      
      const response = await axios({
        method: "get",
        url: `${URL_TOP_SELLING}`,
        headers: {
          Authorization: token
        },
      })

   
// console.log("Ressss",response.data.products.data)

      if (response.data) {

        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count:Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count:Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })


        // console.log("carrttt", cartdata)
        if (cartdata == undefined) {

          dispatch(get_topselling(data))

        }
        else {

          if (cartdata.length > 0) {
            var final = data.map(e => {
              var sathish = cartdata.find(f => f.product_id == e.product_id)
              if (sathish != undefined) {
                return sathish
              }
              else {
                return e
              }
            })
            dispatch(get_topselling(final))
          }
          else {


            dispatch(get_topselling(data))
          }


        }
      }

    }
    catch (err) {
      console.log("error", err)
    }
  }
}

export function fetchrecommended(cartdata,token) {

  return async dispatch => {
    dispatch(update_loader(true))
    try {
      const response = await axios({
        method: "get",
        url: `${URL_RECOMMENDED_PRODUCTS}`,
        headers: {
          Authorization: token
        },
      })
      if (response.data) {
        var data = response.data.products.data.map(e => {
          if (e.item_variant[0].offer_price) {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count:Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(e.item_variant[0].offer_price),
              discount: Number(e.item_variant[0].discount),
              qty: Number(0),
              check: false,

            })
          }
          else {
            return ({
              productname: e.name,
              product_id: e.id,
              variant_id: e.variant_id,
              image: e.image,
              variant_count:Number(e.item_variant_count),
              variant_value: e.item_variant[0].variant_value,
              actual_qty: Number(e.variant_quantity),
              wishlist: e.is_already_in_wish_list,
              price: Number(e.item_variant[0].price),
              offer_price: Number(0),
              qty: Number(0),
              discount: Number(0),
              check: false
            })
          }
        })
        if (cartdata == undefined) {

          dispatch(get_recommended(data))

        }
        else {


          if (cartdata.length > 0) {
            var final = data.map(e => {
              var sathish = cartdata.find(f => f.product_id == e.product_id)
              if (sathish != undefined) {

                return sathish

                
              }
              else {
                return e
              }
            })
            dispatch(get_recommended(final))
          }
          else {
            dispatch(get_recommended(data))
          }
        }
      }
    }
    catch (err) {
      console.log("error", err)
    }
  }
}

