

// const BASE_URL = "http://www.visityourgift.com/admin/api/";
// export const IMAGE_URL_CATEGORY = "http://www.visityourgift.com/admin/onlineGrocery/category/";
// export const IMAGE_URL_PRODUCTS = "http://www.visityourgift.com/admin/onlineGrocery/products/";
// export const IMAGE_URL_BRANDS = "http://www.visityourgift.com/admin/onlineGrocery/brands/";

// export const IMAGE_URL_PROFILE = "http://www.visityourgift.com/admin/onlineGrocery/userprofiles/";

export const PAYAPAL_URL = "http://phpstack-1231498-4714101.cloudwaysapps.com/";


const BASE_URL = "https://phpstack-1231498-4714101.cloudwaysapps.com/api/";
export const IMAGE_URL_CATEGORY = "https://phpstack-1231498-4714101.cloudwaysapps.com/onlineGrocery/category/";
export const IMAGE_URL_PRODUCTS = "https://phpstack-1231498-4714101.cloudwaysapps.com/onlineGrocery/products/";
export const IMAGE_URL_BRANDS = "https://phpstack-1231498-4714101.cloudwaysapps.com/onlineGrocery/brands/";

export const IMAGE_URL_PROFILE = "https://phpstack-1231498-4714101.cloudwaysapps.com/onlineGrocery/userprofiles/";



export const URL_LOGIN = `${BASE_URL}login`;
export const URL_SIGNUP = `${BASE_URL}register`;
export const URL_ENQUIRY = `${BASE_URL}enquiry`;

export const URL_GETPROFILE = `${BASE_URL}get_profile`;
export const URL_UPDATEPROFILE = `${BASE_URL}update_profile`;
export const URL_DELIVERYCHARGE = `${BASE_URL}get_delivery_charge`;


export const URL_POINTS = `${BASE_URL}user-reward-histories`;


export const URL_FCM_TOKEN = `${BASE_URL}firebase_token`;
export const URL_NOTIFICATION_LIST = `${BASE_URL}notification`;

export const URL_CHANGE_PASSWORD = `${BASE_URL}update_password`;
export const URL_HOME_DATA = `${BASE_URL}home?`;
export const URL_TOP_SELLING = `${BASE_URL}top_selling_products`;
export const URL_RECOMMENDED_PRODUCTS = `${BASE_URL}recomended_products`;
export const URL_ADD_TO_CART = `${BASE_URL}cart`;
export const URL_ADD_TO_CART1 = `${BASE_URL}cart/mobile`;
export const URL_CART_LIST = `${BASE_URL}cart`;
export const URL_ADD_TO_WISHLIST = `${BASE_URL}user_whishlist/`;
export const URL_GET_WISHLIST = `${BASE_URL}user_whishlist`;
export const URL_DELETE_WISHLIST = `${BASE_URL}user_whishlist/`;
export const URL_PRODUCTS_DETAILS = `${BASE_URL}product_details/`;
export const APPLYCOUPON = `${BASE_URL}coupon/`;
export const GETUSERACTIVEADDRESS = `${BASE_URL}user_address/active`;
export const URL_ADD_ADDRESS = `${BASE_URL}user_address`;
export const URL_GET_ADDED_ADDRESS = `${BASE_URL}user_address`;
export const URL_DELETE_ADDED_ADDRESS = `${BASE_URL}user_address/`;
export const URL_EDIT_ADDED_ADDRESS = `${BASE_URL}user_address/`;
export const URL_GET_EDIT_ADDED_ADDRESS = `${BASE_URL}user_address/`;
export const URL_SET_USER_ACTIVE = `${BASE_URL}user_address/set/`;
export const URL_ORDERLIST = `${BASE_URL}order`;
export const URL_ORDERDETAIL = `${BASE_URL}order/`;
export const URL_PRODUCTSEARCHLIST = `${BASE_URL}product_search/`;
export const URL_TOP_BRANDS = `${BASE_URL}product_search_history`;
export const URL_BRANDLIST = `${URL_HOME_DATA}country=`;
export const URL_BUYAGAIN = `${BASE_URL}buy_again`;
export const URL_BRANDFILTERCB = `${BASE_URL}home`;
export const URL_BRANDFILTER = `${BASE_URL}brand_filter`;
export const URL_PLACEORDER = `${BASE_URL}order`;
export const URL_ORDERAGAIN = `${BASE_URL}order_again/`;
export const URL_TERMS = `${BASE_URL}terms_and_conditions`;
export const URL_POLICY = `${BASE_URL}privacy_policy`;
export const URL_CANCEL_ORDER = `${BASE_URL}order/cancel/`;

export const URL_ADDRESS_LIST = `${BASE_URL}user_address`;
export const URL_ACTIVE_ADDRESS = `${BASE_URL}user_address/set/`;
export const URL_EDIT_ADDRESS = `${BASE_URL}user_address/`;

export const URL_CAT_PRODUCTS = `${BASE_URL}home?`;

export const URL_INVOICE = `${BASE_URL}order/download_invoice/`;

export const URL_FORGET_PASSWORD = `${BASE_URL}forgot_password/`;
// export const URL_FORGET_PASSWORD1 = `${BASE_URL}/forgot_password/`;





