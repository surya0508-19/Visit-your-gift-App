import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, ImageBackground, StatusBar, StyleSheet, ActivityIndicator } from 'react-native';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';
import { Card } from 'react-native-shadow-cards';
import Helperhome from '../../Components/helperhome';
import Homeproducts from '../../Components/Homeproducts';
import Productdetail from '../../Components/productdetail';
import { Recommendedproduct } from '../TestData/data';
import { profileSelector } from '../../Slices/profile';
import { useSelector } from 'react-redux';

const { width, height } = Dimensions.get("window")
export default function Header(props) {
    const { NotificationList } = useSelector(profileSelector)

    return (
        <View style={styles.header} >
            <View style={{ width: "15%", height: "100%", justifyContent: "center" }}  >
                <TouchableOpacity onPress={() => props.Back()}  >
                    <Image style={styles.back} source={require("../../Assets/back.png")} />
                </TouchableOpacity>
            </View>
            <View style={{ width: "65%", height: "100%", justifyContent: "center", }} >
                <Text style={styles.text1} >{props.dataParentToChild.name}</Text>
            </View>
            {props.dataParentToChild.name == "Notifications" && NotificationList.length ?
                <TouchableOpacity onPress={() => props.clear()} style={{ right: 10, width: "20%", height: "60%", alignItems: 'center', backgroundColor: "#3ba5df", borderRadius: width * 0.015, justifyContent: "center" }} >
                    {props.dataParentToChild.search == false ?
                        <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.04, color: "white", textAlign: "center" }} >Clear</Text>
                        :
                        <ActivityIndicator size={20} color="white"></ActivityIndicator>
                    }
                </TouchableOpacity>
                : null}
            {/* {props.dataParentToChild.search ? 
    <View style={{width:"15%",height:"100%",justifyContent:"center"}}  >
    <TouchableOpacity onPress={() => props.Back()}  >
    <Image style={styles.search} source={require("../../Assets/search.png")} />
    </TouchableOpacity>
    </View>:null} */}
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,

    },
    header: {
        width: "100%",
        height: height * 0.075,
        backgroundColor: "white",
        flexDirection: "row",
        alignItems: "center"
    },
    back: {
        width: width * 0.05,
        height: height * 0.03,
        alignSelf: "center",
    },
    text1: {
        fontSize: width * 0.0475,
        // fontWeight:"600",
        color: "black",
        // marginLeft:"5%",
        fontFamily: "Roboto-Bold"
    },
    text2: {
        fontSize: width * 0.0425,
        textAlign: "center",
        marginTop: "5%",
        fontFamily: "Roboto-Light",
        fontWeight: "600"
    },
    text3: {
        fontSize: width * 0.0425,
        textAlign: "center",
        fontFamily: "Roboto-Bold"
    },
    otp_container: {
        width: "60%",
        height: height * 0.1,
        alignSelf: "center",
        alignItems: "center",
        justifyContent: "space-around",
        marginTop: "10%",
        flexDirection: "row"
    },
    box_container: {
        width: "20%",
        height: "67.5%",
        borderRadius: width * 0.02,
        borderWidth: width * 0.003,
        borderColor: 'black'
    },
    box_container1: {
        width: "20%",
        height: "67.5%",
        borderRadius: width * 0.02,
        borderWidth: width * 0.003,
        borderColor: 'gray'
    },
    text4: {
        fontSize: width * 0.0425,
        textAlign: "center",
        fontWeight: "700",
        color: "#D3D3D3",
        marginTop: "5%",
        fontFamily: "Roboto-Light",
    },
    search: {
        width: 20,
        height: 20,
        alignSelf: "center",
        resizeMode: "contain"
    },
})
