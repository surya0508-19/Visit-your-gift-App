import React, { useState, useEffect, Component } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, SafeAreaView, Alert, Linking } from 'react-native';
import { ScrollView, TextInput } from 'react-native-gesture-handler';
import styles from './style';
import LinearGradient from 'react-native-linear-gradient';
import { Card } from 'react-native-shadow-cards';
import Statusbar from '../../Screens/Statusbar/index';
import Helper from '../../Components/helper';
import { useDispatch, useSelector } from 'react-redux';
import { removeaccesstoken, authSelector } from '../../Slices/auth';
// import { fetchhome } from '../../Slices/fetchhome';
import { fetchctopseling, fetchhomedata, fetchrecommended } from '../../Slices/homedata';

import { fetchtopbrands } from '../../Slices/searchproducts';


import AsyncStorage from '@react-native-async-storage/async-storage';
import { fetchprofile, getNotificationList, profileSelector } from '../../Slices/profile';
import { IMAGE_URL_PROFILE, IMAGE_URL_PRODUCTS } from '../../Constants';
import { cart_empty } from '../../Slices/cart';


export function DrawerMenu(props) {
    const dispatch = useDispatch()
    const { width, height } = Dimensions.get("window")
    const { profile } = useSelector(profileSelector)

    const { token } = useSelector(authSelector)




    const data = "white"
    const wishlist = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Wishlist')
    }

    const myorders = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Myorders')
    }
    const buyagain = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Buyagain')
    }

    const myaccount = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('MyAccount')
    }
    const Invite = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('InviteFriends')
    }
    const Setting = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Address')
    }

    const Terms = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Terms')
    }
    const policy = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Privacy')
    }
    const Contact = () => {
        props.navigation.closeDrawer();
        props.navigation.navigate('Settings')
    }
    const logout = () => {
        Alert.alert('Logout !', 'Do you want to logout', [
            {
                text: 'Cancel',
                onPress: () => console.log('Cancel Pressed'),
                style: 'cancel',
            },
            {
                text: 'OK', onPress: () => {
                    props.navigation.closeDrawer()
                    dispatch(fetchhomedata())
                    dispatch(fetchctopseling())
                    dispatch(fetchrecommended())
                    dispatch(fetchprofile(token))
                    dispatch(fetchtopbrands())
                    dispatch(getNotificationList([]))
                    dispatch(removeaccesstoken(''))
                    AsyncStorage.removeItem("Token")
                    dispatch(cart_empty())
                    props.navigation.navigate('Sidemenu')

                }

            },
        ]);
    }

    const login = () => {
        props.navigation.navigate('login')



    }
    // alert(profile.image)
    return (
        <SafeAreaView style={styles.container} >
            <Statusbar dataParentToChild={data} />
            {/* <Helper /> */}

            {token ?
                <View style={{ width: "100%", height: "25%", backgroundColor: "#00a4ff", justifyContent: "center" }} >
                    <View style={{ flexDirection: "row", width: "100%", height: "50%", }} >
                        <View style={{ width: "35%", height: 100, alignItems: "center" }} >
                            <View style={{ height: 67, width: (Platform.OS === 'ios') ? "70%" : "70%", borderRadius: 100, alignSelf: "center", resizeMode: "contain", borderWidth: width * 0.004, borderColor: "#00a4ff", backgroundColor: "white", justifyContent: "center" }} >
                                {!profile.image ?
                                    <Image style={{ width: "90%", height: "90%", borderRadius: 100, alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/boss.png")} />
                                    :
                                    <Image style={{ width: "90%", height: "90%", borderRadius: 100, alignSelf: "center", resizeMode: "contain", }} source={{ uri: IMAGE_URL_PROFILE + profile.image }} />
                                }
                            </View>
                        </View>
                        <View style={{ width: "65%", }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.055, marginLeft: "2.5%", color: "white" }} >{profile.fname}</Text>
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.055, marginLeft: "2.5%", color: "white" }} >{profile.lname}</Text>
                        </View>
                    </View>
                    <Text style={{ fontFamily: "Roboto-Regular", fontSize: width * 0.045, marginLeft: "5%", color: "white" }} >{profile.email}</Text>
                </View>
                :

                <View style={{ width: "100%", height: "25%", backgroundColor: "#00a4ff", justifyContent: "center" }} >
                    <View style={{ flexDirection: "row", width: "100%", height: 100, alignItems: "center" }} >
                        <View style={{ width: "35%", }} >
                            <View style={{ height: 65, width: (Platform.OS === 'ios') ? "70%" : "70%", borderRadius: 100, alignSelf: "center", resizeMode: "contain", borderWidth: width * 0.004, borderColor: "grey", backgroundColor: "white", justifyContent: "center" }} >

                                <Image style={{ width: "90%", height: "90%", borderRadius: 100, alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/visit-your-gift.png")} />

                            </View>
                        </View>
                        <View style={{ height: 65, width: "60%", justifyContent: "center", marginTop: 5 }} >
                            {/* <Image style={{ width: "90%", height: "85%",  alignSelf: "center", resizeMode: "contain",borderRadius: 5, }} source={require("../../Assets/logo.png")} /> */}
                            <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.05, marginLeft: "5%", color: "white" }} >Visit Your Gift</Text>

                        </View>
                    </View>
                    <TouchableOpacity onPress={() => Linking.openURL('tel:866-868-8365')}>
                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, marginLeft: "5%", color: "white" }} >866-868-8365</Text>

                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => Linking.openURL('mailto: info@snacksballoon.com')}>
                        <Text style={{ fontFamily: "Roboto-Bold", fontSize: width * 0.045, marginLeft: "5%", color: "white" }} >info@visityourgift.com</Text>
                    </TouchableOpacity>
                </View>
            }
            <ScrollView>
                <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.045, marginLeft: "5%", color: "black", marginTop: "5%" }} >Welcome to Visit Your Gift</Text>
                <LinearGradient colors={['#00a4ff', '#4dbfff', 'white']} style={{ borderColor: "#00a4ff", borderWidth: 1, width: "92.5%", height: height * 0.06, borderRadius: 10, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "5%" }} >
                    <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/whites1.png")} />
                    </View>
                    <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "white", }} >Home</Text>
                    </View>

                </LinearGradient>
                {token ?
                    <TouchableOpacity onPress={() => wishlist()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white2.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Wishlist</Text>
                        </View>

                    </TouchableOpacity>
                    : null}
                {token ?
                    <TouchableOpacity onPress={() => myorders()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white3.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >My Orders</Text>
                        </View>

                    </TouchableOpacity>
                    : null}

                {token ?
                    <TouchableOpacity onPress={() => myaccount()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white4.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >My Account</Text>
                        </View>

                    </TouchableOpacity>
                    : null}




                {/* <TouchableOpacity onPress={() => Setting()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                    <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "47.5%", height: "47.5%",  alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/settings.png")} />
                    </View>
                    <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Settings</Text>
                    </View>

                </TouchableOpacity> */}
                <TouchableOpacity onPress={() => Terms()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                    <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white5.png")} />
                    </View>
                    <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Terms & Conditions</Text>
                    </View>

                </TouchableOpacity>

                <TouchableOpacity onPress={() => policy()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                    <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white5.png")} />
                    </View>
                    <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Privacy Policy</Text>
                    </View>

                </TouchableOpacity>

                {token ?
                    <TouchableOpacity onPress={() => Contact()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white6.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Contact us</Text>
                        </View>

                    </TouchableOpacity>
                    : null}




                {/* <TouchableOpacity onPress={() => Invite()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                    <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                        <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/add-group.png")} />
                    </View>
                    <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                        <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Invite Friends, Get Benefits</Text>
                    </View>

                </TouchableOpacity> */}


                {token ?
                    <TouchableOpacity onPress={() => props.navigation.navigate('SuperCoins')} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/right.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Points History</Text>
                        </View>

                    </TouchableOpacity>

                    : null}




                {token ?
                    <TouchableOpacity onPress={() => logout()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%", marginBottom: "5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white7.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Logout</Text>
                        </View>

                    </TouchableOpacity>
                    :
                    <TouchableOpacity onPress={() => login()} style={{ width: "92.5%", height: height * 0.06, borderRadius: width * 0.02, alignSelf: "center", alignItems: "center", flexDirection: "row", marginTop: "2.5%", marginBottom: "5%" }} >
                        <View style={{ width: "20%", height: "100%", justifyContent: "center" }} >
                            <Image style={{ width: "47.5%", height: "47.5%", alignSelf: "center", resizeMode: "contain", }} source={require("../../Assets/white8.png")} />
                        </View>
                        <View style={{ width: "80%", height: "100%", justifyContent: "center" }} >
                            <Text style={{ fontFamily: "Roboto-Medium", fontSize: width * 0.04, marginLeft: "2.5%", color: "#00a4ff", }} >Login</Text>
                        </View>

                    </TouchableOpacity>
                }
                {/*   
        <View style={{width:"100%",height:height*0.06,backgroundColor:"#f3f7ff",marginTop:"10%",borderWidth:1,borderColor:"black"}} >

        </View> */}
            </ScrollView>

        </SafeAreaView>
    )

}