import Home from "../../Screens/Home";
import { DrawerMenu } from "../Drawerscreen";
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { Dimensions, View } from "react-native";

const Drawer = createDrawerNavigator();
function MyDrawer() {
const{width,height}=Dimensions.get("window")
    return (
        <View style={{width:'100%',height:'100%'}}>
          <Drawer.Navigator initialRouteName='Home'
            drawerType='front'
            screenOptions={() => ({headerShown: false})}
            drawerStyle={{ width:"100%"}}
            drawerContent={props => { return <DrawerMenu {...props} />;

            }}
          >
            <Drawer.Screen name="Home" component={Home}  />
          </Drawer.Navigator>  
        </View>
    
    )
  };

export default function Sidemenu() {
  
    return (
        <MyDrawer/>
    );
}