import React, { useState, useEffect, } from 'react';
import { View, Text, TouchableOpacity, Image, Dimensions, Platform, StatusBar, Animated } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Card } from 'react-native-shadow-cards';
import { countSelector } from '../../Slices/count';
import { useDispatch, useSelector } from 'react-redux';
import { getmodel, modelSelector } from '../../Slices/model';
import Search from '../../Components/search';
import { cartSelector } from '../../Slices/cart';
import { profileSelector } from '../../Slices/profile';
import { IMAGE_URL_PRODUCTS, IMAGE_URL_PROFILE } from '../../Constants';
import { authSelector } from '../../Slices/auth';
export default function Header(props, navigation) {
   const { cart_length } = useSelector(cartSelector);
   const dispatch = useDispatch();
   const { count } = useSelector(countSelector);
   const { width, height } = Dimensions.get("window")
   const { token } = useSelector(authSelector);
   const { NotificationList } = useSelector(profileSelector)

   const searchcall = () => {
      dispatch(getmodel(true))
   }
   const [pass, setPass] = useState(false)
   const { profile } = useSelector(profileSelector)

   return (

      <View style={{ width: "100%", height: "10%", backgroundColor: "white", flexDirection: "row", alignItems: "center", }} >
         {/* <View style={{ width: "100%",  flexDirection: "row", alignItems: "center", }} > */}
         <TouchableOpacity onPress={() => props.DrawerCall()} style={{ width: "17%", justifyContent: "center", }} >
            {token ?
               <View style={{ height: 45, width: 45, alignSelf: "center", borderRadius: 100, justifyContent: "center", borderWidth: 2, borderColor: "#00a4ff" }} >

                  {!profile.image ?
                     <Image source={require("../../Assets/boss.png")} style={{ width: "90%", height: "90%", alignSelf: "center", borderRadius: 100 }} />

                     :
                     <Image style={{ width: "90%", height: "90%", borderRadius: 100, alignSelf: "center", resizeMode: "contain", }} source={{ uri: IMAGE_URL_PROFILE + profile.image }} />
                  }


               </View>
               :
               <View style={{ height: 45, width: 45, alignSelf: "center", borderRadius: 100, justifyContent: "center", borderWidth: 2, borderColor: "grey" }} >


                  <Image source={require("../../Assets/visit-your-gift.png")} style={{ width: "90%", height: "90%", alignSelf: "center", borderRadius: 100,resizeMode:"contain" }} />




               </View>
            }
         </TouchableOpacity>

         <Card style={{ alignSelf: "center", width: "53%", height: "70%", }} >
            <TouchableOpacity onPress={() => props.search()} style={{ flexDirection: "row", alignItems: "center", width: "100%", height: "100%" }}  >
               {/* <View style={{ width: "15%", height: "100%", justifyContent: "center", }} > */}
               <Image source={require("../../Assets/search.png")} style={{ marginLeft: "2%", width: 25, height: 25, alignSelf: "center" }} />
               {/* </View> */}
               <View style={{ width: "80%", height: "100%", justifyContent: "center", marginLeft: "2%", }} >
                  <Text style={{ fontSize: width * 0.0425, fontFamily: "Roboto-Light", }} >Search </Text>
               </View>
            </TouchableOpacity>
         </Card>

         <TouchableOpacity onPress={() => props.notificationcall()} style={{ width: "15%", height: 72, justifyContent: "center" }} >
            <Image source={require("../../Assets/bell.png")} style={{ width: width * 0.06, height: height * 0.033, alignSelf: "center" }} />
            <View style={{ width: "35%", height: 20, backgroundColor: "#00a4ff", position: "absolute", borderRadius: width * 0.045, top: "18%", alignSelf: "flex-end", right: "15%", justifyContent: "center" }} >
               <Text style={{ fontFamily: "Roboto-Medium", textAlign: "center", color: "white", fontSize: width * 0.0325 }} >{NotificationList.length}</Text>
            </View>
         </TouchableOpacity>

         <TouchableOpacity onPress={() => props.cartcall()} style={{ width: "15%", height: 72, justifyContent: "center" }} >
            <Image source={require("../../Assets/shopping-cart.png")} style={{ width: width * 0.07, height: height * 0.035, alignSelf: "center" }} />
            <View style={{ width: "35%", height: 20, backgroundColor: "#00a4ff", position: "absolute", borderRadius: 100, top: "18%", alignSelf: "flex-end", right: "15%", justifyContent: "center" }} >
               <Text style={{ fontFamily: "Roboto-Medium", textAlign: "center", color: "white", fontSize: width * 0.0325 }} >{cart_length}</Text>
            </View>
         </TouchableOpacity>

         {/* </View> */}

      </View>

   )

}

